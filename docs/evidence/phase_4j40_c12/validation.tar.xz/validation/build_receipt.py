"""Bind completed verification to the frozen implementation; never promote science."""
import json,time,tarfile,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
from scripts.phase_4j40_c11_numeric import sha,signed,write
from scripts.validate_phase_4j40_c12_receipt import BASE,SOURCES
root=Path('/tmp/j40-c12-validation');v=root/'validation';out=Path('docs/evidence/phase_4j40_c12')
required=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
while not all((v/(n+'-command.json')).exists() for n in required):time.sleep(5)
tested=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
gates={n:json.loads((v/(n+'-command.json')).read_text()) for n in required}
for n,r in gates.items():assert r['exit_code']==0 and r['tested_implementation_commit']==tested,(n,r,tested)
for n in ('focused','regressions','full'):
 suites=ET.parse(v/(n+'.xml')).getroot().findall('testsuite');gates[n]['junit']={k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
summary=json.loads((out/'summary.json').read_text());study=json.loads((root/'study/study.json').read_text());audit=json.loads((root/'study/independent-audit.json').read_text());assert audit['all_passed']
for log in root.glob('*.log'):(v/('progress-'+log.name)).write_bytes(log.read_bytes())
with tarfile.open(out/'validation.tar.xz','w:xz') as archive:
 for p in sorted(v.rglob('*')):
  if p.is_file() and not any(x.endswith('-tmp') or x=='__pycache__' for x in p.relative_to(v).parts):archive.add(p,arcname=str(Path('validation')/p.relative_to(v)))
manifest=signed({'schema':'island.j40-c12-manifest.v1','base_commit':BASE,'tested_implementation_commit':tested,'study_identity':study['identity'],'summary_identity':summary['identity'],'artifacts_archive_sha256':sha(out/'artifacts.tar.xz'),'native_evaluations':208,'additional_exclusion_control_native_evaluations':2,'independent_controls':49,'native_lammps_implementation_repaired':False,'comparison_adapter':'explicit analytical single-frame special-pair completion','scientific_acceptance':False,'production_validated':False,'simulation_readiness':'not_established','cutoff_recovery':'not_executed','long_npt':'not_executed'})
write(out/'manifest.json',manifest)
history=json.loads((v/'historical-hashes.json').read_text())
receipt=signed({'schema':'island.j40-c12-receipt.v1','base_commit':BASE,'tested_implementation_commit':tested,'final_evidence_commit_resolution':'git log --format=%H -1 -- docs/evidence/phase_4j40_c12/receipt.json','implementation_sources':{n:sha(n) for n in SOURCES},'validation':gates,'files':{n:sha(out/n) for n in ('artifacts.tar.xz','artifact-inventory.json','manifest.json','summary.json','validation.tar.xz')},'artifact_inventory':json.loads((out/'artifact-inventory.json').read_text()),'manifest_identity':manifest['identity'],'study_identity':study['identity'],'historical_files':history,'historical_entries':len(history),'scientific_acceptance':False,'production_validated':False,'simulation_readiness':'not_established','scope':'single-frame comparison completion; native LAMMPS and production export behavior unchanged','remaining_limitations':summary['limitations']})
write(out/'receipt.json',receipt)
print(json.dumps({n:r.get('junit',r['exit_code']) for n,r in gates.items()},indent=2),flush=True)
