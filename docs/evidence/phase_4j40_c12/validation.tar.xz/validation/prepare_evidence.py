import json,tarfile,shutil,hashlib
from pathlib import Path
from scripts.phase_4j40_c11_numeric import sha,signed,write
root=Path('/tmp/j40-c12-validation');study=root/'study';out=Path('docs/evidence/phase_4j40_c12')
source=Path('/tmp/j40-validation/final/run');reference=Path('/tmp/j40-c2-validation/run/reference')
originals=study/'source-originals';originals.mkdir(exist_ok=False)
source_hashes={}
for name in ('gaff2-pe','opls-peo','opls-resp-aromatic','opls-network'):
 p=originals/name;p.mkdir()
 shutil.copyfile(source/name/'backend.json',p/'backend.json')
 shutil.copyfile(reference/name/'cross-engine/system.data',p/'system.data')
 source_hashes[name]={n:sha(p/n) for n in ('backend.json','system.data')}
 assert json.loads((p/'backend.json').read_text())==json.loads((study/'additional-inputs'/(name+'-backend.json')).read_text())
 assert (p/'system.data').read_bytes()==(study/'additional-inputs'/(name+'.data')).read_bytes()
audit=json.loads((study/'independent-audit.json').read_text());assert audit['all_passed'] and len(audit['reports'])==49
rows=json.loads((study/'additional-matrix.json').read_text());c11=json.loads((study/'c11-completed.json').read_text());first=next(r for r in c11 if r['name']=='box-1.5')
def compact(row):
 return {k:row[k] for k in ('name','case','charge_origin')}|{'outside_pairs':len(row['completion']['pairs']),'native_energy_error_kj_mol':row['comparison']['native']['absolute_energy_error_kj_mol'],'composite_energy_error_kj_mol':row['comparison']['composite']['absolute_energy_error_kj_mol'],'composite_max_force_error_kj_mol_nm':row['comparison']['composite']['forces']['maximum_component_error'],'native_energy_force_passed':row['comparison']['native']['passed'],'composite_energy_force_passed':row['comparison']['composite']['passed']}
summary=signed({'schema':'island.j40-c12-summary.v1','implementation_scope':'explicit analytical single-frame comparison completion; not a native LAMMPS implementation repair','native_evaluations':208,'c11_paired_rows':38,'additional_paired_rows':48,'independent_frames':49,'independent_audit_sha256':sha(study/'independent-audit.json'),'first_failing_strained_case':{'native_energy_error_kj_mol':first['comparison']['native']['absolute_energy_error_kj_mol'],'composite_energy_error_kj_mol':first['comparison']['composite']['absolute_energy_error_kj_mol'],'native_max_force_error_kj_mol_nm':first['comparison']['native']['forces']['maximum_component_error'],'composite_max_force_error_kj_mol_nm':first['comparison']['composite']['forces']['maximum_component_error'],'special_pairs':len(first['completion']['pairs']),'completion_lj_kj_mol':first['completion']['energy_lj_kj_mol'],'completion_coulomb_kj_mol':first['completion']['energy_coulomb_kj_mol'],'native_passed':False,'composite_energy_force_passed':first['comparison']['composite']['passed']},'actual_matrix':[compact(r) for r in rows],'source_files':source_hashes,'pressure_derivatives':json.loads((study/'strained-pressure.json').read_text()),'ewald_status':'ewald_unvalidated','pressure_status':'pressure_unavailable','scientific_acceptance':False,'production_validated':False,'simulation_readiness':'not_established','long_npt':'not_executed','cutoff_recovery':'not_executed','limitations':['Native LAMMPS pair semantics are unchanged; production exporter rejects beyond-cutoff scaled pairs','Additional PME/PPPM residuals and unstrained tight Ewald residuals still exceed unchanged bounds','No full OpenMM reciprocal force-virial tensor pressure qualification','Rounded native Ewald alpha log is recorded explicitly','Orthorhombic unconstrained no-switching single-frame scope only','No long MD, density target change, charge normalization or native AM1-BCC claim']})
write(out/'summary.json',summary)
with tarfile.open(out/'artifacts.tar.xz','w:xz') as tar:
 tar.add(study,arcname='study')
 for name in ('independent_audit.py','reconstruct_inputs.py'):
  tar.add(root/'validation'/name,arcname='audit/'+name)
with tarfile.open(out/'artifacts.tar.xz') as tar:
 inventory={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile()}
write(out/'artifact-inventory.json',inventory)
print('artifact files',len(inventory),'bytes',(out/'artifacts.tar.xz').stat().st_size)
