"""Extra coordinate-only single-frame control for excluded 1-2/1-3 pairs."""
import copy,json,shutil,sys
from pathlib import Path
import numpy as np
from scripts.phase_4j40_c12 import completion,comparison
from scripts.phase_4j40_c12_study import frame_for
from scripts.phase_4j40_c12_engine import openmm_point,lammps_point
from scripts.phase_4j40_c11_numeric import write,sha
study=Path(sys.argv[1]);out=Path(sys.argv[2]);exe=Path(sys.argv[3]).resolve();out.mkdir()
shutil.copytree(study/'c11-rerun/box-1.5',out/'c11-rerun/box-1.5')
shutil.copyfile(study/'c11-completed.json',out/'c11-completed.json')
b=json.loads((study/'c11-rerun/inputs/backend.json').read_text());base=json.loads((study/'c11-rerun/box-1.5/frame.json').read_text())
xyz=np.array(base['positions_nm']);xyz[0,0]+=.6;box=np.array(base['box_lengths_nm']);frame=frame_for(b,xyz,box)
setting={'method':'ewald','tolerance':1e-9,'cutoff_nm':.5};path=out/'coordinate-perturbation-12-13';path.mkdir();write(path/'frame.json',frame)
om=openmm_point(b,xyz,box,setting,frame['identity'],path/'openmm')
lm=lammps_point((study/'c11-rerun/inputs/system.data').read_text(),xyz,box,setting,frame['identity'],path/'lammps',exe)
c=completion(b,frame,setting,lm);row={'openmm':om,'lammps':lm,'completion':c,'comparison':comparison(om,lm,c)};write(path/'comparison.json',row)
assert {p['path_length'] for p in c['pairs']}=={1,2,3}
write(out/'experiment.json',{'transformation':'atom 1 x coordinate +0.6 nm; single-point diagnostic only','parent_frame_identity':base['identity'],'new_frame_identity':frame['identity'],'same_graph':True,'same_numerical_parameters_and_charges':True,'lammps_sha256':sha(exe),'helper_sha256':sha(__file__),'scientific_acceptance':False})
print('Executed excluded-pair control with path lengths 1, 2 and 3')
