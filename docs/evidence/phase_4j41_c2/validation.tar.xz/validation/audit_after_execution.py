import copy,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
from island.charge_references.records import pack,unpack
from island.exceptions import PCFFError
from island.forcefields.pcff.mixed_sip import load_pcff_sip_distribution
from island.forcefields.pcff.sip_completion import load_pcff_sip_completion
from island.workflows.bundle import system_from
from scripts.phase_4j41_c2 import read
from scripts.validate_phase_4j41_c2_receipt import validate_study
repo=Path.cwd();root=Path('/tmp/j41-c2-validation');v=root/'validation';study=root/'final-study';py=(repo/'../island-validation/phase4e2-env/bin/python').resolve()
env={**os.environ,'PYTHONPATH':str(repo)+':'+str(repo/'src'),'OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,cmd,cwd=repo):
 start=time.time()
 with (v/(name+'.log')).open('w') as log:r=subprocess.run(cmd,env=env,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 result={'argv':list(map(str,cmd)),'cwd':str(cwd),'exit_code':r.returncode,'elapsed_seconds':time.time()-start}
 (v/(name+'-command.json')).write_text(json.dumps(result,indent=2)+'\n')
 if r.returncode:raise RuntimeError('Failed '+name)
 return result
result=validate_study(study)
(v/'study-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('independent study validation passed',flush=True)
report=read(study/'report.json');original=json.loads((repo/'docs/evidence/phase_4j41_c1/receipt.json').read_text())
old={r['name']:r for r in original['profiles']}
for row in report['cases']:
 assert row['c1_identity']==old[row['name']]['assessment_identity']
 assert row['graph_identity']==old[row['name']]['graph_identity']
 assert row['source_complete']==old[row['name']]['source_complete']
base=read(study/'c1-replay/baseline/report.json')['cases'][0]
historical=json.loads((repo/'docs/evidence/phase_4j41/receipt.json').read_text())['numerical_silane']
for key in ('singlepoint','finite_differences','minimization','coefficient_audit'):
 assert base[key]==historical[key],key
(v/'preserved-identities.json').write_text(json.dumps({'c1_assessments':len(report['cases']),'all_identical':True,'finite_silane_numerical_fields_identical':['singlepoint','finite_differences','minimization','coefficient_audit'],'silane_model_identity':base['model_identity']},indent=2)+'\n')
print('all 17 C1 assessment identities and J41 silane numerical fields unchanged',flush=True)
d=load_pcff_sip_distribution(study);mutroot=root/'negative-controls';mutroot.mkdir(exist_ok=False);results=[]
for mutation in ('source','graph','order','charge','coupling','p_type','policy','pressure'):
 name='phosphate_ester' if mutation=='p_type' else 'methylsilane'
 s=system_from(read(study/'c1-replay'/name/'system.json'));p=unpack((study/name/'decision.json').read_text())
 if mutation=='source':p['source_evidence']['atom_rows'][0]['connections']=3
 elif mutation=='graph':p['c1_assessment']['graph']['bonds'].pop()
 elif mutation=='order':p['c1_assessment']['atom_order'].reverse()
 elif mutation=='charge':p['c1_assessment']['inspection']['native_charge_record']['native_charge_record']['partial_charges'][1]+=0.1
 elif mutation=='coupling':p['blocking_interactions'].clear();p['execution_authorized']=True
 elif mutation=='p_type':p['phosphorus_decisions'][0]['selected_type']='p='
 elif mutation=='policy':p['policy']['missing_source_row']='zero'
 elif mutation=='pressure':p['pressure_status']='validated'
 path=mutroot/(mutation+'.json');path.write_text(pack(p))
 try:load_pcff_sip_completion(path,d,system=s)
 except PCFFError as error:results.append({'mutation':mutation,'rejected':True,'diagnostic':str(error),'artifact_sha256':sha(path)})
 else:raise RuntimeError('Mutation accepted '+mutation)
(v/'mutation-audit.json').write_text(json.dumps({'all_rejected':True,'results':results},indent=2)+'\n')
print('eight resigned file-level mutations rejected',flush=True)
relocated=root/'relocated';relocated.mkdir(exist_ok=False);shutil.copytree(study,relocated/'study')
files={str(p.relative_to(study)):sha(p) for p in study.rglob('*') if p.is_file()}
cwd=root/'relocation-cwd';cwd.mkdir(exist_ok=False)
cmd=[str(py),str(repo/'scripts/phase_4j41_c2.py'),'--reconstruct',str(relocated/'study')]
r=run('portable-reconstruction',cmd,cwd)
after={str(p.relative_to(relocated/'study')):sha(p) for p in (relocated/'study').rglob('*') if p.is_file()}
assert after==files,'Relocated study bytes changed'
assert {str(p.relative_to(study)):sha(p) for p in study.rglob('*') if p.is_file()}==files,'Original study changed'
r.update(all_study_files_identical_after_relocation=True,study_file_count=len(files),original_study_unchanged=True)
(v/'portable-reconstruction-command.json').write_text(json.dumps(r,indent=2)+'\n')
print('relocated separate-process reconstruction passed; files unchanged:',len(files),flush=True)
for phase in ('4j41','4j41_c1'):
 run('historical-'+phase+'-validator',[str(py),str(repo/f'scripts/validate_phase_{phase}_receipt.py'),str(repo/f'docs/evidence/phase_{phase}')])
 print('historical receipt validator passed:',phase,flush=True)
for p,h in json.loads((v/'historical-hashes.json').read_text()).items():assert sha(repo/p)==h,p
print('historical byte-hash preservation passed',flush=True)
