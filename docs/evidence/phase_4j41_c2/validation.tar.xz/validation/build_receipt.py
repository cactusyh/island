import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from island.charge_references.records import unpack
from scripts.phase_4j41_c2 import read
from scripts.validate_phase_4j41_c2_receipt import validate_study
from scripts.validate_phase_4j41_receipt import signed
r=Path('/tmp/j41-c2-validation');v=r/'validation';repo=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
commit=(v/'implementation-commit.txt').read_text().strip();base=(v/'base-commit.txt').read_text().strip()
names=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
verification={n:json.loads((v/(n+'-command.json')).read_text()) for n in names}
for name,q in verification.items():
 assert q['exit_code']==0 and q['tested_implementation_commit']==commit,(name,q)
 for shard in q.get('shards',[]):assert shard['exit_code']==0 and shard['tested_implementation_commit']==commit
for name in ('focused','regressions','full'):
 counts={k:0 for k in ('tests','failures','errors','skipped')}
 for suite in ET.parse(v/(name+'.xml')).getroot().iter('testsuite'):
  for k in counts:counts[k]+=int(suite.attrib.get(k,0))
 counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
 assert counts['passed'] and not counts['failures'] and not counts['errors']
 verification[name]['junit']=counts
current_files=sorted(f for f in subprocess.check_output(['git','ls-files','tests'],text=True).splitlines() if Path(f).name.startswith('test_') and f.endswith('.py') and not any(part.startswith('.') for part in Path(f).parts))
assert verification['full']['all_test_files']==current_files
historical=json.loads((v/'historical-hashes.json').read_text());frozen=json.loads((v/'frozen-source.json').read_text())
for group in (historical,frozen):
 for p,h in group.items():assert sha(repo/p)==h,p
identities=json.loads((v/'preserved-identities.json').read_text());mutations=json.loads((v/'mutation-audit.json').read_text());relocation=json.loads((v/'portable-reconstruction-command.json').read_text());execution=json.loads((v/'execution-command.json').read_text())
assert identities['all_identical'] and identities['c1_assessments']==17
assert mutations['all_rejected'] and len(mutations['results'])==8
assert relocation['exit_code']==0 and relocation['all_study_files_identical_after_relocation']
assert execution['exit_code']==1 and execution['tested_implementation_commit']==commit
for name in ('historical-4j41-validator','historical-4j41_c1-validator'):
 assert json.loads((v/(name+'-command.json')).read_text())['exit_code']==0
independent=validate_study(r/'final-study')
report=read(r/'final-study/report.json');silane=read(r/'final-study/c1-replay/baseline/report.json')['cases'][0]
compiled=read(r/'final-study/compiled-completion-searches.json')
source_status=Counter(q['independent']['status'] for q in compiled)
profiles=[]
for row in report['cases']:
 p=unpack((r/'final-study'/row['name']/'decision.json').read_text());legacy=p['c1_assessment'];i=legacy['inspection'];charges=i['native_charge_record']['native_charge_record'] if i else None
 profiles.append({**row,'domain':p['domain'],'phosphorus_decisions':p['phosphorus_decisions'],'charge_origin':p['policy']['charge_origin'],'charge_status':'complete' if i and i['charges_complete'] else 'typing_blocked_not_assigned','parameter_status':'complete' if p['source_complete'] else 'source_incomplete_or_typing_blocked','typing_identity':i['typing_identity'] if i else None,'charge_identity':i['charge_identity'] if i else None,'parameter_identity':i['assignment_identity'] if i and p['source_complete'] else None,'diagnostic_assignment_identity':i['assignment_identity'] if i else None,'atom_order':legacy['atom_order'],'charge_unit':'elementary_charge' if charges else None,'charge_vector':[[k,charges['partial_charges'][k]] for k in legacy['atom_order']] if charges else None,'component_totals':charges['components'] if charges else None,'periodic_status':'not_authorized','scientific_validation_status':'not_established'})
source_dir=v/'source';source_dir.mkdir(exist_ok=False)
for p in frozen:
 dest=source_dir/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,dest)
for name in ('build.py','run_gates.py','audit_after_execution.py','build_receipt.py','rerun_supported.py','finalize_supported_full.py'):
 shutil.copyfile(r/name,v/name)
pub=r/'portable';pub.mkdir(exist_ok=False)
shutil.copytree(r/'final-study',pub/'study')
for folder in ('converter','matcher','negative-controls'):shutil.copytree(r/folder,pub/folder)
for name in ('build.json','matcher-execution.json','environment.json','runtime-inventory.json'):
 shutil.copyfile(r/name,pub/name)
for name in ('execution-command.json','execution.log','study-validation.json','mutation-audit.json','preserved-identities.json','portable-reconstruction-command.json','portable-reconstruction.log','historical-4j41-validator-command.json','historical-4j41-validator.log','historical-4j41_c1-validator-command.json','historical-4j41_c1-validator.log'):
 shutil.copyfile(v/name,pub/name)
bundle=signed({'schema':'island.j41-c2-portable-bundle.v1','files':{str(p.relative_to(pub)):sha(p) for p in sorted(pub.rglob('*')) if p.is_file()}})
(pub/'bundle-manifest.json').write_text(json.dumps(bundle,indent=2)+'\n')
evidence=repo/'docs/evidence/phase_4j41_c2';evidence.mkdir(exist_ok=False)
with tarfile.open(evidence/'execution.tar.xz','w:xz') as tar:
 for p in sorted(pub.iterdir()):tar.add(p,arcname=p.name)
with tarfile.open(evidence/'validation.tar.xz','w:xz') as tar:
 for p in sorted(v.iterdir()):
  if p.is_file() or p.name=='source':tar.add(p,arcname='validation/'+p.name)
manifest=signed({'schema':'island.j41-c2-manifest.v1','base_commit':base,'tested_implementation_commit':commit,'files':{n:sha(evidence/n) for n in ('execution.tar.xz','validation.tar.xz')},'historical_files':historical,'implementation_files':frozen,'bundle_identity':bundle['identity']})
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
runtime=json.loads((r/'runtime-inventory.json').read_text());env=json.loads((r/'environment.json').read_text())
receipt=signed({'schema':'island.j41-c2-receipt.v1','created_utc':datetime.now(timezone.utc).isoformat(),'phase':'4J41-C2','base_commit':base,'tested_implementation_commit':commit,'branch':'codex/phase-4j41-c2-source-complete-sip','acceptance_gate':1,'outcome':'finite_silane_preserved; all 16 additional retained candidates source-incomplete or typing-blocked; no new mixed-Si/P executable profile','production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(evidence/'manifest.json'),'independent_validation':independent,'profiles':profiles,'source_distribution':report['distribution_hashes'],'source_audit':{'independent_parser':'scripts/pcff_j5_reference.py and scripts/pcff_j41_c2_reference.py; no production parser/resolver in raw oracle','full_table_searches':len(compiled),'search_status_counts':dict(sorted(source_status.items())),'c1_raw_numerical_rows_checked':4359,'c1_compiled_direct_queries':347,'c1_assessment_identity_preservation':identities,'angle_angle_adapter':'fixed center/shared site; a b c d then d b c a; compiled leaf calls mirror GetParameters.c find_angleangle_data first coefficient','p_resolution':'explicit degree/valence/oxidation/formal-charge/H/O state and original source/template candidates; no P type or charge selected','missing_source_policy':'reject; never substitute zero or infer a coupling from a lower-order family','no_new_executable_domains':True},'converter':runtime['converter'],'converter_build':json.loads((r/'build.json').read_text()),'lammps':runtime['lammps'],'openmm':{k:env[k] for k in ('python','platform','machine','processor','openmm','openmm_platform','precision','numpy','rdkit')},'finite_silane':{'historical_numerical_results_identical':True,'model_identity':silane['model_identity'],'singlepoint':silane['singlepoint'],'coefficient_audit':silane['coefficient_audit'],'finite_differences':silane['finite_differences'],'minimization':silane['minimization'],'dynamics':silane['dynamics'],'time_step_fs':0.1,'steps_per_integrator':200,'trajectory_length_ps':0.02,'interpretation':'finite software control; no active intramolecular nonbonded pairs; no periodic or scientific qualification'},'periodic_scientific_status':{'ewald':'ewald_unvalidated','pressure':'pressure_unavailable','long_npt':'blocked','cutoff_recovery':'not_executed'},'audits':{'execution':execution,'relocation_fresh_process':relocation,'negative_controls':mutations,'historical_preservation':{'files':len(historical),'changed':0}},'verification':verification,'limitations':['The pinned source does not establish a complete executable path for any of the 16 additional retained candidates.','Converter-supplied label consumption is not chemical perception or charge assignment.','No missing coupling is zero-filled and no Si/P type, parameter or charge is invented or normalized.','Finite-silane whole/split final state and full RNG are exact; checkpoint byte equality applies to identical segmented lineage across relocated fresh processes.','No periodic Ewald/PPPM, backend pressure, long NPT, scientific equilibrium, experimental agreement or production readiness is established.']})
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps({'receipt':str(evidence/'receipt.json'),'verification':{k:q['junit'] for k,q in verification.items() if 'junit'in q},'historical_files':len(historical),'compiled_searches':len(compiled),'acceptance_gate':1}),flush=True)
