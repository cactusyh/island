import concurrent.futures,json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/j41-c2-validation');v=r/'validation';repo=Path.cwd();jobs=json.loads((r/'rerun-supported-shards.json').read_text())
env={**os.environ,**json.loads(Path('/tmp/j41-c1-validation/validation/full-command.json').read_text())['environment']}
def run(q):
 start=time.time()
 with (v/(q['name']+'.log')).open('w') as log:x=subprocess.run(q['argv'],env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 record={'argv':q['argv'],'cwd':str(repo),'environment':{k:env[k] for k in env if k.startswith('ISLAND_') or k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exit_code':x.returncode,'elapsed_seconds':time.time()-start}
 (v/(q['name']+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');print(q['name'],x.returncode,flush=True)
 return x.returncode
# Let the superseded parent finish writing its failed-shard records first.
while not all((v/(q['name']+'-command.json')).exists() for q in jobs):time.sleep(1)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,jobs))
raise SystemExit(max(results))
