import hashlib,json,os,platform,shutil,subprocess,sys
from pathlib import Path
root=Path('/tmp/j41-c2-validation')
repo=Path.cwd()
src=repo.parent/'lammps/lammps/tools/msi2lmp/src'
out=root/'converter'
out.mkdir(exist_ok=False)
for p in sorted(src.iterdir()):
 if p.suffix in ('.c','.h'):
  shutil.copyfile(p,out/p.name)
cmd=['cc','-O2','-o',str(out/'msi2lmp'),*[str(p) for p in sorted(out.glob('*.c'))],'-lm']
r=subprocess.run(cmd,capture_output=True,text=True)
(root/'build.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.suffix in ('.c','.h')},'executable_sha256':hashlib.sha256((out/'msi2lmp').read_bytes()).hexdigest() if r.returncode==0 else None},indent=2))
r.check_returncode()
cmd=[sys.executable,'scripts/audit_pcff_c_matcher.py','--source',str(src.parent/'frc_files/pcff.frc'),'--msi2lmp-source',str(src),'--output',str(root/'matcher'),'--compare-native']
r=subprocess.run(cmd,capture_output=True,text=True)
(root/'matcher-execution.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2))
r.check_returncode()
import openmm,numpy,rdkit
(root/'environment.json').write_text(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'processor':platform.processor(),'openmm':openmm.__version__,'openmm_platform':'Reference','precision':'double','numpy':numpy.__version__,'rdkit':rdkit.__version__,'compiler':subprocess.check_output(['cc','--version'],text=True),'cpuinfo':Path('/proc/cpuinfo').read_text(),'build_time_worktree_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2))
cmd=[sys.executable,'scripts/phase_4j41_c2.py','--distribution',str(src.parent/'frc_files'),'--converter',str(out/'msi2lmp'),'--matcher',str(root/'matcher/leaf.so'),'--lammps',str(repo.parent/'island-validation/phase4j22/lmp-kspace'),'--output',str(root/'study')]
r=subprocess.run(cmd,capture_output=True,text=True)
(root/'study-execution.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2))
print(r.stdout,r.stderr,flush=True)
if r.returncode != 1: raise SystemExit(r.returncode or 99)
print('expected blocked source gate reproduced',flush=True)
