import concurrent.futures,hashlib,json,os,re,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/tmp/j41-c2-validation');v=root/'validation';v.mkdir(exist_ok=True);repo=Path.cwd();py='../island-validation/phase4e2-env/bin/python'
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1',**json.loads(Path('/tmp/j41-c1-validation/validation/full-command.json').read_text())['environment']}
mode=sys.argv[1]
def run(name,argv):
 start=time.time();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 with (v/(name+'.log')).open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 result={'argv':argv,'cwd':str(repo),'environment':{k:env[k] for k in env if k.startswith('ISLAND_') or k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'tested_implementation_commit':commit,'exit_code':r.returncode,'elapsed_seconds':time.time()-start}
 (v/(name+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,r.returncode,flush=True)
 return result
if mode in ('focused','regressions','full'):
 if mode=='focused':files=[Path('tests/test_phase_4j41_c2.py')];n=1
 elif mode=='regressions':
  files=[p for p in sorted(Path('tests').glob('test_phase_4j*.py')) if (m:=re.search(r'4j(\d+)',p.name)) and 22<=int(m[1])<=41 and p.name!='test_phase_4j41_c2.py'];n=8
 else:files=sorted(Path(f) for f in subprocess.check_output(['git','ls-files','tests'],text=True).splitlines() if Path(f).name.startswith('test_') and f.endswith('.py') and not any(part.startswith('.') for part in Path(f).parts));n=8
 durations={}
 for test in ET.parse('/tmp/j41-c1-validation/validation/full.xml').getroot().iter('testcase'):
  file=test.attrib['classname'].replace('.','/')+'.py';durations[file]=durations.get(file,0)+float(test.attrib.get('time',0))
 bins=[[] for _ in range(n)];times=[0.]*n
 for p in sorted(files,key=lambda x:durations.get(str(x),60),reverse=True):
  i=min(range(n),key=lambda i:times[i]);bins[i].append(str(p));times[i]+=durations.get(str(p),60)
 def shard(item):
  i,fs=item;name=f'{mode}-{i:02d}';argv=[py,'-m','pytest','-p','no:cacheprovider','-q','--tb=short','--junitxml='+str(v/(name+'.xml')),'--basetemp='+str(v/(name+'-tmp')),*fs]
  return run(name,argv)
 with concurrent.futures.ThreadPoolExecutor(max_workers=n) as pool:results=list(pool.map(shard,enumerate(bins)))
 merged=ET.Element('testsuites')
 for i in range(n):
  for suite in ET.parse(v/f'{mode}-{i:02d}.xml').getroot():merged.append(suite)
 ET.ElementTree(merged).write(v/(mode+'.xml'),encoding='utf-8',xml_declaration=True)
 aggregate={'argv':['module-partitioned pytest; exact shard commands attached'],'cwd':str(repo),'tested_implementation_commit':results[0]['tested_implementation_commit'],'exit_code':max(r['exit_code'] for r in results),'shards':results,'all_test_files':sorted(map(str,files)),'partition_disjoint':True}
 assert len(files)==len(set(f for b in bins for f in b))
 (v/(mode+'-command.json')).write_text(json.dumps(aggregate,indent=2)+'\n')
 raise SystemExit(aggregate['exit_code'])
if mode=='checks':
 jobs=[('ruff',[py,'-m','ruff','check','.']),('compileall',[py,'-m','compileall','-q','src','scripts','tests']),('diff_check',['git','diff','--check'])]
 environments={'supported':'../island-validation/phase4e2-env/bin/python','foyer':'../island-validation/phase4g1-env/bin/python','analysis':'../island-validation/phase4j32-analysis-env/bin/python','amber':'../miniforge3/envs/md_rg/bin/python','quantum':'../island-validation/phase4j36-native-env/bin/python'}
 jobs += [(f'pip_{k}',[p,'-m','pip','check']) for k,p in environments.items()]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(lambda j:run(*j),jobs))
 raise SystemExit(max(r['exit_code'] for r in results))
if mode=='execution':
 cmd=[py,'scripts/phase_4j41_c2.py','--distribution',str(repo.parent/'lammps/lammps/tools/msi2lmp/frc_files'),'--converter',str(root/'converter/msi2lmp'),'--matcher',str(root/'matcher/leaf.so'),'--lammps',str(repo.parent/'island-validation/phase4j22/lmp-kspace'),'--output',str(root/'final-study')]
 result=run('execution',cmd)
 if result['exit_code']!=1 or not (root/'final-study/report.json').is_file():raise SystemExit(99)
 raise SystemExit(0)
