import json,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
r=Path('/tmp/j41-c2-validation');v=r/'validation'
while not (v/'full-command.json').exists():time.sleep(5)
while True:
 try:checks=[json.loads((v/f'full-{i:02d}-command.json').read_text()) for i in range(8)]
 except FileNotFoundError:time.sleep(5);continue
 if all(q['exit_code']==0 for q in checks):break
 if (r/'supported-rerun.log').read_text().count(' 0')>=2:
  raise SystemExit('A supported full-suite partition failed')
 time.sleep(5)
files=[a for q in checks for a in q['argv'] if a.startswith('tests/')]
expected=sorted(f for f in subprocess.check_output(['git','ls-files','tests'],text=True).splitlines() if Path(f).name.startswith('test_') and f.endswith('.py') and not any(part.startswith('.') for part in Path(f).parts))
assert len(files)==len(set(files)) and sorted(files)==expected,'Incomplete/overlapping supported test inventory'
merged=ET.Element('testsuites')
for i in range(8):
 for suite in ET.parse(v/f'full-{i:02d}.xml').getroot():merged.append(suite)
ET.ElementTree(merged).write(v/'full.xml',encoding='utf-8',xml_declaration=True)
record={'argv':['module-partitioned pytest; exact supported shard commands attached'],'cwd':str(Path.cwd()),'tested_implementation_commit':checks[0]['tested_implementation_commit'],'exit_code':0,'shards':checks,'all_test_files':expected,'partition_disjoint':True,'discovery_policy':'standard pytest ignores hidden directories, including .ipynb_checkpoints','discovery_exclusions':['tests/.ipynb_checkpoints/test_conformations-checkpoint.py','tests/.ipynb_checkpoints/test_forcefields-checkpoint.py']}
(v/'full-command.json').write_text(json.dumps(record,indent=2)+'\n')
print('All supported full-suite partitions passed; exact discovery inventory:',len(expected),flush=True)
