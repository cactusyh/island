#include <string.h>
#include "Forcefield.h"
int match_types(int,int,char[][5],char[][5],int*);
#include <stdio.h>
#include <stdlib.h>
struct FrcFieldItem equivalence;
void condexit(int code) { exit(code); }
int find_equiv_type(char potential_type[5]);
int find_match(int n, char types1[][5],struct FrcFieldItem item,int
               *backwards_ptr)
{
  int k,match;

  match = 0;
  k=0;

  /* Try for an exact match (no wildcards) first */

  while (!match && (k < item.entries)) {
    if (match_types(n, 0,types1,item.data[k].ff_types,backwards_ptr) == 1)
      match = 1;
    else
      k++;
  }

  /* Try again - allow wildcard matching  */

  if (!match) {
    k=0;
    while (!match && (k < item.entries)) {
      if (match_types(n,1,types1,item.data[k].ff_types,backwards_ptr) == 1)
        match = 1;
      else
        k++;
    }
  }
  if (match) return k;
  else return -1;
}

int match_types(int n,int wildcard,char types1[][5],char types2[][5],
                int *backwards_ptr)
{
  int k,match;

  /* Routine to match short arrays of characters strings which contain
     atom potential types. The arrays range from 1 to 4 (VDW or equivalences,
     bond, angle, dihedrals or oops). There are potentially four ways the
     arrays can match: exact match (forwards), exact match when one array is
     run backwards (backwards), forwards with wildcard character match allowed
     (forwards *) and finally backwards with wildcard character match
     (backwards *). If the variable, backwards (pointed by backwards_ptr)
     is -1, then the backwards options are not to be used (such when
     matching oop types)
  */


  if (wildcard == 0) {

  /* forwards */

    k=0;
    match = 1;
    while (match && (k < n)) {
      if (strncmp(types1[k],types2[k],5) == 0)
        k++;
      else
        match = 0;
    }
  } else {

  /* forwards * */

    k=0;

    match = 1;
    while (match && (k < n)) {
      if ((strncmp(types1[k],types2[k],5) == 0) ||
          (types2[k][0] == '*'))
        k++;
      else
        match = 0;
    }
  }

  if (match) {
    *backwards_ptr = 0;
    return 1;
  }
  if ((n < 2) || (*backwards_ptr == -1)) return 0;

  if (wildcard == 0) {

  /* backwards */

    k=0;
    match = 1;
    while (match && (k < n)) {
      if (strncmp(types1[n-k-1],types2[k],5) == 0)
        k++;
      else
        match = 0;
    }
  } else {

  /* backwards * */

    k=0;
    match = 1;
    while (match && (k < n)) {
      if ((strncmp(types1[n-k-1],types2[k],5) == 0) ||
          (types2[k][0] == '*')                   )
        k++;
      else
        match = 0;
    }
  }

  if (match) {
    *backwards_ptr = 1;
    return 1;
  } else return 0;
}

void get_equivs(int ic,char potential_types[][5],char equiv_types[][5])
{
  int i,k;
  switch (ic) {
  case 1:
    k = find_equiv_type(potential_types[0]);
    if (k > -1) memcpy(equiv_types[0],equivalence.data[k].ff_types[1],5);
    break;

  case 2:
    for (i=0; i < 2; i++) {
      k = find_equiv_type(potential_types[i]);
      if (k > -1) memcpy(equiv_types[i],equivalence.data[k].ff_types[2],5);
    }
    break;
  case 3:
    for (i=0; i < 3; i++) {
      k = find_equiv_type(potential_types[i]);
      if (k > -1) memcpy(equiv_types[i],equivalence.data[k].ff_types[3],5);
    }
    break;
  case 4:
    for (i=0; i < 4; i++) {
      k = find_equiv_type(potential_types[i]);
      if (k > -1) memcpy(equiv_types[i],equivalence.data[k].ff_types[4],5);
    }
    break;

  case 5:
    for (i=0; i < 4; i++) {
      k = find_equiv_type(potential_types[i]);
      if (k > -1)
        memcpy(equiv_types[i],equivalence.data[k].ff_types[5],5);
    }
    break;
  default:
    printf(" Requesting equivalences of unsupported type: %d\n",ic);
    condexit(26);
    break;
  }
}

int find_equiv_type(char potential_type[5])
{
  int j,k,match;

  j = -1;
  k = 0;
  match = 0;

  while (!match && (k < equivalence.entries)) {
    if (strncmp(potential_type,
                equivalence.data[k].ff_types[0],5) == 0) {
      match = 1;
      j = k;
    } else {
      k++;
    }
  }
  if (j < 0)
    printf(" Unable to find equivalent type for %s\n",potential_type);
  return j;
}

int select_rows(int n, int count, char query[][5], struct FrcFieldData *data, int *reverse) {
  struct FrcFieldItem item = {0};
  item.entries = count;
  item.data = data;
  return find_match(n, query, item, reverse);
}

void map_rows(int role, int count, struct FrcFieldData *data, char query[][5], char output[][5]) {
  equivalence.entries = count;
  equivalence.data = data;
  get_equivs(role, query, output);
}
