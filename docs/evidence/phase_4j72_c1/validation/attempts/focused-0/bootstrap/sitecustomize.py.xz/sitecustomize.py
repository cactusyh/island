import os,sys
try:
 sys.path.insert(0,'/inspire/ssd/project/sais-suiren-foundation-model-prediction/public/yh/island')
 from scripts.phase_4j72_c1_fence import install
 install()
except BaseException as exc:
 os.write(2,('C1 fence startup failed: '+repr(exc)+'\n').encode())
 os._exit(97)
