import json
import os
import shutil
import sys
from pathlib import Path
from scripts.phase_4j72_c1_fence import assert_installed
from scripts.verify_phase_4j72_c1 import run

assert_installed()
output = Path('/tmp/island-j72-c1-validation/final-checks')
output.mkdir(exist_ok=False)
commands = [
 ('ruff', [shutil.which('ruff'), 'check', 'src', 'scripts', 'tests']),
 ('compileall', [sys.executable, '-m', 'compileall', '-q', 'src', 'scripts', 'tests']),
 ('diff', ['git', 'diff', '--check', 'HEAD']),
 ('offline-replay', [sys.executable, '-m', 'scripts.validate_phase_4j72_c1_receipt', 'docs/evidence/phase_4j72_c1', '--replay']),
]
results = []
for name, command in commands:
 result = {'name': name, **run(command, output / (name+'.log'), dict(os.environ))}
 results.append(result)
 (output/'checks.json').write_text(json.dumps(results, indent=2)+'\n')
 print(name, result['returncode'], flush=True)
raise SystemExit(int(any(r['returncode'] for r in results)))
