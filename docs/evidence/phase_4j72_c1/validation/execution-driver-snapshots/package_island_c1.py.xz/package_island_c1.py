import hashlib
import json
import lzma
import shutil
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

repo = Path.cwd()
source = Path('/tmp/island-j72-c1-validation')
root = repo / 'docs/evidence/phase_4j72_c1'
validation = root / 'validation'
attempts = validation / 'attempts'
attempts.mkdir(parents=True, exist_ok=True)
archives = {}

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def retain(path, target):
    data = path.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix in ('.xml', '.log', '.jsonl', '.py'):
        target = target.with_name(target.name + '.xz')
        target.write_bytes(lzma.compress(data, preset=6))
        archives[str(target.relative_to(root))] = {
            'compression': 'xz/lzma lossless original bytes',
            'uncompressed_sha256': hashlib.sha256(data).hexdigest(),
            'uncompressed_bytes': len(data),
            'original_execution_path': str(path),
        }
    else:
        target.write_bytes(data)
    return str(target.relative_to(root))

fenced = []
for path in sorted(source.iterdir()):
    if path.is_file():
        retain(path, attempts / path.name)
        continue
    if (path / 'policy.json').is_file():
        for child in sorted(path.iterdir()):
            if child.is_file():
                retain(child, attempts / path.name / child.name)
        for child in sorted((path / 'bootstrap').iterdir()):
            if child.is_file():
                retain(child, attempts / path.name / 'bootstrap' / child.name)
        fenced.append(str((attempts / path.name).relative_to(root)))
    else:
        # Keep only original coordinator outputs, not pytest scratch directories.
        for child in sorted(path.iterdir()):
            if child.is_file():
                retain(child, attempts / path.name / child.name)
for name in ('island-c1-smoke-0', 'island-c1-smoke-1'):
    path = Path('/tmp') / name
    for child in path.iterdir():
        if child.is_file():
            retain(child, attempts / name / child.name)
    for child in (path / 'bootstrap').iterdir():
        if child.is_file():
            retain(child, attempts / name / 'bootstrap' / child.name)
    fenced.append(str((attempts / name).relative_to(root)))

write(validation / 'fenced-runs.json', fenced)
write(validation / 'lossless-archives.json', archives)
shutil.copyfile(source / 'final-collection.json', root / 'collection.json')

def cases(path):
    return list(ET.parse(path).iter('testcase'))

def node(case):
    return case.attrib['classname'].replace('.', '/') + '.py::' + case.attrib['name']

def status(case):
    return next((k for k in ('error', 'failure', 'skipped') if case.find(k) is not None), 'passed')

correction = json.loads((source / 'corrections-2/results.json').read_text())
assert not correction['running']
assert set(correction['affected_files']) == {r['file'] for r in correction['results']}
assert all(r['returncode'] == 0 for r in correction['results'])
selection = {}
terminal = {}
for path in sorted((source / 'suite-2').glob('full-*.xml')):
    for case in cases(path):
        n = node(case)
        selection[n] = f'validation/attempts/suite-2/{path.name}.xz'
        terminal[n] = status(case)
for result in correction['results']:
    path = source / 'corrections-2' / (Path(result['file']).stem + '.xml')
    expected = {n for n in selection if n.split('::')[0] == result['file']}
    actual = {node(c) for c in cases(path)}
    assert actual == expected, (result['file'], actual ^ expected)
    for case in cases(path):
        n = node(case)
        selection[n] = f'validation/attempts/corrections-2/{path.name}.xz'
        terminal[n] = status(case)
for n in list(selection):
    if n.startswith('tests/test_phase_4j72_c1.py::'):
        selection.pop(n)
        terminal.pop(n)
for case in cases(source / 'focused-5.xml'):
    n = node(case)
    selection[n] = 'validation/attempts/focused-5.xml.xz'
    terminal[n] = status(case)
collection = json.loads((root / 'collection.json').read_text())['nodes']
assert set(selection) == set(collection) and len(selection) == 5978
counts = Counter(terminal.values())
assert not counts['failure'] and not counts['error']
write(validation / 'terminal-selection.json', selection)
write(validation / 'terminal-summary.json', {
    'unique_collected_nodes': len(collection),
    'counts': dict(counts),
    'complete_corrected_files': correction['affected_files'],
    'focused_C1_tests': 145,
    'focused_terminal_source': 'validation/attempts/focused-5.xml.xz',
    'selection_rule': 'Original unaffected cases; entire corrected files for every file containing an initial failure/error; entire final C1 focused file. No overlapping rerun increases unique coverage.',
    'scope_skips_are_not_scientific_verification': True,
})
notes = {
    'island-c1-smoke-0': 'Initial decoder failure denied execution, then ptrace resume after kill raised ProcessLookupError. Return 1. Original tool traceback was not redirected; available event ledger preserved. No scientific execution.',
    'island-c1-smoke-1': 'Corrected parent/child smoke passed.',
    'focused-0': '142 passed, 2 bookkeeping failures: list of row instances compared directly with 378. Corrected to compare its length.',
    'focused-1': '144 passed; overlapping focused rerun.',
    'focused-2': '145 passed; overlapping focused rerun.',
    'focused-3': '145 passed; Python 3.10 and child scope classification checks included.',
    'focused-4': '145 passed; losslessly compressed ledger replay added.',
    'focused-5': '145 passed; final whole-file focused controls include fake Python LAMMPS import blocking and compressed ledger replay. No real LAMMPS module is imported.',
    'final-collection-fence': 'Final collect-only inventory retains exactly 5978 unique nodes after the fake-module case is renamed from xtb to lammps.',
    'suite-0-fence': 'Collection stopped with 15 errors; SWIG registration hook was overbroad. No scientific fixture launched.',
    'checks-0-fence': 'Missing PATH candidates for Git were rejected; overly broad ruff check . linted archived evidence. Original failures retained.',
    'suite-1-fence': 'Deliberately interrupted by SIGTERM, launcher shell exit 143, before integrator restore/clone hardening. EXITKILL terminated descendants; no replacement of original logs.',
    'checks-1-fence': 'Interrupted with suite-1; shell exit 143.',
    'suite-2-fence': 'All 5978 unique nodes ran under inherited kernel/Python fence. Four raw shard return codes 1. Historical adapters swallowed scope exceptions or wrapped them, causing software assertion/setup failures. Every affected historical file rerun in full after explicit scope-skip correction. Raw failures retained.',
    'checks-2-fence': 'J54-J72 receipts and supported checks passed except legacy Python 3.10 fence startup failed on datetime.UTC; return 97 before scientific fixture. Bootstrap compatibility corrected and pip rerun successfully.',
    'correction-0-fence': 'J55 whole-file diagnostic: 63 passed, 10 skipped, 1 failed because CLI explicitly requested live OpenMM runtime. That parameter is now an explicit scope skip.',
    'correction-1-fence': 'J41-C2 whole-file diagnostic: 34 passed, 1 scope skip. Overlap only; not additional terminal coverage.',
    'corrections-2-fence': 'All 29 affected historical files rerun in full; every return code 0. Scope rejections bypass application Exception handlers; descendant rejection output retained then parent scope-skipped.',
    'pip-legacy-final': 'Corrected Python 3.10 fence bootstrap; pip check passed.',
    'offline-replay-0': 'Fresh-process offline evidence reconstruction passed.',
    'quarantine-crosscheck-0': 'All 192 available original files exactly match quarantine; no unarchived or missing files.',
    'reconstruction-0': 'Independent quarantine and exclusion reports reconstructed without scientific execution.',
}
history = []
for name, explanation in notes.items():
    p = source / name
    if not p.exists(): p = Path('/tmp') / name
    entry = {'run': name, 'explanation': explanation, 'retained_directory': f'validation/attempts/{name}'}
    if (p / 'result.json').exists():
        entry['recorded_result'] = json.loads((p / 'result.json').read_text())
    xml = source / (name.removesuffix('-fence') + '.xml')
    if xml.exists(): entry['raw_testcase_status_counts'] = dict(Counter(status(c) for c in cases(xml)))
    history.append(entry)
write(validation / 'attempt-history.json', {
    'no_failed_attempt_overwritten': True,
    'all_new_scientific_execution_forbidden': True,
    'attempts': history,
    'initial_raw_shards': {p.name: dict(Counter(status(c) for c in cases(p))) for p in sorted((source/'suite-2').glob('full-*.xml'))},
    'source_snapshot': 'validation/attempts/fence-runtime-used-by-suite-2.py.xz',
})
checks = json.loads((source / 'checks-2/checks.json').read_text())
for check in checks:
    check['log'] = f"validation/attempts/checks-2/{check['log']}.xz"
    check['fence'] = 'validation/attempts/checks-2-fence'
    if check['name'] == 'pip-md_rg':
        check.update(json.loads((source/'pip-legacy-final/result.json').read_text()))
        check['log'] = 'validation/attempts/pip-legacy-final.log.xz'
        check['fence'] = 'validation/attempts/pip-legacy-final'
        check['correction'] = 'Earlier Python 3.10 startup failure retained in checks-2.'
        check.pop('runtime_seconds', None)
result = json.loads((source/'offline-replay-0/result.json').read_text())
checks.append({'name':'offline-replay', **result, 'log':'validation/attempts/offline-replay-0.log.xz', 'fence':'validation/attempts/offline-replay-0'})
write(validation/'checks.json', checks)
print(json.dumps({'terminal':dict(counts), 'unique':len(selection), 'fenced_runs':len(fenced), 'corrected_whole_files':len(correction['results']), 'checks':len(checks)},sort_keys=True))
# Final current-code checks replace earlier overlapping successes by name.
final_checks = json.loads((source/'final-checks/checks.json').read_text())
by_name = {c['name']: c for c in checks}
for check in final_checks:
    check['log'] = 'validation/attempts/final-checks/' + check['log'] + '.xz'
    check['fence'] = 'validation/attempts/final-checks-fence'
    by_name[check['name']] = check
write(validation/'checks.json', [by_name[k] for k in sorted(by_name)])
for path in (Path('/tmp/package_island_c1.py'), Path('/tmp/island_c1_final_checks.py')):
    retain(path, validation/'execution-driver-snapshots'/path.name)
p = Path('/tmp/island-c1-audit-preseal-0')
for child in p.iterdir():
    if child.is_file(): retain(child, attempts/p.name/child.name)
for child in (p/'bootstrap').iterdir():
    if child.is_file(): retain(child, attempts/p.name/'bootstrap'/child.name)
retain(p.with_name(p.name+'.log'), attempts/(p.name+'.log'))
fenced.append(str((attempts/p.name).relative_to(root)))
write(validation/'fenced-runs.json', fenced)
write(validation/'lossless-archives.json', archives)
# Preserve detailed skip reasons separately from passed software checks.
skips = Counter()
for source_path in set(selection.values()):
    data = lzma.decompress((root/source_path).read_bytes())
    for case in ET.fromstring(data).iter('testcase'):
        if selection.get(node(case)) == source_path and case.find('skipped') is not None:
            message = case.find('skipped').attrib.get('message', '')
            skips['C1 execution scope' if 'C1 scope' in message else message] += 1
write(validation/'skip-reasons.json', dict(skips))
print('Final checks, packaging source and pre-seal audit retained.')
p = Path('/tmp/island-c1-independent-relocation-0')
for child in p.iterdir():
    if child.is_file(): retain(child, attempts/p.name/child.name)
for child in (p/'bootstrap').iterdir():
    if child.is_file(): retain(child, attempts/p.name/'bootstrap'/child.name)
retain(p.with_name(p.name+'.log'), attempts/(p.name+'.log'))
fenced.append(str((attempts/p.name).relative_to(root)))
write(validation/'fenced-runs.json', fenced)
write(validation/'lossless-archives.json', archives)
history_file = validation/'attempt-history.json'
history = json.loads(history_file.read_text())
for name, explanation in (
    ('final-checks-fence', 'Current implementation Ruff, compileall, staged diff checks and offline replay all returned 0.'),
    ('island-c1-audit-preseal-0', 'Independent full pre-seal audit verified unique terminal selection, all historical hashes and the entire recorded execution ledger.'),
    ('island-c1-independent-relocation-0', 'Fresh root launcher installs its own fence from copied repository code, then reconstructs pristine relocated scientific inputs without the original repository path. Passed; no new science.'),
):
    p = source/name if (source/name).exists() else Path('/tmp')/name
    history['attempts'].append({'run':name, 'explanation':explanation, 'retained_directory':f'validation/attempts/{name}', 'recorded_result':json.loads((p/'result.json').read_text())})
write(history_file,history)
print('Independent relocated launcher/replay retained.')
