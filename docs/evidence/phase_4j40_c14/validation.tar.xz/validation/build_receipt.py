"""Package frozen C14 implementation and additive evidence after completed gates."""
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
from scripts.phase_4j40_c11_numeric import sha,signed,write
from scripts.phase_4j40_c14 import build_report

root=Path('/tmp/j40-c14-validation');v=root/'validation';out=Path('docs/evidence/phase_4j40_c14');out.mkdir(parents=True,exist_ok=True)
commit=(v/'implementation-commit.txt').read_text().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
sources=['src/island/analysis/backend_readiness.py','scripts/phase_4j40_c14.py','scripts/validate_phase_4j40_c14_receipt.py','tests/test_phase_4j40_c14.py','docs/phase_4j40_c14.md']
for name in sources:
 raw=subprocess.check_output(['git','show',commit+':'+name]);assert hashlib.sha256(raw).hexdigest()==sha(name),name
 p=v/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
report=json.loads((root/'comparison-report.json').read_text());assert report==build_report(Path('docs/evidence/phase_4j40_c13'))
checks={}
for name in ('focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum'):
 r=json.loads((v/(name+'-command.json')).read_text());assert r['exit_code']==0,(name,r)
 assert r['tested_implementation_commit']==commit,(name,'not frozen source')
 checks[name]=r
counts={}
for mode in ('focused','regressions','full'):
 suites=ET.parse(v/(mode+'.xml')).getroot().findall('testsuite')
 counts[mode]={k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
assert json.loads((v/'c13-revalidation.json').read_text())=={'integrity_exit_code':0,'scientific_acceptance_exit_code':1,'rows_reconstructed':108}
history=json.loads((v/'historical-hashes.json').read_text());assert all(sha(p)==h for p,h in history.items())
write(v/'frozen-source.json',{'tested_implementation_commit':commit,'files':{n:sha(n) for n in sources},'all_tested_and_packaged_sources_match_commit':True})
write(v/'report-command.json',{'argv':['../island-validation/phase4e2-env/bin/python','-m','scripts.phase_4j40_c14','--source','docs/evidence/phase_4j40_c13','--output','/tmp/j40-c14-validation/comparison-report.json'],'exit_code':1,'software_result':'report generated and reconstructed successfully','scientific_acceptance':'blocked','tested_implementation_commit':commit})
shutil.copyfile(root/'comparison-report.json',out/'comparison-report.json')
with tarfile.open(out/'validation.tar.xz','w:xz',preset=6) as t:
 for p in sorted(v.iterdir()):
  if p.is_file() and p.suffix in ('.json','.log','.xml','.txt','.py'):t.add(p,arcname='validation/'+p.name)
 t.add(v/'source',arcname='validation/source')
manifest=signed({'schema':'island.j40-c14-manifest.v1','files':{n:sha(out/n) for n in ('comparison-report.json','validation.tar.xz')},'historical_files':history,'implementation_files':{n:sha(n) for n in sources}})
write(out/'manifest.json',manifest)
receipt=signed({'schema':'island.j40-c14-receipt.v1','base_commit':'4633e89936c5a9c4264828c316ef52de191c645d','tested_implementation_commit':commit,'manifest_sha256':sha(out/'manifest.json'),'report_identity':report['identity'],'source_counts':{k:report[k] for k in ('native_evaluations','comparison_count','passing_comparisons')},'backend_states':{c['cell']:c['decision'] for c in report['cells']},'new_qualified_equivalence_policy':None,'scientific_acceptance_exit_code':1,'production_validated':False,'simulation_readiness':'not_established','new_md_execution':'not_executed','historical_byte_hashes_preserved':len(history),'tests':counts,'checks':{k:{'argv':r['argv'],'exit_code':r['exit_code'],'tested_implementation_commit':r['tested_implementation_commit']} for k,r in checks.items()},'c13_raw_revalidation':json.loads((v/'c13-revalidation.json').read_text()),'limitations':['Backend policy checks caller-verified evidence scope and bindings, not the scientific truth of arbitrary assertions','C13 native and explicitly completed composite remain distinct','OpenMM pressure, internal-force, sampling and continuation gates are not qualified for a new long protocol','Scientific NPT, equilibrium and production readiness are not established'],'evidence_references':['comparison-report.json','manifest.json','validation.tar.xz']})
write(out/'receipt.json',receipt)
print(json.dumps({'tests':counts,'source_counts':receipt['source_counts'],'preserved_historical_hashes':len(history),'tested_implementation_commit':commit},indent=2),flush=True)
