"""Exercise intact and mutated C14 receipt/manifest validation before packaging."""
import copy,json,shutil,tarfile,tempfile
from pathlib import Path
from scripts.phase_4j40_c11_numeric import sha,signed,write
from scripts.validate_phase_4j40_c14_receipt import validate
root=Path('/tmp/j40-c14-validation');p=Path('/tmp/j40-c14-preflight');p.mkdir(exist_ok=True)
shutil.copyfile(root/'comparison-report.json',p/'comparison-report.json')
with tarfile.open(p/'validation.tar.xz','w:xz') as t:t.add(root/'validation/implementation-commit.txt',arcname='preflight-only.txt')
sources=['src/island/analysis/backend_readiness.py','scripts/phase_4j40_c14.py','scripts/validate_phase_4j40_c14_receipt.py','tests/test_phase_4j40_c14.py','docs/phase_4j40_c14.md']
history=json.loads((root/'validation/historical-hashes.json').read_text())
manifest=signed({'schema':'island.j40-c14-manifest.v1','files':{n:sha(p/n) for n in ('comparison-report.json','validation.tar.xz')},'historical_files':history,'implementation_files':{n:sha(n) for n in sources}});write(p/'manifest.json',manifest)
r=json.loads((p/'comparison-report.json').read_text())
receipt=signed({'schema':'island.j40-c14-receipt.v1','manifest_sha256':sha(p/'manifest.json'),'report_identity':r['identity'],'source_counts':{k:r[k] for k in ('native_evaluations','comparison_count','passing_comparisons')},'backend_states':{c['cell']:c['decision'] for c in r['cells']},'scientific_acceptance_exit_code':1,'production_validated':False,'simulation_readiness':'not_established','historical_byte_hashes_preserved':len(history)})
write(p/'receipt.json',receipt)
result={'intact':validate(p),'negative_controls':[]}
for key,value in [('schema','forged'),('production_validated',True),('simulation_readiness','established'),('scientific_acceptance_exit_code',0),('source_counts',{}),('backend_states',{})]:
 mutated=copy.deepcopy(receipt);mutated[key]=value;write(p/'receipt.json',signed(mutated))
 try:validate(p)
 except ValueError as error:result['negative_controls'].append({'mutation':key,'rejected':True,'reason':str(error)})
 else:raise AssertionError('Accepted mutated receipt: '+key)
write(p/'receipt.json',receipt)
write(root/'validation/receipt-preflight.json',result)
print(json.dumps(result,indent=2))
