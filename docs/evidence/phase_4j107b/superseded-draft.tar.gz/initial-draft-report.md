# J107B：有来源支持的化学环境覆盖扩展

从 J107A `bfaeefb` 新建 `codex/j107b-chemical-coverage`。本阶段目标是补充可追溯的 OPLS 环境并建立 GAFF/GAFF2 完整图小型覆盖基线，不宣称整个参数库已覆盖任意 PSMILES。

## OPLS polymer-v2 profile

新增显式 `opls-polymer-v2` profile。它从固定的 2024 OPLS-AA 来源复制参数文件，仅在 `opls-aa.top` 增加规则：

- ETCL、ETBR、ETIO 的卤代烷碳环境；
- MEAN、DMAN、TMAN 的脂肪胺碳/氢环境；
- ANIS 及支化芳醚环境。

规则使用来源库已有的类型、质量、电荷、LJ、键角和增量；profile manifest 记录来源 residue，且 `numerical_parameters_changed=false`。PCFF 参数文件和 OPLS 原始 profile 未修改。

```bash
python -m island.forcefields.emc_profiles opls-polymer-v2 work/opls-polymer-v2
python scripts/validate_j107b_coverage.py work/j107b-checks \
  --field-dir work/opls-polymer-v2
```

8 个源 residue 的类型/电荷与 `.define` 对照通过；5 个留出模型（支化氯代烷、支化溴代烷、叔胺、支化芳醚、仲酰胺）全部通过完整图分配。留出模型不参与规则生成。

## GAFF/GAFF2 完整图基线

`validate_gaff_graph_coverage.py` 对 PE、PP 手性链、PEG、PET、PA6、cis-二烯、支化醚、含氟链、含氯链和芳醚共 10 个模型分别测试 GAFF 与 GAFF2。当前环境下两者均为 **10/10**，使用 Gasteiger 电荷；这只是常见结构小面板，不等同于 RadonPy 的 1,077/1,077 参考分母，也不覆盖量化电荷、交联网络或任意杂环。

## 验证

- J107B 新测试 **5 passed**；其中 profile 安装、8 个源模型/5 个留出模型、GAFF/GAFF2 各 10 个完整图模型和未知 profile 拒绝均通过。
- J107A 及前序回归另行保留；J107A 的 120 项最终测试仍作为上游基线。
- profile 不添加通用零参数或近似参数；未覆盖环境继续返回原生缺项。

## 当前缺口与后续

OPLS 的含磷、硫氧化物、离子、复杂芳香氮和部分电荷增量仍需按来源 residue 分批扩展。每次扩展都应包括源模型、跨接点模型和留出模型；不能只用规则命中数增加成功率。GAFF/GAFF2 下一步应扩大到 982 条固定输入的完整图重测，并覆盖嵌段、支链、交联图及 RESP/ESP 电荷协议。

证据见 [J107B 目录](evidence/phase_4j107b/)。
