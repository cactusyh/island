# J107B 证据

- `opls-polymer-v2-checks.json`：8 个源 residue 与 5 个留出结构。
- `native-source-models.json`：独立源残基类型/电荷对照。
- `gaff-graph-coverage.json`：GAFF/GAFF2 各 10 个完整图模型。
- `profile-install.log`：profile 安装输出和来源变更标记。
- `j107b-tests.log`：J107B 测试日志。

结果均使用固定来源文件和完整图入口；没有把 profile 安装或预检当作参数质量证明。MD、平衡和物性验证不属于本阶段。
