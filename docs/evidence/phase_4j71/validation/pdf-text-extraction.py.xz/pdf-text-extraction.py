from pathlib import Path
from pypdf import PdfReader
import json,hashlib,traceback
out=Path('/tmp/island-j71-validation/text');out.mkdir(exist_ok=True)
rows=[];seen={}
for p in sorted(Path('island_ffref/pcff').rglob('*.pdf')):
 sha=hashlib.sha256(p.read_bytes()).hexdigest()
 if sha in seen:
  rows.append({'path':str(p),'sha':sha,'byte_identical_to':seen[sha]});continue
 seen[sha]=str(p)
 try:
  r=PdfReader(p);pages=[]
  for i,page in enumerate(r.pages):
   t=page.extract_text(extraction_mode='layout');pages.append(t)
   (out/f'{sha[:12]}-page-{i+1:02}.txt').write_text(t)
  (out/f'{sha[:12]}-all.txt').write_text('\n'.join(f'===== PDF PAGE {i+1} =====\n{t}' for i,t in enumerate(pages)))
  row={'path':str(p),'sha':sha,'pages':len(pages),'chars':[len(t) for t in pages],'page_text_sha256':[hashlib.sha256(t.encode()).hexdigest() for t in pages],'metadata':{str(k):str(v) for k,v in (r.metadata or {}).items()}}
 except Exception as e: row={'path':str(p),'sha':sha,'error':str(e)}
 rows.append(row);print(json.dumps(row),flush=True)
Path('/tmp/island-j71-validation/extraction.json').write_text(json.dumps(rows,indent=2)+'\n')
