import json,hashlib,re,sys,zipfile
from pathlib import Path
sys.path.insert(0,'/tmp/island-j71-validation/fitz126')
import pymupdf as fitz
R=Path.cwd(); E=R/'docs/evidence/phase_4j71'; E.mkdir(exist_ok=True)
inv=json.load(open(E/'source-inventory.json'))
def dump(n,x):(E/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
# Metadata established by complete reading, not by filename.
meta={
'65bda3a5b14c':('Sun & Rigby 1997','Polysiloxanes: ab initio force field and structural, conformational and thermophysical properties','H. Sun; D. Rigby','Spectrochimica Acta A 53 (1997) 1301–1323','10.1016/S1386-1425(97)00013-9','PCFF','all_atom','siloxanes, silanes, silanols','Appendix pp21–22; equations pp2–3; trans=180 degrees p16; no siloxane AA/EBT/MBT/AT/AAT numerical table'),
'9c6d6315b91e':('Sun 1995','Ab Initio Calculations and Force Field Development for Computer Simulation of Polysilanes','H. Sun','Macromolecules 28 (1995) 701–712','10.1021/ma00107a006','PCFF','all_atom','polysilanes, Si–Si backbone; PDMS here means poly(dimethylsilane)','Table5 p4; Appendix p11; equations p3; not PDMS siloxane'),
'00b279decf05':('Sun 1994','Force field for computation of conformational energies, structures, and vibrational frequencies of aromatic polyesters','H. Sun','Journal of Computational Chemistry 15 (1994) 752–768',None,'CFF93','all_atom','aromatic polyesters','Tables and equations address aromatic carbonyl/ester environments, not Si/O siloxane missing couplings'),
'ac85e79667e1':('Sun et al. 1994','An ab Initio CFF93 All-Atom Force Field for Polycarbonates','H. Sun; S. J. Mumby; J. R. Maple; A. T. Hagler','JACS 116 (1994) 2978–2987','10.1021/ja00086a030','CFF93','all_atom','polycarbonates','Class-II equations and carbonate parameters are not siloxane source rows'),
'9a62dafe2236':('Sun 1998','COMPASS: An ab Initio Force-Field Optimized for Condensed-Phase Applications—Overview with Details on Alkane and Benzene Compounds','H. Sun','J. Phys. Chem. B 102 (1998) 7338–7364',None,'COMPASS','all_atom','alkanes, benzene; generic atom-type inventory includes Si','p2 explicitly distinguishes PCFF/CFF93 from COMPASS; AppendixB pp24–25 hydrocarbon parameters; no native compatibility contract'),
'ee8614dcf423':('Sun, Ren & Fried 1998','The COMPASS force field: parameterization and validation for phosphazenes','H. Sun; P. Ren; J. R. Fried','Computational and Theoretical Polymer Science 8 (1998) 229–246',None,'COMPASS','all_atom','phosphazenes','P/N/organic substituent parameters and validation, no Si/O Class-II authority'),
'f9277e1c608f':('Rigby, Sun & Eichinger 1997','Computer simulations of poly(ethylene oxide): force field, pvt diagram and cyclization behaviour','D. Rigby; H. Sun; B. E. Eichinger','Polymer International 44 (1997) 311–330',None,'PCFF_related','all_atom','ethers and alcohols, PEO','Appendix pp17–20; ether o2e/hydroxyl o2h, not siloxane osi; filename year 1999 disagrees with printed 1997'),
'c518da36d84d':('Patil & Mark 2000','Evaluations of forcefields for aromatic polysiloxanes, and some applications to poly(diphenylsiloxane)','R. D. Patil; J. E. Mark','Computational and Theoretical Polymer Science 10 (2000) 189–195',None,'PCFF_COMPASS_comparison','all_atom','aromatic polysiloxanes','pcff2 named COMPASS1.0; Tables1–4 crystal/RIS/output quantities, no new force-constant table'),
'a1415925e044':('Smith, Borodin & Smith 2004','A Quantum Chemistry Based Force Field for Poly(dimethylsiloxane)','J. S. Smith; O. Borodin; G. D. Smith','J. Phys. Chem. B 108 (2004) 20340–20350','10.1021/jp047434r','Smith2004_PDMS','all_atom','PDMS oligomers and melts','Table3 p3 charges; Table4 p5 complete bonded/nonbonded model; exp6, half 1–4, sine-squared torsion/bend modulation; not PCFF'),
'04ecee672431':('Xiang et al. 2025','Force-Field Benchmark for Polydimethylsiloxane: Density, Heat Capacity, Isothermal Compressibility, Viscosity and Thermal Conductivity','Z. Xiang; C. Gao; T. Long; L. Ding; T. Zhou; Z. Wu','J. Phys. Chem. B 129 (2025) 1864–1873','10.1021/acs.jpcb.4c08471','multiple_benchmark','mixed','PDMS','SI TablesS1–S5 are parameter source; ref22 explicitly associates github.com/COMO-lab/PDMS_benchmark (2024; accessed 2025-01-11); plotted charges not digitized'),
'6e86aa640854':('Xiang et al. 2025 SI','Supporting Information: Force-Field Benchmark for Polydimethylsiloxane','Z. Xiang; C. Gao; T. Long; L. Ding; T. Zhou; Z. Wu','J. Phys. Chem. B (2025) Supporting Information','10.1021/acs.jpcb.4c08471','multiple_benchmark','mixed','PDMS','14 pages; S1 UA p2; S2 HUANG p3; S3 COMPASS pp4–5; S4 OPLS p6; S5 Dreiding p7; SI label/order/command conflicts retained'),
'a8a4961f8c1b':('Bunte & Sun 2000','Molecular Modeling of Energetic Materials: The Parameterization and Validation of Nitrate Esters in the COMPASS Force Field','S. W. Bunte; H. Sun','J. Phys. Chem. B 104 (2000) 2477–2489','10.1021/jp991786u','COMPASS','all_atom','nitrate esters','Nitrate oxygen environments, no Si/O siloxane parameter source'),
'5372747c08f6':('Jorge et al. 2021','New Force-Field for Organosilicon Molecules in the Liquid Phase','M. Jorge; A. W. Milne; M. C. Barrera; J. R. B. Gomes','ACS Physical Chemistry Au 1 (2021) 54–69','10.1021/acsphyschemau.1c00014','PolCA','united_atom','alkylsilanes, silanols, alkoxysilanes and siloxanes','Tables1–2 p6 charges;3–4 p7 bonds/angles;5 p8 RB;6 p9 LJ; no aliphatic H sites; OH–H length printed 0.945 nm retained unresolved'),
'1e95027a1202':('Jorge et al. 2021 SI','Supporting Information: PolCA organosilicates','M. Jorge; A. W. Milne; M. C. Barrera; J. R. B. Gomes','ACS Physical Chemistry Au (2021) Supporting Information','10.1021/acsphyschemau.1c00014','PolCA','united_atom','organosilicates','76 pages; raw experimental/property tables S1–S71; S3 geometry discussion pp48–49; S4 torsion fits; S72 p65 repeated RB coefficients; S5 diffusion and final references'),
'451cf754daab':('Jorgensen et al. 1996 SI','Supporting Information: Development and Testing of the OPLS All-Atom Force Field on Conformational Energetics and Properties of Organic Liquids','W. L. Jorgensen; D. S. Maxwell; J. Tirado-Rives','JACS 118 (1996) Supporting Information','10.1021/ja9621760','OPLS','all_atom','organic liquids, no Si','13 scanned pages read manually from rendered pages without OCR; cover plus 12 SI pages; main paper absent; Table6 compares AMBER/CHARMM, not native OPLS')}
meta['7f9f328bea7d']=meta['a8a4961f8c1b']
readings=[];seen={}
for f in inv['files']:
 s=f['sha256']; short=s[:12]; r=dict(f)
 if short in meta:
  m=meta[short];r.update(citation=m[0],title=m[1],authors=m[2],journal_year=m[3],doi=m[4],force_field=m[5],resolution=m[6],chemical_domain=m[7],reading_findings=m[8])
  pdf=fitz.open(f['relative_path']);r.update(page_count=len(pdf),page_coverage=list(range(1,len(pdf)+1)),full_text_present=not short=='451cf754daab',supplementary_information_present=short in ('6e86aa640854','1e95027a1202','451cf754daab') or short in ('04ecee672431','5372747c08f6'),actually_read_successfully=True,read_mode='manual_rendered_no_OCR' if short=='451cf754daab' else 'complete_text_reading_with_manual_table_checks',page_content_sha256=[hashlib.sha256(p.get_text().encode()).hexdigest() for p in pdf])
  r['full_text_kind']='supporting_information_only_main_absent' if short=='451cf754daab' else ('complete_supporting_information' if short in ('6e86aa640854','1e95027a1202') else 'complete_main_paper')
  if s in seen:r.update(read_mode='byte_identical_copy_of_read_document',duplicate_of=seen[s])
  if short=='7f9f328bea7d':r.update(read_mode='content_duplicate_separate_hash',content_duplicate_of='a8a4961f8c1b036c0fb66e211dc08f7a5cd6ccfc57721cf533b1eace9e22e250')
  seen[s]=f['relative_path']
 elif short=='d5ef1c3e962f':r.update(title=meta['9c6d6315b91e'][1],authors=meta['9c6d6315b91e'][2],journal_year=meta['9c6d6315b91e'][3],doi=meta['9c6d6315b91e'][4],actually_read_successfully=False,full_text_present=False,supplementary_information_present=False,reading_status='unreadable_truncated_checkpoint',error='Stream has ended unexpectedly',page_coverage=[])
 else:r.update(title='PDMS benchmark associated parameter archive' if 'benchmark' in f['relative_path'] else 'LAMMPS-pcff engineering archive',authors='COMO-lab' if 'benchmark' in f['relative_path'] else 'archive authors; not original PCFF authors',journal_year='archived local version; upstream commit unavailable',doi=None,full_text_present=False,supplementary_information_present=True,actually_read_successfully=False,read_mode='member_inventory_and_selected_applicable_parameter_rows; not a paper',license_access_status='no redistribution license located in archive')
 if short in ('04ecee672431','5372747c08f6'):r['license_access_status']='printed_CC_BY_4.0; full paper retained externally anyway'
 readings.append(r)
dump('reading-status.json',{'schema':'island.j71-reading-ledger.v1','frozen_inventory_sha256':hashlib.sha256((E/'source-inventory.json').read_bytes()).hexdigest(),'files':readings,'OCR_used':False,'full_text_committed':False,'reading_agent':'Codex J71; page-complete reading in this session','prior_review':'J54 105 source rows compared after fresh J71 full reading; original producer preserved'})
# Capture compact numeric rows, never whole papers.
rows=[];docs={s:fitz.open(f['relative_path']) for s in meta for f in inv['files'] if f['sha256'].startswith(s) and '.ipynb_checkpoints' not in f['relative_path']}
def loc(src,page,table,label,raw=None,bbox=None):
 p=docs[src][page-1]; hits=p.search_for(label.replace('−','-')) or p.search_for(label)
 box=bbox or ([round(v,3) for v in hits[0]] if hits else None)
 return {'pdf_page':page,'printed_page':None,'table':table,'equation':'see source contract','row_label':label,'bbox_pdf_points':box,'cell_coordinates':'column index in fields, 1-based; row identified by label; bbox uses PDF points' ,'raw_snippet':raw or label}
def add(src,fam,sites,fields,values,units,page,table,raw=None,bbox=None,**extra):
 rows.append({'source':src,'family':fam,'ordered_sites':sites,'fields':fields,'raw_values':values,'raw_units':units,'location':loc(src,page,table,'-'.join(sites),raw,bbox),**extra})
old=json.load(open('docs/evidence/sun_siloxane_parameters/parameters.json'))
for r in old['rows']:
 src=old['sources'][r['source']]['sha256'][:12]; evidence=r['source_evidence']; label=r['labels'];sites=label.replace('/','/').split('-')
 add(src,r['family'],sites,r['fields'],r['original_values'],r['source_units'],evidence['pdf_page'],evidence['location'],evidence['raw_pdf_text'],evidence['bbox_pdf_points'],historical_comparison_id=r['id'],blank_fields=r['missing_fields'],manual_numeric_review='J71 checked Appendix renders and equation definitions; Sun1995 Si-C=1.899, Sun1997 Si4 epsilon=0.198; no OCR inference')
# Smith Table4, raw blank cells stay null.
src='a1415925e044'
for s,vs in {'Si-Si':['50326','2.846','3085.3'],'Si-O':['61781','3.454','1109.4'],'Si-C':['24753','2.968','1406.1'],'O-O':['75844','4.063','398.9'],'O-C':['33702','3.577','505.6'],'O-H':['14177','3.902','104.5'],'C-C':['14967','3.090','640.8'],'C-H':['6300','3.415','132.5'],'H-H':['2650','3.740','27.4']}.items():add(src,'exp6',s.split('-'),['A','B','C'],vs,['kcal/mol','angstrom^-1','kcal*angstrom^6/mol'],5,'Table4 nonbonded',raw=s+' | '+' | '.join(vs))
for s,vs in {'Si-O':['1.651','350','-517','674'],'Si-C':['1.878','190','-279','308'],'C-H':['1.092','328',None,None]}.items():add(src,'quartic_bond',s.split('-'),['r0','k2','k3','k4'],vs,['angstrom','kcal/(mol*angstrom^2)','kcal/(mol*angstrom^3)','kcal/(mol*angstrom^4)'],5,'Table4 bonds',raw=s+' | '+str(vs))
for s,vs in {'Si-O-Si':['137.63','10.305','-18.101','10.100'],'O-Si-O':['105.56','91.835',None,None],'O-Si-C':['109.82','23.022','-31.399','24.981'],'C-Si-C':['112.44','36.210','-20.390','20.020'],'Si-C-H':['111.09','28.770','-13.950',None],'H-C-H':['107.77','38.500',None,None]}.items():add(src,'quartic_angle',s.split('-'),['theta0','k2','k3','k4'],vs,['degree','kcal/(mol*radian^2)','kcal/(mol*radian^3)','kcal/(mol*radian^4)'],5,'Table4 bends',raw=s+' | '+str(vs))
for s,vs in {'Si-O-Si-O':['-0.41000','0.27319','0.21968'],'Si-O-Si-C':[None,None,'-0.05706'],'O-Si-C-H':[None,None,'-0.15000'],'C-Si-C-H':[None,None,'-0.15000']}.items():add(src,'smith_torsion',s.split('-'),['k1','k2','k3'],vs,['kcal/mol']*3,5,'Table4 torsions and footnote d',raw=s+' | '+str(vs))
# PolCA tables: united-atom context retained explicitly.
src='5372747c08f6'
for s,v in {'Si-C':'.1875','Si-OH':'.1653','Si-OC':'.1656','Si-OB':'.1640','C-C':'.154','C-OC':'.141','OH-H':'.945'}.items():add(src,'rigid_bond',s.split('-'),['r0'],[v],['nm'],7,'Table3',raw=s+' | '+v,extraction_issue='printed OH-H 0.945 nm; not silently corrected' if s=='OH-H' else None)
for s,vs in {'C-Si-C':['112.0','656.2'],'Si-C-C':['111.5','726.5'],'C-Si-OH':['107.4','774.6'],'Si-OH-H':['115.5','257.8'],'OH-Si-OH':['104.4','872.6'],'Si-OB-Si':['149.5','61.3'],'Si-OC-C':['124.8','298.1'],'C-Si-OC':['111.0','774.6'],'OC-Si-OC':['105.7','795.0'],'C-C-C':['114.0','519.7'],'OC-C-C':['112.0','418.2']}.items():add(src,'harmonic_angle',s.split('-'),['theta0','k'],vs,['degree','kJ/(mol*radian^2)'],7,'Table4',raw=s+' | '+' | '.join(vs))
polca=[('C-C-Si-C','1.224 3.672 0.0 -4.895 0.0 0.0'),('C-Si-OC-C','1.364 4.093 0.0 -5.457 0.0 0.0'),('C-C-Si-OC','0.692 2.456 0.437 -3.416 0.0 0.0'),('C-C-OC-Si','7.949 7.892 2.723 -18.563 0.0 0.0'),('C-OC-Si-OC','4.314 4.803 0.0 -0.489 0.0 0.0'),('C-Si-OH-H','0.870 2.600 0.0 -3.470 0.0 0.0'),('C-C-Si-OH','0.801 2.760 0.508 -3.615 0.0 0.0'),('OC-Si-OH-H','10.189 2.939 0.0 6.918 0.0 0.0'),('C-OC-Si-OH','13.021 0.350 -39.801 -25.132 39.605 31.769'),('OH-Si-OH-H','10.071 6.167 2.322 6.236 0.0 0.0'),('C-C-Si-OB','0.692 2.456 0.437 -3.416 0.0 0.0'),('C-OC-Si-OB','4.314 4.803 0.0 -0.489 0.0 0.0'),('C-Si-OB-Si','0.0503 0.151 0.0 -0.201 0.0 0.0'),('OC-Si-OB-Si','10.607 0.420 0.0 10.187 0.0 0.0'),('OB-Si-OB-Si','10.607 0.420 0.0 10.187 0.0 0.0'),('OH-Si-OB-Si','14.871 8.170 0.0 6.700 0.0 0.0')]
for s,v in polca:
 for so,pa,tab in [(src,8,'Table5'),('1e95027a1202',65,'TableS72')]:add(so,'RB_torsion',s.split('-'),['C'+str(i) for i in range(6)],v.split(),['kJ/mol']*6,pa,tab,raw=s+' | '+v)
for s,v in {'Si0':'.580 .108','Si1':'.551 .108','Si2':'.522 .108','Si3':'.493 .108','Si4':'.464 .108','OC':'.235 1.344','OB':'.235 1.344','OH':'.304 1.750'}.items():add(src,'LJ12_6',[s],['sigma','epsilon'],v.split(),['nm','kJ/mol'],9,'Table6',raw=s+' | '+v)
for s,v in {'CHx_Si_alkyl':'-.24','CH3_Si_O':'-.32','CH2_Si_O':'-.27','CHx_OC':'.25','OC':'-.68','OH':'-.88','H_OH':'.44','OB':'-.88'}.items():add(src,'charge',[s],['q'],[v],['elementary_charge'],6,'Table2',raw=s+' | '+v)
# SI command rows: all numeric model commands, no implicit padding of omitted terms.
si='6e86aa640854'; prefixes={'pair_coeff','bond_coeff','angle_coeff','dihedral_coeff','improper_coeff'}
for page in range(2,8):
 text=(Path('/tmp/island-j71-validation/text')/(si+f'-page-{page:02}.txt')).read_text(); model={2:'UA',3:'HUANG',4:'COMPASS',5:'COMPASS',6:'OPLS',7:'Dreiding'}[page]
 for line in text.splitlines():
  t=line.split()
  if t and t[0] in prefixes:
   skip=3 if t[0]=='pair_coeff' else 2
   if len(t)>skip and not re.fullmatch(r'[-+]?\d*\.?\d+',t[skip]):skip+=1
   vals=t[skip:]
   if not vals or not all(re.fullmatch(r'[-+]?\d*\.?\d+',v) for v in vals):continue
   label=t[1]+'-'+t[2] if t[0]=='pair_coeff' else t[1]
   rows.append({'source':si,'family':'LAMMPS_command','ordered_sites':label.split('_'),'fields':['column'+str(i+1) for i in range(len(vals))],'raw_values':vals,'raw_units':['LAMMPS_real_contract_pending']*len(vals),'location':loc(si,page,'TableS'+str({2:1,3:2,4:3,5:3,6:4,7:5}[page]),label,line.strip()),'model':model,'command':t[0],'substyle':t[skip-1] if skip>(3 if t[0]=='pair_coeff' else 2) else None,'printed_command':line.strip()})
# Every archive member hash; parse complete topology, then exact used coefficient IDs only.
archives=[]
for f in inv['files']:
 if f['file_type']!='zip':continue
 z=zipfile.ZipFile(f['relative_path']);members=[]
 for name in z.namelist():
  if name.endswith('/'):continue
  data=z.read(name);members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'reading_mode':'hashed_only' if name.endswith(('.charges','.data')) else 'read_commands_or_documentation' if len(data)<40000 else 'machine_parsed_all_lines; manually_reviewed_applicable_rows'})
 archives.append({'path':f['relative_path'],'sha256':f['sha256'],'members':members,'license':'no LICENSE member found; no grant inferred'})
 if 'benchmark' not in f['relative_path']:continue
 for model,stem in [('COMPASS','system'),('Dreiding','dr_system'),('OPLS','opls_system'),('HUANG','H_system'),('UA','UA_system')]:
  base='PDMS_benchmark-main/param/'+model+'/';data=z.read(base+stem+'.data').decode();bysec={};sec=None
  for line in data.splitlines():
   line=line.split('#')[0].strip()
   if not line:continue
   if line[0].isalpha():sec=line;bysec[sec]=[]
   elif sec is not None:bysec[sec].append(line.split())
  atoms={int(t[0]):t[2] for t in bysec['Atoms']}; top={};used={}
  for section,cmd in [('Bonds','bond_coeff'),('Angles','angle_coeff'),('Dihedrals','dihedral_coeff'),('Impropers','improper_coeff')]:
   used[cmd]={t[1] for t in bysec.get(section,[])}
   for t in bysec.get(section,[]):
    types=tuple(atoms[int(a)] for a in t[2:]);top.setdefault((cmd,t[1]),set()).add(types)
  used['pair_coeff']=set(atoms.values());setting=next(n for n in z.namelist() if n.startswith(base) and n.endswith(('.setting','.settings')))
  for line_no,line in enumerate(z.read(setting).decode().splitlines(),1):
   t=line.split('#')[0].split()
   if not t or t[0] not in used or t[1] not in used[t[0]]:continue
   if t[0]=='pair_coeff' and (t[2]!=t[1]):continue
   skip=3 if t[0]=='pair_coeff' else 2; sub=None
   if len(t)>skip and not re.fullmatch(r'[-+]?\d*\.?\d+(?:e[-+]?\d+)?',t[skip],re.I):sub=t[skip];skip+=1
   vals=t[skip:]
   if not vals or not all(re.fullmatch(r'[-+]?\d*\.?\d+(?:e[-+]?\d+)?',v,re.I) for v in vals):continue
   types=sorted(top.get((t[0],t[1]),{(t[1],t[2])} if t[0]=='pair_coeff' else set()))
   rows.append({'source':f['sha256'][:12],'family':'LAMMPS_command','ordered_sites':list(types[0]),'fields':['column'+str(i+1) for i in range(len(vals))],'raw_values':vals,'raw_units':['LAMMPS_real_contract_pending']*len(vals),'location':{'archive_member':setting,'member_sha256':hashlib.sha256(z.read(setting)).hexdigest(),'line':line_no,'row_label':t[1],'raw_snippet':line.strip(),'equation':'LAMMPS style bound in associated init file'},'model':model,'command':t[0],'substyle':sub,'archive_type_patterns':[list(x) for x in types],'topology_member':base+stem+'.data','topology_sha256':hashlib.sha256(z.read(base+stem+'.data')).hexdigest(),'printed_command':line.strip(),'style_source':z.read(base+stem+'.in.init').decode()})
dump('archive-members.json',{'schema':'island.j71-associated-archives.v1','archives':archives,'commands_executed':False})
# Explicit charge cells from the benchmark SI; no normalization.
for page in range(2,8):
 text=(Path('/tmp/island-j71-validation/text')/(si+f'-page-{page:02}.txt')).read_text(); model={2:'UA',3:'HUANG',4:'COMPASS',5:'COMPASS',6:'OPLS',7:'Dreiding'}[page]
 for line in text.splitlines():
  t=line.split()
  if len(t)==2 and t[0] in ('O','Si','C','H','CH3') and re.fullmatch(r'[-+]?\d*\.?\d+',t[1]):add(si,'charge',[t[0]],['q'],[t[1]],['elementary_charge'],page,'TableS'+str({2:1,3:2,4:3,5:3,6:4,7:5}[page]),raw=line.strip(),model=model)
for site,v in {'Si_end_methyl':'0.8376','O':'-0.5144','C':'-0.5284','H':'0.1117'}.items():add('a1415925e044','charge',[site],['q'],[v],['elementary_charge'],3,'Table3 HMDS column',raw=site+' HMDS '+v)
# Only directly printed C/H OPLS cells; manually read rendered SI, no OCR.
for site,v in {'C_methane':['-0.240','3.500','0.066'],'C_methyl':['-0.180','3.500','0.066'],'H_alkane':['0.060','2.500','0.030']}.items():add('451cf754daab','OPLS_nonbond',[site],['q','sigma','epsilon'],v,['elementary_charge','angstrom','kcal/mol'],3,'Table1 (printed SI2)',raw=site+' | '+' | '.join(v),extraction_mode='manual_rendered_no_OCR')
# Every field has a logical table-cell coordinate even when PDF text has no matching glyph boxes.
for r in rows:
 if 'pdf_page' in r['location']:
  r['location']['cell_coordinates']=[{'row':r['location']['row_label'],'column':k,'column_index':i+1} for i,k in enumerate(r['fields'])]
# Concrete contract anomalies; values never silently fixed.
for i,r in enumerate(rows):r['cell_id']=f'cell-{i:04d}'
dump('extraction-ledger.json',{'schema':'island.j71-reviewed-table-cells.v1','method':'fresh full document reading; native text extraction plus explicit manual table checks, no OCR; applicable archive rows selected by full static topology parsing','cells':rows,'source_resolution':'raw source cells; no values accepted as native PCFF'})
print('sources',len(readings),'cells',len(rows))
