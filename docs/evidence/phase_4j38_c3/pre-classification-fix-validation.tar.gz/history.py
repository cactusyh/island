import json
from scripts.validate_phase_4j38_c2_receipt import historical_hashes
from pathlib import Path
hashes=historical_hashes('3d298cccd7f430340c82d8e069f387a352e4f19b')
Path('/tmp/j38-c3-validation/final/historical-hashes.json').write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n')
print(json.dumps({'historical_tracked_docs_and_evidence_files':len(hashes),'byte_preservation':True,'json_readability':True}))
for name in hashes:
 if name.endswith('.json'):json.loads(Path(name).read_text())
