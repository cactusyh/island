import concurrent.futures,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/j44-validation');v=root/'validation';repo=Path.cwd();py=str((repo.parent/'island-validation/phase4e2-env/bin/python').resolve())
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
def run(name,argv,cwd=repo):
 start=time.time();commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
 with (v/(name+'.log')).open('w') as log:r=subprocess.run(argv,env=env,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=False)
 result={'argv':argv,'cwd':str(cwd),'environment':{k:env[k] for k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'tested_implementation_commit':commit,'exit_code':r.returncode,'elapsed_seconds':time.time()-start}
 (v/(name+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,r.returncode,flush=True)
 return result
if sys.argv[1]=='historical':
 code="from scripts.validate_phase_4j42_receipt import validate; import json; print(json.dumps(validate('docs/evidence/phase_4j42',repo='/tmp/j42-c1-validation/historical-base')))"
 code_c1="from scripts.validate_phase_4j42_c1_receipt import validate; import json; print(json.dumps(validate('docs/evidence/phase_4j42_c1')))"
 code_j43="from scripts.validate_phase_4j43_receipt import validate; import json; print(json.dumps(validate('docs/evidence/phase_4j43')))"
 jobs=[('receipt_j43',[py,'-c',code_j43],repo),('receipt_j42',[py,'-c',code],repo),('receipt_j42_c1',[py,'-c',code_c1],repo),('historical_byte_audit',[py,str(root/'historical_byte_audit.py')],repo)]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(lambda j:run(*j),jobs))
 assert all(r['exit_code']==0 for r in results)
 raise SystemExit(0)
if sys.argv[1]=='reconstruction':
 source=root/'final-study';target=root/'relocated-study-final';shutil.copytree(source,target)
 shutil.copytree(repo/'island_ffref',root/'relocated-references')
 result=run('relocation',[py,'scripts/phase_4j44.py','--reconstruct',str(target),'--references',str(root/'relocated-references')]);assert result['exit_code']==0
 def hashes(folder):return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
 a,b=hashes(source),hashes(target);assert a==b
 (v/'relocation-file-hashes.json').write_text(json.dumps({'identical_files':len(a),'files':a},indent=2)+'\n')
 raise SystemExit(0)
if sys.argv[1]=='regression_collection':
 files=[p for p in sorted(Path('tests').glob('test_phase_4j*.py')) if (m:=re.search(r'4j(\d+)',p.name)) and 22<=int(m[1])<=43]
 result=run('regressions-collection',[py,'-m','pytest','--collect-only','-q',*map(str,files)]);raise SystemExit(result['exit_code'])
