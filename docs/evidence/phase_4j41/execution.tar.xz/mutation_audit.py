import json,shutil,tempfile
from pathlib import Path
from island.charge_references.records import pack,unpack
from island.exceptions import PCFFError
from island.workflows import storage
from scripts.validate_phase_4j41_receipt import validate_study
original=Path('/tmp/j41-validation/final-study');results=[]
for mutation in ('source_bytes','atom_order','charge_vector','component_total','incomplete_interactions','promoted_readiness'):
 with tempfile.TemporaryDirectory(prefix='island-j41-negative-') as temp:
  root=Path(temp)/'study';shutil.copytree(original,root)
  if mutation=='source_bytes':
   p=root/'pcff.frc';p.write_bytes(p.read_bytes().replace(b'silicon atom',b'SILICON atom',1))
  elif mutation=='promoted_readiness':
   p=root/'report.json';value=storage.decode(storage.read_json(p));value['production_validated']=True;p.write_bytes(storage.json_bytes(storage.encode(value)))
  else:
   p=root/'silane/assessment.json';value=unpack(p.read_text())
   if mutation=='atom_order':value['atom_order'].reverse()
   elif mutation=='charge_vector':value['inspection']['native_charge_record']['native_charge_record']['partial_charges'][1]+=0.01
   elif mutation=='component_total':value['inspection']['native_charge_record']['native_charge_record']['components'][0]['charge']=0.1
   elif mutation=='incomplete_interactions':value['inspection']['interaction_queries'].pop()
   p.write_text(pack(value))
  try:validate_study(root)
  except (PCFFError,ValueError) as error:
   results.append({'mutation':mutation,'rejected':True,'error_type':type(error).__name__,'diagnostic':str(error)})
  else:raise RuntimeError('Mutation accepted: '+mutation)
Path('/tmp/j41-validation/mutation-audit.json').write_text(json.dumps({'schema':'island.j41-independent-mutation-audit.v1','results':results,'all_rejected':True},indent=2)+'\n')
print(json.dumps({'rejected':len(results),'total':len(results)}))
