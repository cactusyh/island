import ctypes, json, sys, hashlib
from pathlib import Path
from decimal import Decimal
from scripts.pcff_j41_reference import inventory
from scripts.pcff_j5_reference import read_source
from island.forcefields.pcff import inspect_pcff_full_source, load_pcff_source
from island.forcefields.pcff.fallbacks import lookup, MSI_POLICY
source=load_pcff_source(sys.argv[1]); raw=read_source(source.raw); inv=inventory(source.raw)
catalog=inspect_pcff_full_source(source); indexed={r['id']:r for r in catalog['records']}
checked=[]
for row in inv['rows']:
 key=f"{row['section']}:{row['namespace']}:{row['line']}"
 if key in indexed:
  native=indexed[key]
  if native['raw']!=row['raw']:raise ValueError(key)
  if 'original_values' in native:
   types=native['types']; values=row['fields'][2+len(types):]
   if list(map(float,values))!=native['original_values']:raise ValueError(key)
  checked.append(key)
atom=ctypes.c_char*5
class Row(ctypes.Structure):
 _fields_=[('version',ctypes.c_float),('ref',ctypes.c_int),('types',atom*6),('parameters',ctypes.c_double*8)]
lib=ctypes.CDLL(sys.argv[2]);lib.select_rows.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.POINTER(atom),ctypes.POINTER(Row),ctypes.POINTER(ctypes.c_int)];lib.select_rows.restype=ctypes.c_int
queries=[('quartic_bond','cff91',('h','si')),('quartic_bond','cff91',('c','si')),('quartic_angle','cff91',('h','si','h')),('quartic_angle','cff91',('c','sio','osi')),('quartic_angle','cff91',('o','p','o')),('angle-angle','cff91',('h','si','h','h')),('angle-angle','cff91',('o','p','o','o')),('quadratic_angle','cff91_auto',('h_','si_','h_')),('quadratic_angle','cff91_auto',('o_','p_','o_'))]+[('nonbond(9-6)','cff91',(t,)) for t in ('p','p=','si','sio','sz','hsi','osi')]
results=[]
for family,ns,query in queries:
 # Mirror exact-key duplicate replacement in compiled SearchAndFill.c, retaining slots.
 slots={}
 for r in raw[family,ns]:
  key=tuple(r['types'])
  if key not in slots or r['version']>slots[key]['version']:slots[key]=r
 table=list(slots.values());data=(Row*len(table))()
 for dst,r in zip(data,table):
  dst.version=float(r['version'])
  for i,t in enumerate(r['types']):dst.types[i].value=t.encode()
 q=(atom*len(query))(*(atom(*t.encode()) for t in query));back=ctypes.c_int(-1 if family=='angle-angle' else 0)
 ix=lib.select_rows(len(query),len(table),q,data,ctypes.byref(back));selected=table[ix] if ix>=0 else None
 native=lookup(family,list(query),ns,indexed,[],policy=MSI_POLICY)
 candidate_ids={r['record_id'] for r in native.get('candidates',[])}
 agrees=(selected is None and native['status']=='missing') or (selected is not None and selected['id'] in candidate_ids)
 if not agrees:raise ValueError((query,selected,native))
 results.append({'family':family,'namespace':ns,'query':query,'compiled_c_row':selected['id'] if selected else None,'compiled_c_values':list(map(str,selected['values'])) if selected else None,'native_status':native['status'],'native':native,'selected_among_independent_candidates':agrees,'scope':'leaf matching only; automatic queries do not imply converter auto-equivalence support; AA center reversal disabled'})
output={'schema':'island.j41-independent-native-c-source-audit.v1','source_sha256':source.identity['sha256'],'raw_rows_checked':len(checked),'raw_record_ids':checked,'compiled_leaf_sha256':hashlib.sha256(Path(sys.argv[2]).read_bytes()).hexdigest(),'queries':results,'assembly_authority':False,'production_validated':False,'simulation_readiness':'not_established'}
Path(sys.argv[3]).write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'raw_rows_checked':len(checked),'compiled_queries':len(results),'passed':True}))
