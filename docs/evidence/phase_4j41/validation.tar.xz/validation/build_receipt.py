import hashlib,json,shutil,subprocess,tarfile,time,xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from island.workflows import storage
from island.charge_references.records import unpack
from scripts.validate_phase_4j41_receipt import signed,validate_study

root=Path('/tmp/j41-validation');v=root/'validation';repo=Path.cwd()
names=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
while not all((v/(n+'-command.json')).is_file() for n in names):time.sleep(5)
verification={n:json.loads((v/(n+'-command.json')).read_text()) for n in names}
if any(r['exit_code'] for r in verification.values()):raise RuntimeError('Required check failed')
commit=(v/'implementation-commit.txt').read_text().strip()
if any(r['tested_implementation_commit']!=commit for r in verification.values()):raise RuntimeError('Mixed tested commits')
for name in ('focused','regressions','full'):
 suite=ET.parse(v/(name+'.xml')).getroot().find('testsuite')
 counts={k:int(suite.attrib.get(k,0)) for k in ('tests','failures','errors','skipped')};counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
 if counts['failures'] or counts['errors'] or not counts['passed']:raise RuntimeError('Invalid JUnit outcome')
 verification[name]['junit']=counts
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
historical=json.loads((v/'historical-hashes.json').read_text());frozen=json.loads((v/'frozen-source.json').read_text())
for group in (historical,frozen):
 for path,digest in group.items():
  if sha(repo/path)!=digest:raise RuntimeError('Changed preserved/frozen file: '+path)
independent=validate_study(root/'final-study')
pub=root/'portable'
for name in ('mutation-audit.json','mutation-audit.log','portable-reconstruction.log'):
 shutil.copyfile(root/name,pub/name)
for name in ('mutation_audit.py','portable-reconstruction-command.json'):
 shutil.copyfile(v/name,pub/name)
for path in (root/'final-study').rglob('*'):
 if path.is_file() and sha(path)!=sha(pub/'study'/path.relative_to(root/'final-study')):raise RuntimeError('Changed study after reconstruction')
bundle=signed({'schema':'island.j41-portable-bundle.v1','files':{str(p.relative_to(pub)):sha(p) for p in sorted(pub.rglob('*')) if p.is_file() and p.name!='bundle-manifest.json'}})
(pub/'bundle-manifest.json').write_text(json.dumps(bundle,indent=2)+'\n')
evidence=repo/'docs/evidence/phase_4j41';evidence.mkdir(exist_ok=False)
with tarfile.open(evidence/'execution.tar.xz','w:xz') as tar:
 for path in sorted(pub.iterdir()):tar.add(path,arcname=path.name)
with tarfile.open(evidence/'validation.tar.xz','w:xz') as tar:
 for path in sorted(v.iterdir()):
  if path.is_file() or path.name=='source':tar.add(path,arcname='validation/'+path.name)
report=storage.decode(storage.read_json(root/'final-study/report.json'));env=json.loads((root/'environment.json').read_text())
profiles=[]
for row in report['cases']:
 p=unpack((root/'final-study'/row['name']/'assessment.json').read_text());inspection=p['inspection']
 native=inspection['native_charge_record']['native_charge_record'] if inspection else None
 profiles.append({'name':row['name'],'smiles':row['smiles'],'seed':2026,'profile':p['profile'],'atom_count':len(p['atom_order']),'atom_order':p['atom_order'],'graph_identity':p['graph_identity'],'assessment_identity':row['assessment_identity'],'typing_identity':p['typing_identity'],'charge_identity':inspection['charge_identity'] if inspection else None,'parameter_identity':row.get('parameter_identity'),'model_identity':row.get('model_identity'),'charge_origin':p['charge_origin'],'formal_component_charges':[c['formal_charge'] for c in native['components']] if native else [sum(s['formal_charge'] for s in p['graph']['sites'])],'charge_vector':[[i,native['partial_charges'][i]] for i in p['atom_order']] if native else None,'charge_components':native['components'] if native else None,'charge_unit':'elementary_charge' if native else None,'charge_tolerance_e':1e-12,'graph_status':'complete','typing_status':'complete' if p['typing'] and p['typing']['coverage']['complete'] else 'source_interpretation_unresolved','charge_status':'complete' if inspection and inspection['charges_complete'] else 'not_assigned_typing_blocked','parameter_status':'complete' if row['source_complete'] else 'source_incomplete','executable_workflow_status':'finite_software_verified' if row['dynamics_executed'] else 'blocked_before_model_publication','missing_interactions':dict(Counter(d['interaction']['family'] for d in row['diagnostics'] if 'interaction' in d)),'converter':row['converter'],'scientific_validation_status':'not_established','periodic_md_status':'unsupported_in_this_finite_profile'})
manifest=signed({'schema':'island.j41-manifest.v1','base_commit':(v/'base-commit.txt').read_text().strip(),'tested_implementation_commit':commit,'files':{name:sha(evidence/name) for name in ('execution.tar.xz','validation.tar.xz')},'historical_files':historical,'implementation_files':frozen,'bundle_identity':bundle['identity']})
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
silane=report['cases'][0]
receipt=signed({'schema':'island.j41-receipt.v1','created_utc':datetime.now(timezone.utc).isoformat(),'phase':'4J41','base_commit':manifest['base_commit'],'tested_implementation_commit':commit,'branch':'codex/phase-4j41-pcff-silicon-phosphorus','acceptance_gate':1,'outcome':'partial_source_coverage; finite_silane_software_verified; mixed_Si_and_P_publication_blocked','production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(evidence/'manifest.json'),'independent_validation':independent,'profiles':profiles,'source_distribution':env['source_distribution'],'converter':env['converter'],'lammps':{k:val for k,val in env['lammps'].items() if k!='help'},'openmm':env['openmm'],'source_audit':{'independent_raw_rows_checked':1942,'compiled_Si_P_matcher_queries':16,'wildcard_equivalence_control':'matcher/receipt.json in execution archive','mutation_audit':'mutation-audit.json in execution archive; six corrupted bundles rejected','typing_authority':'bounded ISLAND graph predicates; converter consumes supplied types, not a chemical perception authority','charge_policy':'source native zero-base direct then ordinary increments; no normalization','missing_coupling_policy':'source row required; no compatibility or invented zero'},'numerical_silane':{'singlepoint':silane['singlepoint'],'coefficient_audit':silane['coefficient_audit'],'finite_differences':silane['finite_differences'],'minimization':silane['minimization'],'dynamics':silane['dynamics'],'time_step_fs':0.1,'steps_per_integrator':200,'trajectory_length_ps':0.02,'equilibrium_established':False,'nonbonded_limitation':'no active nonbonded pairs within the single silane molecule under 0/0/1 shortest-path exclusions'},'audits':{'execution_exit_code':1,'expected_execution_meaning':'four source-incomplete profiles preserve the nonzero publication gate','source_audit_exit_code':0,'compiled_matcher_exit_code':0,'portable_reconstruction':json.loads((v/'portable-reconstruction-command.json').read_text()),'historical_preservation':{'files':len(historical),'changed':0}},'verification':verification,'limitations':['Only the retained finite neutral silane fixture is numerically qualified.','Organosilicon and siloxane required couplings are absent; publication and MD blocked.','P oxo versus phosphazene typing is unresolved; no invented P/O assignments or charges.','No universal PCFF/COMPASS or msi2lmp parity.','No periodic, pressure, Ewald/PPPM, equilibration or production qualification in J41.','Checkpoint byte equality compares identical segmented lineage across in-process and relocated fresh-process continuation; uninterrupted physical state and full RNG are exact, whole-run lineage/counters remain distinct.','No AM1-BCC support or experimental validation claimed.']})
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps({'receipt':str(evidence/'receipt.json'),'verification':{k:r['junit'] for k,r in verification.items() if 'junit' in r},'historical_files':len(historical),'acceptance_gate':1}),flush=True)
