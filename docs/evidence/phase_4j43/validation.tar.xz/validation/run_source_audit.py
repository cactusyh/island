import json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/j43-validation');v=r/'validation';py='../island-validation/phase4e2-env/bin/python'
env={**os.environ,'PYTHONPATH':'.:src','PYTHONDONTWRITEBYTECODE':'1','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'}
args=[py,str(r/'source_availability_audit.py')];start=time.time()
with (v/'source_availability_audit.log').open('w') as log:p=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
(v/'source_availability_audit-command.json').write_text(json.dumps({'argv':args,'cwd':str(Path.cwd()),'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'environment':{k:env[k] for k in ('PYTHONPATH','PYTHONDONTWRITEBYTECODE','OPENMM_CPU_THREADS','OMP_NUM_THREADS')}},indent=2)+'\n')
assert p.returncode==0
print('source_availability_audit passed; physical source-row reconstruction blocked by absent inputs')
