"""Package only verified J43 evidence; preserve historical source bytes."""
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
from pathlib import Path
from scripts.phase_4j41_c2 import read
from scripts.phase_4j43 import BASE,BRANCH
from scripts.validate_phase_4j41_receipt import sha,signed
root=Path('/tmp/j43-validation');v=root/'validation';repo=Path.cwd();dest=repo/'docs/evidence/phase_4j43'
commit=(v/'implementation-commit.txt').read_text().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
verification={}
for name in ('focused','full','regressions','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum','receipt_j42','receipt_j42_c1','historical_byte_audit','relocation','source_availability_audit','execution'):
 result=json.loads((v/(name+'-command.json')).read_text())
 assert result['exit_code']==(1 if name=='execution' else 0) and result['tested_implementation_commit']==commit,name
 verification[name]=result
report=read(root/'final-study/report.json')
assert len(report['cases'])==5 and report['acceptance_gate']==1
assert report['literature_inventory']==[] and report['extracted_parameter_rows']=={}
assert report['execution_profiles']==[] and report['backend_executions']==[]
assert all(c['status']=='asset_unavailable' for c in report['cases'])
historical={**json.loads((v/'historical-byte-hashes.json').read_text()),**json.loads((v/'protected-source-hashes.json').read_text())}
assert all(sha(repo/p)==h for p,h in historical.items())
implementation={p:sha(repo/p) for p in ('src/island/forcefields/pdms_literature.py','scripts/phase_4j43.py','scripts/validate_phase_4j43_receipt.py','tests/test_phase_4j43.py')}
for p,h in implementation.items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':'+p])).hexdigest()==h
for name in ('run_gates.py','run_extra.py','derive_regressions.py','historical_byte_audit.py','source_availability_audit.py','run_source_audit.py','build_receipt.py'):shutil.copyfile(root/name,v/name)
def files(folder):return {str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
dest.mkdir(parents=True,exist_ok=True)
for archive,source,arcname in [('execution.tar.xz',root/'final-study','study'),('validation.tar.xz',v,'validation')]:
 with tarfile.open(dest/archive,'w:xz',preset=6) as tar:tar.add(source,arcname=arcname)
manifest=signed({'schema':'island.j43-manifest.v1','base_commit':BASE,'historical_files':historical,'implementation_files':implementation,'archives':{n:sha(dest/n) for n in ('execution.tar.xz','validation.tar.xz')},'study_files':files(root/'final-study'),'validation_files':files(v)})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
counts={name:{k:sum(int(s.attrib.get(k,0)) for s in E.parse(v/(name+'.xml')).getroot()) for k in ('tests','failures','errors','skipped')} for name in ('focused','full','regressions')}
assert all(c['failures']==c['errors']==0 for c in counts.values())
receipt=signed({'schema':'island.j43-receipt.v1','base_commit':BASE,'branch':BRANCH,'tested_implementation_commit':commit,'status':'asset_unavailable','acceptance_gate':1,'native_pcff_acceptance_gate':1,'execution_profiles':[],'backend_executions':[],'production_validated':False,'simulation_readiness':'not_established','limitations':report['limitations'],'manifest_sha256':sha(dest/'manifest.json'),'study_report':report,'source_asset_hashes':{},'physical_parameter_rows_reconstructed':0,'source_row_reconstruction':'blocked; no user-supplied literature source','reconstruction':json.loads((v/'relocation.log').read_text()),'relocation':json.loads((v/'relocation-file-hashes.json').read_text()),'verification':verification,'test_counts':counts,'regression_scope':'Exact J22-J42-C1 subset of supported full execution; no second execution claimed','historical_bytes_match_base':True,'historical_documentation_files':sum(p.startswith('docs/') for p in historical),'historical_source_files':sum(not p.startswith('docs/') for p in historical),'native_forcefields_c5_schema_and_historical_receipts_unchanged':True,'historical_receipt_validation':'Unchanged J42-C1 validator at current runtime; unchanged J42 validator source pins at its original detached snapshot, current runtime study reconstruction','retained_failed_attempts':['initial-harness-run','initial-newline-test-run','initial-source-audit']})
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'test_counts':counts,'historical_files':len(historical),'study_files':len(files(root/'final-study'))},indent=2))
