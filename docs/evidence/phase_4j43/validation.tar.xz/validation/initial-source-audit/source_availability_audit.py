"""Independent audit of supplied input availability; no physical rows exist."""
import json
from pathlib import Path
from scripts.phase_4j41_c2 import read
from scripts.phase_4j41_c5 import CASES
root=Path('/tmp/j43-validation/final-study')
r=read(root/'report.json')
assert not r['source_supplied'] and not r['bundle_supplied']
assert r['literature_inventory']==[] and r['extracted_parameter_rows']=={}
assert r['execution_profiles']==[] and r['backend_executions']==[] and r['acceptance_gate']==1
assert [c['name'] for c in r['cases']]==[c[0] for c in CASES]
missing={}
for row in r['cases']:
 p=read(root/row['name']/'ingestion.json')
 # Study ingestion files use the standard immutable envelope, not generic write().
 from island.forcefields.pdms_literature import LiteratureIngestion
 p=LiteratureIngestion((root/row['name']/'ingestion.json').read_text()).payload
 assert p['status']=='asset_unavailable' and p['source_record'] is None
 assert p['missing_interactions']==p['preparation']['requirements']['interactions']
 assert len(p['missing_interactions'])==row['missing_interactions']
 assert len(p['unresolved_dependencies'])==row['unresolved_dependencies']
 missing[row['name']]={'interaction_keys':sorted(p['missing_interactions']),'dependencies':p['unresolved_dependencies']}
print(json.dumps({'status':'asset_unavailable','source_files_supplied':0,'physical_parameter_rows_reconstructed':0,'reason':'No explicit user-supplied literature source or independent pin','source_row_reconstruction':'blocked; no physical source to reconstruct','missing_by_fixture':missing},indent=2))
