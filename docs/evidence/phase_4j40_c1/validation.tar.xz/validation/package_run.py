import json,tarfile,hashlib
from pathlib import Path
root=Path('/tmp/j40-c1-validation/final'); target=Path('docs/evidence/phase_4j40_c1')
assert not (target/'artifacts.tar.xz').exists()
inventory={}
with tarfile.open(target/'artifacts.tar.xz','w:xz',preset=6) as archive:
 for p in sorted((root/'run').rglob('*')):
  if p.is_file():
   name=p.relative_to(root).as_posix();archive.add(p,arcname=name)
   inventory[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 for p,name in [(root/'independent-baseline.json','independent-baseline.json'),(Path('/tmp/j40-c1-validation/before.json'),'before-code-change.json')]:
  archive.add(p,arcname=name);inventory[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(target/'artifact-inventory.json').write_text(json.dumps(inventory,sort_keys=True,indent=2)+'\n')
print('archived',len(inventory),'files')
