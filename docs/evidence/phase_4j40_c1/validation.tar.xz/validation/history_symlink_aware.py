import hashlib,json,os,subprocess
from pathlib import Path
base='a7dfb9a5aaf8ef37d94604e7771cb2771572d82c'
rows=subprocess.check_output(['git','ls-tree','-rz',base,'docs','.gitattributes']).split(b'\0')
hashes={}; links={}
for row in rows:
 if not row:continue
 header,name=row.split(b'\t',1); mode,kind,oid=header.decode().split();name=name.decode();p=Path(name)
 raw=subprocess.check_output(['git','cat-file','blob',oid])
 if mode=='120000':
  assert p.is_symlink() and os.readlink(p).encode()==raw,name
  links[name]={'target':os.readlink(p),'git_blob_sha256':hashlib.sha256(raw).hexdigest()}
 else: assert not p.is_symlink() and p.read_bytes()==raw,name
 hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 if name.endswith('.json'):json.loads(p.read_text())
v=Path('/tmp/j40-c1-validation/verified')
(v/'historical-hashes.json').write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n')
(v/'historical-links.json').write_text(json.dumps(links,sort_keys=True,indent=2)+'\n')
print(json.dumps({'base':base,'files':len(hashes),'links':links,'byte_preservation':True}))
