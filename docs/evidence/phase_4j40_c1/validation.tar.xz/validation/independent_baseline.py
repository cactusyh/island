import json,math,hashlib
from pathlib import Path
root=Path('/tmp/j40-validation/final/run'); result={}
for key in ('gaff2-pe','opls-resp-aromatic','opls-peo','opls-network'):
 replicas=[]
 for i in range(2):
  p=root/key/f'replica-{i}/uninterrupted'; m=json.loads((p/'manifest.json').read_text());f=json.loads((p/'frames.json').read_text())['frames'];n=[x for x in f if x['stage']=='npt'];burn=len(n)//4;n=n[burn:]
  volumes=[x['box_vectors_nm'][0][0]*x['box_vectors_nm'][1][1]*x['box_vectors_nm'][2][2] for x in n]
  density=[m['total_mass_dalton']*1.66053906660e-3/v for v in volumes]
  mean=lambda x:math.fsum(x)/len(x)
  replicas.append({'npt_retained_after_burn':len(n),'required_retained':512,'burn_in_frames':burn,'measured_temperature_kelvin':mean([x['measured_temperature_kelvin'] for x in n]),'target_kelvin':m['config']['temperature_kelvin'],'temperature_pass':abs(mean([x['measured_temperature_kelvin'] for x in n])/300-1)<=.05,'pressure_values':sorted(set(x['measured_pressure_bar'] for x in n),key=str),'mean_volume_nm3':mean(volumes),'mean_density_g_cm3':mean(density),'trajectory_bytes_sha256':hashlib.sha256((p/'frames.json').read_bytes()).hexdigest()})
 result[key]=replicas
out=Path('/tmp/j40-c1-validation/final/independent-baseline.json');out.write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
