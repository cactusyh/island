"""Seal additive evidence only after actual final gate processes finish."""
import gzip,hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
from island.analysis.npt import FLAGS,_signed
from scripts.validate_phase_4j40_c1_receipt import SOURCES
base='a7dfb9a5aaf8ef37d94604e7771cb2771572d82c'
v=Path('/tmp/j40-c1-validation/verified'); evidence=Path('docs/evidence/phase_4j40_c1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
implementation='fd591b7eff8c6f1a4ad0554b8da705b6e0706dfe'
counts={}; commands={}
for name in ('focused','j22-j40','full_supported'):
 command=json.loads((v/'validation'/(name+'-command.json')).read_text())
 assert command['implementation_commit']==implementation and command['exit_code']==0,command
 suites=ET.parse(v/'validation'/(name+'.xml')).getroot().iter('testsuite')
 total={k:0 for k in ('tests','failures','errors','skipped')}
 for suite in suites:
  for k in total:total[k]+=int(suite.attrib.get(k,0))
 assert total['errors']==total['failures']==0,total
 counts[name]={**total,'passed':total['tests']-total['skipped']}
 commands[name]=command
for name in ('ruff','compileall','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum','diff_check','historical_receipts'):
 command=json.loads((v/'validation'/(name+'-command.json')).read_text())
 assert command['exit_code']==0 and command['implementation_commit']==implementation,command
 commands[name]=command
commands['acceptance_driver']={'argv':['../island-validation/phase4e2-env/bin/python','-m','scripts.validate_phase_4j40_c1','--source','/tmp/j40-validation/final/run','--output',str(v/'run'),'--lammps','../island-validation/phase4j22/lmp-kspace'],'environment':{'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'},'implementation_commit':implementation,'exit_code':1,'result':'scientific_acceptance_blocked'}
commands['independent_baseline']={'argv':['../island-validation/phase4e2-env/bin/python','/tmp/j40-c1-validation/final/validation/independent_baseline.py'],'environment':{'PYTHONPATH':'.:src'},'exit_code':0,'role':'independent historical raw-frame reductions'}
assert (v/'run/matrix.json').exists()
assert json.loads((v/'run/child.json').read_text())['exit_code']==0
assert 'byte_preservation": true' in (v/'validation/historical-hashes.log').read_text()
assert 'acceptance_met": false' in (v/'validation/j40-historical-integrity.log').read_text()
# Keep first outputs, never silently overwrite retained development evidence.
pre=Path('/tmp/j40-c1-validation/preliminary-artifact-archive.tar.xz')
if not pre.exists():shutil.copy2(evidence/'artifacts.tar.xz',pre)
inventory={}
with tarfile.open(evidence/'artifacts.tar.xz','w:xz') as archive:
 for p in sorted((v/'run').rglob('*')):
  if p.is_file():
   name=p.relative_to(v).as_posix(); archive.add(p,arcname=name);inventory[name]=sha(p)
 for p,name in [(Path('/tmp/j40-c1-validation/final/independent-baseline.json'),'independent-baseline.json'),(Path('/tmp/j40-c1-validation/before.json'),'before-code-change.json')]:
  archive.add(p,arcname=name);inventory[name]=sha(p)
(evidence/'artifact-inventory.json').write_text(json.dumps(inventory,sort_keys=True,indent=2)+'\n')
for name in ('environments.json','historical-links.json'):
 shutil.copy2(v/name,evidence/name)
# Logs and exact scripts/argv; exclude disposable pytest temporary trees.
with tarfile.open(evidence/'validation.tar.xz','w:xz') as archive:
 for p in sorted((v/'validation').iterdir()):
  if p.is_file():archive.add(p,arcname='validation/'+p.name)
 archive.add(v/'execution.log',arcname='execution.log')
 archive.add(Path('/tmp/j40-c1-validation/final/validation/independent_baseline.py'),arcname='validation/independent_baseline.py')
with tarfile.open(evidence/'preliminary-validation.tar.xz','w:xz') as archive:
 for p in sorted(Path('/tmp/j40-c1-validation').glob('*')):
  if p.is_file():archive.add(p,arcname=p.name)
 for p in sorted(Path('/tmp/j40-c1-validation/final/validation').iterdir()):
  if p.is_file():archive.add(p,arcname='first-implementation/'+p.name)
controls={}
source=Path('/tmp/j40-validation/final/run')
for name,path in [('native_aromatic','controls/native-aromatic.json'),('native_am1bcc','controls/native-am1bcc.json'),('pcff','controls/pcff/result.json')]:
 controls[name]={'historical_path':path,'sha256':sha(source/path),'record':json.loads((source/path).read_text())}
matrix=json.loads((v/'run/matrix.json').read_text())
manifest=_signed({'schema':'island.j40-c1-manifest.v1','base_commit':base,'implementation_commit':implementation,'engine_binary_sha256':matrix['engine_sha256'],'engine_executable':str(Path('../island-validation/phase4j22/lmp-kspace').resolve()),'engine_source':json.loads((source/'engine.json').read_text()),'protocol':matrix['protocol'],'cases':matrix['cases'],'controls':controls,'historical_trajectory_role':'read_only_reanalysis_and_reconstruction; not new equilibration','new_campaign_dynamics':'not_executed','scientific_acceptance':False,'documentation_sha256':sha('docs/phase_4j40_c1.md'),'artifact_hashes':inventory,'commands':commands,**FLAGS})
(evidence/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
receipt=_signed({'schema':'island.j40-c1-receipt.v1','base_commit':base,'implementation_commit':implementation,'final_evidence_commit_resolution':'git log --diff-filter=A --format=%H -- docs/evidence/phase_4j40_c1/receipt.json','source_hashes':{p:sha(p) for p in SOURCES},'historical_hashes':json.loads((v/'historical-hashes.json').read_text()),'historical_entry_count':2408,'historical_symlinks':json.loads((v/'historical-links.json').read_text()),'files':{p.name:sha(p) for p in sorted(evidence.iterdir()) if p.is_file() and p.name!='receipt.json'},'scientific_acceptance':False,'new_acceptance_campaign_dynamics':'not_executed','failed_stages':['insufficient_sampling','temperature_target_unmet','pressure_unavailable','cross_engine_discrepancy','packed_network_finite_difference_interval_not_converged'],'minimized_network_finite_difference':'passed_at_unchanged_bound','validation_counts':counts,'commands':commands,'controls':controls,'remaining_limits':['no validated periodic pressure estimator','Ewald errors exceed unchanged bounds','longer equilibration protocol unexecuted','no thermodynamic equilibrium or production readiness'],**FLAGS})
(evidence/'receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(counts,indent=2))
