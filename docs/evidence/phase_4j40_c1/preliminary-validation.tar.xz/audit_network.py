import json
from pathlib import Path
from scripts.phase_4j38_fixture import build
from scripts.phase_4j40_c1_finite_difference import audit
p=json.load(open('/tmp/j40-validation/final/run/opls-network/backend.json'))
f,_=build('network');ids=sorted(f.packed.system.topology.sites)
xyz=[f.packed.system.coordinates.get(i)/10 for i in ids]
r=audit(p,xyz,ids)
Path('/tmp/j40-c1-validation/network-fd.json').write_text(json.dumps(r,indent=2)+'\n')
print(r['passed'],[(k,v['passed']) for k,v in r['components'].items()],flush=True)
