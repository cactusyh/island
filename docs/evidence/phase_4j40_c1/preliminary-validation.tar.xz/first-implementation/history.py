import json
from scripts.validate_phase_4j38_c2_receipt import historical_hashes
from pathlib import Path
hashes=historical_hashes('a7dfb9a5aaf8ef37d94604e7771cb2771572d82c')
Path('/tmp/j40-c1-validation/final/historical-hashes.json').write_text(json.dumps(hashes,sort_keys=True,indent=2)+'\n')
print(json.dumps({'historical_tracked_docs_and_evidence_files':len(hashes),'byte_preservation':True,'json_readability':True}))
for name in hashes:
 if name.endswith('.json'):json.loads(Path(name).read_text())
