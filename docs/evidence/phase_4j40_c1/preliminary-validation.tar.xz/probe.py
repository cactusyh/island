import json
import numpy as np
import openmm as mm
from openmm import unit
from island._periodic_openmm import build
p=json.load(open('/tmp/j40-validation/final/run/opls-network/backend.json'))
m=build(p['numerical_data'],p['config'],mm)
# Graph's retained coordinates are in workflow first frame.
w=json.load(open('/tmp/j40-validation/final/run/opls-network/replica-0/uninterrupted/frames.json'))
print(type(w),str(w)[:200])
from scripts.phase_4j38_fixture import build as fixture
f,_=fixture('network'); xyz=np.array([f.packed.system.coordinates.get(i)/10 for i in sorted(f.packed.system.topology.sites)])
it=mm.VerletIntegrator(.001);ctx=mm.Context(m,it,mm.Platform.getPlatformByName('Reference'));ctx.setPositions(xyz)
for force in m.getForces():
 g=force.getForceGroup(); s=ctx.getState(getEnergy=True,getForces=True,groups=1<<g)
 analytic=s.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer)/10
 print(force.getName(),g,'energy',s.getPotentialEnergy(),flush=True)
 for h in (1e-4,1e-5,1e-6,1e-7,1e-8):
  errors=[]
  for a in (0,len(xyz)-1):
   for axis in range(3):
    es=[]
    for sign in (-1,1):
     x=xyz.copy();x[a,axis]+=sign*h;ctx.setPositions(x)
     es.append(ctx.getState(getEnergy=True,groups=1<<g).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole))
    errors.append(abs(-(es[1]-es[0])/(20*h)-analytic[a,axis]))
  print(h,max(errors),flush=True)
 ctx.setPositions(xyz)
