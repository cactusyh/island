import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
repo=Path.cwd();root=Path('/tmp/j41-c3-validation');v=root/'validation';study=root/'final-study';py=(repo/'../island-validation/phase4e2-env/bin/python').resolve()
env={**os.environ,'PYTHONPATH':str(repo)+':'+str(repo/'src')+':'+str(repo/'scripts'),'OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,cmd,cwd=repo,expected=0):
 start=time.time()
 with (v/(name+'.log')).open('w') as log:r=subprocess.run(cmd,env=env,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 record={'argv':list(map(str,cmd)),'cwd':str(cwd),'exit_code':r.returncode,'elapsed_seconds':time.time()-start,'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
 (v/(name+'-command.json')).write_text(json.dumps(record,indent=2)+'\n')
 if r.returncode!=expected:raise RuntimeError('Failed '+name)
 return record
while not (v/'execution-command.json').is_file():time.sleep(2)
record=json.loads((v/'execution-command.json').read_text());assert record['exit_code']==1 and (study/'report.json').is_file()
run('independent-study-audit',[str(py),str(repo/'scripts/validate_phase_4j41_c3_receipt.py'),'--study',str(study)])
print('independent study audit passed',flush=True)
# Reconstruct in a fresh process after copying the complete raw study elsewhere.
files={str(p.relative_to(study)):sha(p) for p in study.rglob('*') if p.is_file()}
relocated=root/'relocated';relocated.mkdir(exist_ok=False);shutil.copytree(study,relocated/'study')
cwd=root/'relocation-cwd';cwd.mkdir(exist_ok=False)
result=run('portable-reconstruction',[str(py),str(repo/'scripts/phase_4j41_c3.py'),'--reconstruct',str(relocated/'study')],cwd)
assert {str(p.relative_to(relocated/'study')):sha(p) for p in (relocated/'study').rglob('*') if p.is_file()}==files
assert {str(p.relative_to(study)):sha(p) for p in study.rglob('*') if p.is_file()}==files
result.update(all_study_files_identical_after_relocation=True,study_file_count=len(files),original_study_unchanged=True)
(v/'portable-reconstruction-command.json').write_text(json.dumps(result,indent=2)+'\n')
print('relocation and checkpoint/RNG reconstruction passed:',len(files),flush=True)
for phase in ('4j41','4j41_c1','4j41_c2'):
 run('historical-'+phase+'-validator',[str(py),str(repo/f'scripts/validate_phase_{phase}_receipt.py'),str(repo/f'docs/evidence/phase_{phase}')])
 print('historical validator passed:',phase,flush=True)
for p,h in json.loads((v/'historical-hashes.json').read_text()).items():assert sha(repo/p)==h,p
print('historical byte-hash preservation passed',flush=True)
