import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from island.charge_references.records import unpack
from scripts.phase_4j41_c2 import read
from scripts.validate_phase_4j41_receipt import signed
r=Path('/tmp/j41-c3-validation');v=r/'validation';repo=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
commit=(v/'implementation-commit.txt').read_text().strip();base=(v/'base-commit.txt').read_text().strip()
names=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
verification={n:json.loads((v/(n+'-command.json')).read_text()) for n in names}
for name,q in verification.items():
 assert q['exit_code']==0 and q['tested_implementation_commit']==commit,(name,q)
 for shard in q.get('shards',[]):assert shard['exit_code']==0 and shard['tested_implementation_commit']==commit
for name in ('focused','regressions','full'):
 counts={k:0 for k in ('tests','failures','errors','skipped')}
 for suite in ET.parse(v/(name+'.xml')).getroot().iter('testsuite'):
  for k in counts:counts[k]+=int(suite.attrib.get(k,0))
 counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
 assert counts['passed'] and not counts['failures'] and not counts['errors']
 verification[name]['junit']=counts
files=sorted(f for f in subprocess.check_output(['git','ls-files','tests'],text=True).splitlines() if Path(f).name.startswith('test_') and f.endswith('.py') and not any(part.startswith('.') for part in Path(f).parts))
assert verification['full']['all_test_files']==files
historical=json.loads((v/'historical-hashes.json').read_text());frozen=json.loads((v/'frozen-source.json').read_text())
for group in (historical,frozen):
 for p,h in group.items():assert sha(repo/p)==h,p
execution=json.loads((v/'execution-command.json').read_text());assert execution['exit_code']==1
ind_command=json.loads((v/'independent-study-audit-command.json').read_text());assert ind_command['exit_code']==0
# The independent validator prints plain JSON and runs in a separate process.
independent=json.loads((v/'independent-study-audit.log').read_text())
relocation=json.loads((v/'portable-reconstruction-command.json').read_text());assert relocation['exit_code']==0 and relocation['all_study_files_identical_after_relocation']
mutations=json.loads((v/'mutation-audit.json').read_text());assert mutations['all_rejected'] and len(mutations['results'])==8
for name in ('4j41','4j41_c1','4j41_c2'):assert json.loads((v/f'historical-{name}-validator-command.json').read_text())['exit_code']==0
report=read(r/'final-study/report.json');runtime=json.loads((r/'runtime-inventory.json').read_text())
assert runtime['converter']['sha256']==report['converter_sha256']
assert runtime['lammps']['sha256']==report['lammps_sha256']
assert sha(r/'matcher/leaf.so')==report['matcher_sha256']
source_audits={};results=[];compiled_counts=Counter()
for source in ('pcff','compass_published'):
 a=read(r/'final-study'/source/'raw-source-audit.json')
 q=read(r/'final-study'/source/'compiled-searches.json')
 p=unpack((r/'final-study'/source/'inventory.json').read_text())
 source_audits[source]={**a,'compiled_search_count':len(q),'compiled_status_counts':dict(Counter(x['independent']['status'] for x in q)),'source_identity':p['sha256'],'variant_identity':a['variant_identity'],'provenance':p['provenance'],'companion_hashes':p['companion_hashes'],'sip_labels':p['sip_labels'],'template_counts':{k:len(t) for k,t in p['templates'].items()},'end_marker_present':p['end_marker_present']}
 compiled_counts.update(x['independent']['status'] for x in q)
for row in report['cases']:
 p=read(r/'final-study'/row['source'].removesuffix('.frc')/row['name']/'raw-reconstruction.json')
 if row['source']=='pcff.frc':
  from island.charge_references.records import unpack
  d=unpack((r/'final-study/pcff'/row['name']/'decision.json').read_text())
  interactions=d['blocking_interactions'];block_counts=Counter(q['family'] for q in interactions)
  typed=d['phosphorus_decisions'];origin='PCFF/source_native_bond_increments'
 else:
  interactions=[q for q in p['interactions'] if q['resolution']['status'] not in ('assigned','not_applicable')]
  block_counts=Counter(q['family'] for q in interactions)
  typed=p['mapping']['blockers'];origin='COMPASS/source_native_bond_increments' if p['charges'] else 'unassigned'
 results.append({**row,'missing_interaction_context_count':len(interactions),'missing_families':dict(sorted(block_counts.items())),'first_missing_contexts':interactions[:3],'typing_blockers':typed,'charge_origin':origin,'periodic_status':'not_authorized','scientific_validation_status':'not_established'})
source_dir=v/'source';source_dir.mkdir(exist_ok=False)
for p in frozen:
 target=source_dir/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,target)
for n in ('build.py','run_gates.py','audit_after_execution.py','build_receipt.py','mutation_worker.py','mutations.py','runtime.py'):
 shutil.copyfile(r/n,v/n)
pub=r/'portable';pub.mkdir(exist_ok=False);shutil.copytree(r/'final-study',pub/'study')
for folder in ('converter','matcher','negative-controls'):shutil.copytree(r/folder,pub/folder)
for n in ('build.json','matcher-execution.json','environment.json','runtime-inventory.json','converter-help.log','lammps-help.log'):
 shutil.copyfile(r/n,pub/n)
for n in ('execution-command.json','execution.log','independent-study-audit-command.json','independent-study-audit.log','portable-reconstruction-command.json','portable-reconstruction.log','mutation-audit.json'):
 shutil.copyfile(v/n,pub/n)
bundle=signed({'schema':'island.j41-c3-portable-bundle.v1','files':{str(p.relative_to(pub)):sha(p) for p in sorted(pub.rglob('*')) if p.is_file()}})
(pub/'bundle-manifest.json').write_text(json.dumps(bundle,indent=2)+'\n')
evidence=repo/'docs/evidence/phase_4j41_c3';evidence.mkdir(exist_ok=False)
with tarfile.open(evidence/'execution.tar.xz','w:xz') as tar:
 for p in sorted(pub.iterdir()):tar.add(p,arcname=p.name)
with tarfile.open(evidence/'validation.tar.xz','w:xz') as tar:
 for p in sorted(v.iterdir()):
  if p.is_file() or p.name=='source':tar.add(p,arcname='validation/'+p.name)
implementation={**frozen,'docs/phase_4j41_c3.md':sha(repo/'docs/phase_4j41_c3.md')}
manifest=signed({'schema':'island.j41-c3-manifest.v1','base_commit':base,'tested_implementation_commit':commit,'files':{n:sha(evidence/n) for n in ('execution.tar.xz','validation.tar.xz')},'historical_files':historical,'implementation_files':implementation,'bundle_identity':bundle['identity']})
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt=signed({'schema':'island.j41-c3-receipt.v1','created_utc':datetime.now(timezone.utc).isoformat(),'phase':'4J41-C3','base_commit':base,'tested_implementation_commit':commit,'branch':'codex/phase-4j41-c3-authorized-source-variants','acceptance_gate':1,'outcome':'authorized variants audited; no source-complete new mixed-Si/P execution profile; original silane and all blocked decisions preserved','production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(evidence/'manifest.json'),'independent_validation':independent,'source_variants':source_audits,'profiles':results,'compiled_search_status_counts':dict(compiled_counts),'new_execution_profiles':[],'converter_build':json.loads((r/'build.json').read_text()),'runtime':runtime,'periodic_scientific_status':{'ewald':'ewald_unvalidated','pressure':'pressure_unavailable','long_npt':'blocked','cutoff_recovery':'not_executed'},'audits':{'execution':execution,'independent_raw_source_process':ind_command,'relocation_fresh_process':relocation,'negative_controls':mutations,'historical_preservation':{'files':len(historical),'changed':0,'original_c2_decisions':17}},'verification':verification,'limitations':['Only authorized local pcff.frc and compass_published.frc were compared; no proprietary source retrieval or universal coverage claim.','Inventories and trial labels authorize no execution profile; no rows are mixed across sources.','Neither source completes the retained mixed-Si/P environments; missing cross terms remain missing and chemical P ambiguity remains blocked.','Finite silane has no active intramolecular nonbonded pairs or proper dihedrals; COMPASS diagnostic agreement is not a new transferable profile.','No charge normalization, interpolation, invented parameters, or wildcard-based P state transfer.','Periodic Ewald, pressure and long-NPT gates remain blocked; no scientific equilibrium, experimental agreement or production readiness.']})
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps({'receipt':str(evidence/'receipt.json'),'verification':{k:q['junit'] for k,q in verification.items() if 'junit'in q},'historical_files':len(historical),'compiled_searches':sum(compiled_counts.values()),'acceptance_gate':1}),flush=True)
