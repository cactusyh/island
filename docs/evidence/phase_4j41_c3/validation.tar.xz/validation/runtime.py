import hashlib,json,subprocess
from pathlib import Path
r=Path('/tmp/j41-c3-validation');repo=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
out={}
for name,path in [('converter',r/'converter/msi2lmp'),('lammps',repo.parent/'island-validation/phase4j22/lmp-kspace')]:
 cmd=[str(path.resolve()),'-h'];x=subprocess.run(cmd,capture_output=True,text=True,check=False)
 text=x.stdout+x.stderr;(r/(name+'-help.log')).write_text(text)
 out[name]={'executable':str(path.resolve()),'sha256':sha(path),'argv':cmd,'exit_code':x.returncode,'help_sha256':sha(r/(name+'-help.log')),'version_lines':text.splitlines()[:6]}
line=next(x for x in (r/'final-study/pcff/silane_control/converter.log').read_text().splitlines() if 'Running msi2lmp' in x)
out['converter']['executed_version_line']=line
assert 'msi2lmp v3.9.11' in line
assert 'class2' in (r/'lammps-help.log').read_text()
try:out['local_lammps_revision']=subprocess.check_output(['git','-C',str(repo.parent/'lammps/lammps'),'rev-parse','HEAD'],text=True).strip()
except subprocess.CalledProcessError:out['local_lammps_revision']='unavailable; source files individually hashed'
out['class2_conventions']={'boundary':'f f f; finite isolated diagnostic only','pair_style':'lj/class2/coul/cut','mixing':'sixthpower','special_bonds_lj_coul':[0,0,1],'kspace_executed_for_c3':False}
(r/'runtime-inventory.json').write_text(json.dumps(out,indent=2)+'\n')
print('runtime identities and original help outputs recorded')
