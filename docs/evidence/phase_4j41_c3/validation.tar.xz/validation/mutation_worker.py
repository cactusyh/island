import sys
from pathlib import Path
from island.charge_references.records import unpack
from island.forcefields.pcff.sip_variants import validate_sip_variant_inventory
from island.workflows.bundle import system_from
from scripts.pcff_j41_c3_reference import validate_compass_reconstruction
from scripts.phase_4j41_c2 import read
from scripts.validate_phase_4j41_c3_receipt import reload_variant
study=Path(sys.argv[1]);kind=sys.argv[2];artifact=Path(sys.argv[3]);name=sys.argv[4]
v=reload_variant(study/'compass_published','compass_published.frc')
if kind=='inventory':validate_sip_variant_inventory(artifact,v)
else:
 s=system_from(read(study/'compass_published'/name/'system.json'))
 validate_compass_reconstruction(s,v,read(artifact))
