import copy,hashlib,json,os,subprocess,time
from pathlib import Path
from island.charge_references.records import pack,unpack
from scripts.phase_4j41_c2 import read,write
root=Path('/tmp/j41-c3-validation');v=root/'validation';study=root/'final-study';repo=Path.cwd();py=(repo/'../island-validation/phase4e2-env/bin/python').resolve()
while not (study/'report.json').exists():time.sleep(2)
folder=root/'negative-controls';folder.mkdir(exist_ok=False)
env={**os.environ,'PYTHONPATH':str(repo)+':'+str(repo/'src')+':'+str(repo/'scripts'),'OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'}
results=[]
for mutation in ('mixed_source_row','wrong_source_hash','missing_cross_terms','wrong_graph','wrong_atom_order','changed_charge','p_state_transfer','pressure_promotion'):
 name='phosphate_ester' if mutation=='p_state_transfer' else 'methylsilane'
 if mutation in ('mixed_source_row','wrong_source_hash'):
  kind='inventory';p=unpack((study/'compass_published/inventory.json').read_text())
  if mutation=='wrong_source_hash':p['sha256']='0'*64
  else:p['rows'].append(unpack((study/'pcff/inventory.json').read_text())['rows'][0])
 else:
  kind='trial';p=read(study/'compass_published'/name/'raw-reconstruction.json')
  if mutation=='missing_cross_terms':p['interactions']=[q for q in p['interactions'] if q['resolution']['status']!='missing'];p['source_complete']=True
  elif mutation=='wrong_graph':p['system_sha256']='0'*64
  elif mutation=='wrong_atom_order':p['mapping']['labels'][1],p['mapping']['labels'][2]=p['mapping']['labels'][2],p['mapping']['labels'][1]
  elif mutation=='changed_charge':p['charges']['vector_e'][1]='0'
  elif mutation=='p_state_transfer':p['mapping']['labels'][3]='p4=';p['mapping']['blockers']=[]
  else:p['pressure_status']='validated'
 artifact=folder/(mutation+'.json')
 if kind=='inventory':artifact.write_text(pack(p))
 else:write(artifact,p)
 cmd=[str(py),str(root/'mutation_worker.py'),str(study),kind,str(artifact),name]
 r=subprocess.run(cmd,env=env,capture_output=True,text=True,check=False)
 (folder/(mutation+'.log')).write_text(r.stdout+r.stderr)
 assert r.returncode!=0 and 'Contradictory' in r.stderr,(mutation,r.stdout,r.stderr)
 results.append({'mutation':mutation,'rejected':True,'argv':cmd,'exit_code':r.returncode,'artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'diagnostic':r.stderr.splitlines()[-1]})
(v/'mutation-audit.json').write_text(json.dumps({'all_rejected':True,'results':results},indent=2)+'\n')
print('eight separate-process reserialized mutations rejected',flush=True)
