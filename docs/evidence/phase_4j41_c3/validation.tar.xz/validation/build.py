import hashlib,json,platform,shutil,subprocess,sys
from pathlib import Path
root=Path('/tmp/j41-c3-validation');repo=Path.cwd()
src=repo.parent/'lammps/lammps/tools/msi2lmp/src';out=root/'converter';out.mkdir(exist_ok=False)
for p in sorted(src.iterdir()):
 if p.suffix in ('.c','.h'):shutil.copyfile(p,out/p.name)
cmd=['cc','-O2','-o',str(out/'msi2lmp'),*[str(p) for p in sorted(out.glob('*.c'))],'-lm']
r=subprocess.run(cmd,capture_output=True,text=True)
(root/'build.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'compiler':subprocess.check_output(['cc','--version'],text=True),'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.suffix in ('.c','.h')},'executable_sha256':hashlib.sha256((out/'msi2lmp').read_bytes()).hexdigest() if r.returncode==0 else None},indent=2))
r.check_returncode()
cmd=[sys.executable,'scripts/audit_pcff_c_matcher.py','--source',str(src.parent/'frc_files/pcff.frc'),'--msi2lmp-source',str(src),'--output',str(root/'matcher'),'--compare-native']
r=subprocess.run(cmd,capture_output=True,text=True)
(root/'matcher-execution.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2));r.check_returncode()
import numpy,rdkit,openmm
(root/'environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'openmm':openmm.__version__,'numpy':numpy.__version__,'rdkit':rdkit.__version__,'cpuinfo':Path('/proc/cpuinfo').read_text()},indent=2))
print('compiled converter and matcher',flush=True)
