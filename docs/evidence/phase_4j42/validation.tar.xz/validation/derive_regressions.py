import copy,hashlib,json,sys,time,xml.etree.ElementTree as E
from pathlib import Path
root=Path('/tmp/j42-final-validation');v=root/'validation'
while not (v/'full-command.json').is_file():time.sleep(2)
full=json.loads((v/'full-command.json').read_text());assert full['exit_code']==0
collection=json.loads((v/'regressions-collection-command.json').read_text());assert collection['exit_code']==0
nodes=sorted(line.strip() for line in (v/'regressions-collection.log').read_text().splitlines() if line.startswith('tests/') and '::' in line)
assert nodes and len(nodes)==len(set(nodes)) and set(nodes)<=set(full['all_test_nodeids'])
index={}
for t in E.parse(v/'full.xml').getroot().iter('testcase'):
 key=(t.attrib['classname'],t.attrib['name']);assert key not in index;index[key]=t
suite=E.Element('testsuite',name='J22-through-J41-C5 subset of the supported full execution')
counts={k:0 for k in ('tests','failures','errors','skipped')}
for node in nodes:
 file,*parts=node.split('::');key=(file[:-3].replace('/','.')+(' .'.strip() if False else '')+(''.join('.'+c for c in parts[:-1])),parts[-1])
 assert key in index,(node,key)
 case=copy.deepcopy(index[key]);suite.append(case);counts['tests']+=1
 for k,tag in (('failures','failure'),('errors','error'),('skipped','skipped')):counts[k]+=len(case.findall(tag))
assert counts['tests']==len(nodes) and not counts['failures'] and not counts['errors']
for k,value in counts.items():suite.set(k,str(value))
parent=E.Element('testsuites');parent.append(suite);E.ElementTree(parent).write(v/'regressions.xml',encoding='utf-8',xml_declaration=True)
commit=(v/'implementation-commit.txt').read_text().strip();assert full['tested_implementation_commit']==collection['tested_implementation_commit']==commit
result={'argv':[sys.executable,str(Path(__file__).resolve())],'cwd':full['cwd'],'tested_implementation_commit':commit,'exit_code':0,'scope':'Exact J22-J41-C5 subset of the supported full-suite execution; no duplicate test execution claimed','all_test_nodeids':nodes,'all_test_files':sorted(set(n.split('::')[0] for n in nodes)),'full_command_sha256':hashlib.sha256((v/'full-command.json').read_bytes()).hexdigest(),'collection':collection,'partition_disjoint':True}
(v/'regressions-command.json').write_text(json.dumps(result,indent=2)+'\n')
(v/'regressions.log').write_text(json.dumps({'source':'full.xml','counts':counts,'all_nodes_present_exactly_once':True},indent=2)+'\n')
print(json.dumps(counts),flush=True)

(v/'regressions.json').write_text(json.dumps({'tests':counts['tests'],'failures':counts['failures']+counts['errors'],'skipped':counts['skipped'],'all_test_nodeids':nodes,'derivation':'exact subset of full.xml; not a second execution'},indent=2)+'\n')
