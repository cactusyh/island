import concurrent.futures,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/j42-final-validation');v=root/'validation';repo=Path.cwd();py='../island-validation/phase4e2-env/bin/python'
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
def run(name,argv):
 start=time.time();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 with (v/(name+'.log')).open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 result={'argv':argv,'cwd':str(repo),'environment':{k:env[k] for k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'tested_implementation_commit':commit,'exit_code':r.returncode,'elapsed_seconds':time.time()-start}
 (v/(name+'-command.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,r.returncode,flush=True)
 return result
if sys.argv[1]=='historical':
 jobs=[(n,[py,'scripts/validate_phase_4j41'+s+'_receipt.py','docs/evidence/phase_4j41'+s]) for n,s in [('receipt_j41',''),('receipt_c1','_c1'),('receipt_c2','_c2'),('receipt_c3','_c3'),('receipt_c4','_c4'),('receipt_c5','_c5')]]
 jobs.append(('historical_byte_audit',[py,str(root/'historical_byte_audit.py')]))
 with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:results=list(pool.map(lambda j:run(*j),jobs))
 raise SystemExit(max(r['exit_code'] for r in results))
if sys.argv[1]=='reconstruction':
 source=root/'final-study';target=root/'relocated-study'
 shutil.copytree(source,target)
 result=run('relocation',[py,'scripts/phase_4j42.py','--reconstruct',str(target)])
 assert result['exit_code']==0
 def hashes(folder):return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
 a,b=hashes(source),hashes(target);assert a==b
 (v/'relocation-file-hashes.json').write_text(json.dumps({'identical_files':len(a),'files':a},indent=2)+'\n')
 raise SystemExit(0)
if sys.argv[1]=='regression_collection':
 files=[p for p in sorted(Path('tests').glob('test_phase_4j*.py')) if (m:=re.search(r'4j(\d+)',p.name)) and 22<=int(m[1])<=41]
 result=run('regressions-collection',[py,'-m','pytest','--collect-only','-q',*map(str,files)])
 raise SystemExit(result['exit_code'])
