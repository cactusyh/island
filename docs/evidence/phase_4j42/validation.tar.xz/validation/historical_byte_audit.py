import hashlib,json,subprocess
from pathlib import Path
from scripts.phase_4j42 import BASE
from scripts.validate_phase_4j41_receipt import sha
root=Path.cwd();rows=subprocess.check_output(['git','ls-tree','-r',BASE,'docs'],text=True).splitlines()
p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
result={}
for row in rows:
 meta,name=row.split('\t',1);mode,kind,oid=meta.split();assert kind=='blob' and mode in ('100644','100755','120000')
 p.stdin.write((oid+'\n').encode());p.stdin.flush()
 header=p.stdout.readline().split();assert header[0].decode()==oid and header[1]==b'blob'
 raw=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n'
 expected=hashlib.sha256(raw).hexdigest()
 if mode=='120000':
  import os
  assert os.readlink(root/name).encode()==raw,name
  result[name]=sha(root/name)
 else:
  assert sha(root/name)==expected,name
  result[name]=expected
p.stdin.close();assert p.wait()==0
Path('/tmp/j42-final-validation/validation/historical-byte-hashes.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'historical_files':len(result),'base_commit':BASE,'all_bytes_equal_to_git_base':True}))
