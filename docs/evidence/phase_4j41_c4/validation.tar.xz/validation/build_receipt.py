import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from scripts.phase_4j41_c2 import read
from scripts.validate_phase_4j41_receipt import signed
r=Path('/tmp/j41-c4-validation');v=r/'validation';repo=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def logjson(path):
 text=Path(path).read_text();decoder=json.JSONDecoder()
 for i,line in enumerate(text.splitlines(keepends=True)):
  if line.startswith('{'):
   pos=sum(map(len,text.splitlines(keepends=True)[:i]));obj,end=decoder.raw_decode(text[pos:]);assert not text[pos+end:].strip();return obj
 raise ValueError('No JSON result '+str(path))
commit=(v/'implementation-commit.txt').read_text().strip();base=(v/'base-commit.txt').read_text().strip()
names=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
verification={n:json.loads((v/(n+'-command.json')).read_text()) for n in names}
for name,q in verification.items():
 assert q['exit_code']==0 and q['tested_implementation_commit']==commit,(name,q)
 for shard in q.get('shards',[]):assert shard['exit_code']==0 and shard['tested_implementation_commit']==commit
for name in ('focused','regressions','full'):
 counts={k:0 for k in ('tests','failures','errors','skipped')}
 for suite in ET.parse(v/(name+'.xml')).getroot().iter('testsuite'):
  for k in counts:counts[k]+=int(suite.attrib.get(k,0))
 counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
 assert counts['passed'] and not counts['failures'] and not counts['errors']
 verification[name]['junit']=counts
 nodes=verification[name]['all_test_nodeids']
 assert counts['tests']==len(nodes) and len(nodes)==len(set(nodes))
files=sorted(f for f in subprocess.check_output(['git','ls-files','tests'],text=True).splitlines() if Path(f).name.startswith('test_') and f.endswith('.py') and not any(part.startswith('.') for part in Path(f).parts))
assert verification['full']['all_test_files']==files
historical=json.loads((v/'historical-hashes.json').read_text());frozen=json.loads((v/'frozen-source.json').read_text())
for group in (historical,frozen):
 for p,h in group.items():assert sha(repo/p)==h,p
execution=json.loads((v/'execution-command.json').read_text());assert execution['exit_code']==1
ind_command=json.loads((v/'independent-study-audit-command.json').read_text());assert ind_command['exit_code']==0
independent=logjson(v/'independent-study-audit.log')
relocation=json.loads((v/'portable-reconstruction-command.json').read_text());assert relocation['exit_code']==0 and relocation['all_study_files_identical_after_relocation']
mutations=json.loads((v/'mutation-audit.json').read_text());assert mutations['all_rejected'] and len(mutations['results'])==11
for name in ('4j41','4j41_c1','4j41_c2','4j41_c3'):assert json.loads((v/f'historical-{name}-validator-command.json').read_text())['exit_code']==0
report=read(r/'final-study/report.json');runtime=read(r/'final-study/tools/build.json')
assert all(row['converter_sha256']==runtime['builds']['original']['executable_sha256'] and row['lammps_sha256']==runtime['lammps']['sha256'] for row in report['cases'])
source_audits={}
for source in ('pcff','compass_published'):
 a=read(r/'final-study'/source/'independent-inventory.json')
 from island.charge_references.records import unpack
 p=unpack((r/'final-study'/source/'inventory.json').read_text())
 source_audits[source]={**a,'variant_identity':a['variant_identity'],'provenance':p['provenance'],'companion_hashes':p['companion_hashes']}
source_dir=v/'source';source_dir.mkdir(exist_ok=False)
for p in frozen:
 target=source_dir/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,target)
for n in ('run_gates.py','audit_after_execution.py','build_receipt.py'):shutil.copyfile(r/n,v/n)
pub=r/'portable';pub.mkdir(exist_ok=False);shutil.copytree(r/'final-study',pub/'study')
# Negative-control raw inputs and actual worker outputs remain reviewable.
shutil.copytree(r/'negative-controls',pub/'negative-controls')
for n in ('execution-command.json','execution.log','independent-study-audit-command.json','independent-study-audit.log','portable-reconstruction-command.json','portable-reconstruction.log','negative-controls-command.json','negative-controls.log','mutation-audit.json'):shutil.copyfile(v/n,pub/n)
bundle=signed({'schema':'island.j41-c4-portable-bundle.v1','files':{str(p.relative_to(pub)):sha(p) for p in sorted(pub.rglob('*')) if p.is_file()}})
(pub/'bundle-manifest.json').write_text(json.dumps(bundle,indent=2)+'\n')
evidence=repo/'docs/evidence/phase_4j41_c4';evidence.mkdir(exist_ok=False)
with tarfile.open(evidence/'execution.tar.xz','w:xz') as tar:
 for p in sorted(pub.iterdir()):tar.add(p,arcname=p.name)
with tarfile.open(evidence/'validation.tar.xz','w:xz') as tar:
 for p in sorted(v.iterdir()):
  if p.is_file() or p.name=='source':tar.add(p,arcname='validation/'+p.name)
implementation={**frozen,'docs/phase_4j41_c4.md':sha(repo/'docs/phase_4j41_c4.md')}
manifest=signed({'schema':'island.j41-c4-manifest.v1','base_commit':base,'tested_implementation_commit':commit,'files':{n:sha(evidence/n) for n in ('execution.tar.xz','validation.tar.xz')},'historical_files':historical,'implementation_files':implementation,'bundle_identity':bundle['identity']})
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt=signed({'schema':'island.j41-c4-receipt.v1','created_utc':datetime.now(timezone.utc).isoformat(),'phase':'4J41-C4','base_commit':base,'tested_implementation_commit':commit,'branch':'codex/phase-4j41-c4-executable-msi2lmp-resolution','acceptance_gate':1,'status':'source_incomplete','outcome':'Executed original converter plus traced reconstruction; required mixed-Si couplings and P typing remain incomplete; no C4 runtime resolver/profile authorized','production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(evidence/'manifest.json'),'independent_validation':independent,'source_variants':source_audits,'targets':report['cases'],'new_execution_profiles':[],'runtime':runtime,'periodic':report['periodic'],'audits':{'execution':execution,'independent_raw_source_and_converter':ind_command,'relocation':relocation,'negative_controls':mutations,'historical_preservation':{'files':len(historical),'changed':0,'c2_decisions':17,'c3_compiled_searches':374},'historical_receipt_validators':{name:json.loads((v/f'historical-{name}-validator-command.json').read_text()) for name in ('4j41','4j41_c1','4j41_c2','4j41_c3')}},'verification':verification,'limitations':['No complete new mixed Si/P domain was demonstrated; no runtime execution profile or resolver was invented.','C4 independently reconstructs full converter source-row selection; msi2lmp consumes supplied atom labels and charges and is not chemical typing authority.','Converter zero initialization and partial angle-angle success do not supply physical coefficients; absent charge increments and couplings remain blocked.','PCFF p/p= and COMPASS p4= remain chemically state-scoped; phosphate, phosphonate, phosphine oxide, protonated P, PF5-like and unresolved mixed Si/P remain rejected.','CAR/MDF are generated only for an independent oracle; the public PSMILES/final-graph workflow is unchanged.','No row mixing, parameter interpolation, charge normalization, tolerance relaxation, electrostatics disabling or new blocked-domain MD.','The historical finite-silane model remains unchanged; periodic Ewald, pressure, cutoff recovery and long NPT remain blocked.']})
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps({'receipt':str(evidence/'receipt.json'),'verification':{k:q['junit'] for k,q in verification.items() if 'junit'in q},'historical_files':len(historical),'counts':independent['counts'],'acceptance_gate':1}),flush=True)
