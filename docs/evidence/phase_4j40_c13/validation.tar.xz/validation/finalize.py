import json,os,shutil,subprocess,time
from pathlib import Path
v=Path('/tmp/j40-c13-validation/validation');py='../island-validation/phase4e2-env/bin/python';env={**os.environ,'PYTHONPATH':'.:src'}
while not all((v/(name+'-command.json')).exists() for name in ('regressions','full')):time.sleep(10)
for name in ('regressions','full'):
 r=json.loads((v/(name+'-command.json')).read_text());assert r['exit_code']==0,(name,r)
with (v/'build.log').open('w') as f:subprocess.run([py,str(v/'build_receipt.py')],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
out=Path('docs/evidence/phase_4j40_c13')
with (out/'receipt-validation.json').open('w') as f:subprocess.run([py,'-m','scripts.validate_phase_4j40_c13_receipt',str(out)],env=env,stdout=f,check=True)
relocated=Path('/tmp/j40-c13-relocated/evidence');shutil.copytree(out,relocated,dirs_exist_ok=True)
with (out/'relocated-validation.json').open('w') as f:subprocess.run([py,'-m','scripts.validate_phase_4j40_c13_receipt',str(relocated)],env=env,stdout=f,check=True)
print((v/'build.log').read_text(),flush=True);print('Fresh and relocated validators passed',flush=True)
