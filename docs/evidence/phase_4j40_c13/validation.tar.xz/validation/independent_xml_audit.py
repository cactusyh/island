"""Independent XML/raw-dump audit. Does not import any ISLAND/C11/C12 helper."""
import json,math,re,hashlib,sys
from pathlib import Path
import numpy as np
import openmm as mm
from openmm import unit
root=Path(sys.argv[1]); reports=[]
paths=[root/'c11-rerun/box-1.5']+[p for p in sorted(root.iterdir()) if p.is_dir() and (p/'comparison.json').exists() and not p.name.startswith('strained-pressure')]
for path in paths:
 frame=json.loads((path/'frame.json').read_text()); xyz=np.array(frame['positions_nm']);box=np.array(frame['box_lengths_nm'])
 system=mm.XmlSerializer.deserialize((path/'openmm/system.xml').read_text())
 coul=next(f for f in system.getForces() if isinstance(f,mm.NonbondedForce))
 lj=next(f for f in system.getForces() if f.getName()=='lj14')
 charges=[float(coul.getParticleParameters(i)[0].value_in_unit(unit.elementary_charge)) for i in range(len(xyz))]
 scaled={}
 for i in range(lj.getNumBonds()):
  a,b,params=lj.getBondParameters(i);scaled[tuple(sorted((a,b)))]=list(map(float,params))
 text=(path/'lammps/log.lammps').read_text();alpha=float(re.search(r'G vector \(1/distance\)\s*=\s*([\deE+.-]+)',text)[1])*10
 rc=float(coul.getCutoffDistance().value_in_unit(unit.nanometer))
 model=mm.System()
 for _ in xyz:model.addParticle(12)
 vectors=[mm.Vec3(*v) for v in np.diag(box)];model.setDefaultPeriodicBoxVectors(*vectors)
 force=mm.CustomBondForce('4*e*((s/r)^12-(s/r)^6)+138.935456264*(p-q*erf(a*r))/r')
 for name in ('e','s','p','q','a'):force.addPerBondParameter(name)
 force.setUsesPeriodicBoundaryConditions(True);count=0
 for i in range(coul.getNumExceptions()):
  a,b,prod,_,_=coul.getExceptionParameters(i);delta=xyz[b]-xyz[a];delta-=box*np.rint(delta/box);r=np.linalg.norm(delta)
  if r<=rc:continue
  sigma,epsilon=scaled.get(tuple(sorted((a,b))),(1.,0.))
  force.addBond(a,b,[epsilon,sigma,float(prod.value_in_unit(unit.elementary_charge**2)),charges[a]*charges[b],alpha]);count+=1
 model.addForce(force);integrator=mm.VerletIntegrator(.0005);ctx=mm.Context(model,integrator,mm.Platform.getPlatformByName('Reference'));ctx.setPositions(xyz)
 state=ctx.getState(getEnergy=True,getForces=True);energy=float(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole));forces=state.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer)
 row=json.loads((path/'comparison.json').read_text())
 if 'completion' in row:c=row['completion']
 else:
  completed=json.loads((root/'c11-completed.json').read_text());c=next(x['completion'] for x in completed if x['name']=='box-1.5')
 expected=c['energy_lj_kj_mol']+c['energy_coulomb_kj_mol'];energyerror=abs(energy-expected);forceerror=float(np.max(np.abs(forces-c['forces_kj_mol_nm'])))
 assert energyerror<1e-10 and forceerror<1e-10,(path,energyerror,forceerror)
 # Native real-unit dump is parsed independently, with strict atom ordering.
 lines=(path/'lammps/forces.dump').read_text().splitlines();start=next(i for i,x in enumerate(lines) if x.startswith('ITEM: ATOMS'))+1
 atoms=np.array([list(map(float,x.split())) for x in lines[start:]])
 assert atoms[:,0].tolist()==frame['atom_ids']
 assert atoms[:,2].tolist()==charges
 difference=atoms[:,3:6]/10-xyz;assert np.max(np.abs(difference-box*np.rint(difference/box)))<1e-13
 nativeforces=atoms[:,6:9]*41.84
 conversion_error=float(np.max(np.abs(nativeforces-np.array(row['lammps']['forces_kj_mol_nm']))))
 conversion_bound=4*np.finfo(float).eps*max(1.,float(np.max(np.abs(nativeforces))))
 assert conversion_error<=conversion_bound,(path,conversion_error,conversion_bound)
 # Independent finite-volume derivative of the XML-derived correction.
 h=1e-6;energies=[]
 for sign in (-1,1):
  scale=(1+sign*h)**(1/3);ctx.setPeriodicBoxVectors(*[v*scale for v in vectors]);ctx.setPositions(xyz*scale)
  energies.append(float(ctx.getState(getEnergy=True).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)))
 derivative=-(energies[1]-energies[0])/(2*h);virial=float(np.trace(c['virial_kj_mol'])/3)
 assert abs(derivative-virial)<1e-6,(path,derivative,virial)
 reports.append({'case':path.name,'outside_pairs':count,'energy_error_kj_mol':energyerror,'force_max_error_kj_mol_nm':forceerror,'volume_derivative_vs_virial_kj_mol_error':abs(derivative-virial),'raw_dump_mapping_and_force_units':'passed','independent_force_conversion_error':conversion_error,'independent_force_conversion_bound':conversion_bound})
 del ctx,integrator
result={'schema':'island.j40-c12-independent-xml-audit.v1','helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'implementation':'native OpenMM XML particle/exception/LJ14 parameters + independent erf expression and raw real-unit dump parser; no production importer/completion helper','reports':reports,'all_passed':True,'pressure_scope':'isolated special-pair configurational increment only; no full backend qualification','production_validated':False,'simulation_readiness':'not_established'}
Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n');print(len(reports),'independent raw/XML controls passed')
