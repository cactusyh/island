"""Package C13 results without rewriting historical evidence."""
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
from scripts.phase_4j40_c11_numeric import signed,write,sha
root=Path('/tmp/j40-c13-validation'); study=root/'study';v=root/'validation';out=Path('docs/evidence/phase_4j40_c13');out.mkdir(parents=True,exist_ok=True)
summary=json.loads((study/'c13-summary.json').read_text())
source_files=[str(p) for p in sorted(Path('scripts').glob('*phase_4j40_c13*.py'))]+['tests/test_phase_4j40_c13.py','docs/phase_4j40_c13.md']
write(v/'final-source-manifest.json',{'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{p:sha(p) for p in source_files},'note':'Broad suites started on the C12 base with C13 working-tree implementation. Final source hashes are recorded here; final focused/checks and fresh offline reconstruction use these sources. Native C12 helpers remain historically unchanged.'})
commands={'matrix':{'argv':['../island-validation/phase4e2-env/bin/python','-m','scripts.phase_4j40_c12_study','--source','/tmp/j40-validation/final/run','--reference','/tmp/j40-c2-validation/run/reference','--lammps','../island-validation/phase4j22/lmp-kspace','--output',str(study)],'exit_code':1,'note':'Blocked scientific gate; native outputs completed'},'extension':{'argv':['../island-validation/phase4e2-env/bin/python','-m','scripts.phase_4j40_c13_study','--run',str(study),'--lammps','../island-validation/phase4j22/lmp-kspace'],'exit_code':1,'note':'Command reconstructed from orchestration record; native per-point LAMMPS commands retained in artifacts'},'independent_audit':{'argv':['../island-validation/phase4e2-env/bin/python','-m','scripts.phase_4j40_c13_audit',str(study),str(v/'independent-convergence-pressure-audit.json')],'exit_code':0}}
write(v/'numerical-commands.json',commands)
for p in source_files:
 d=v/'final-source'/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
shutil.copyfile(study/'c13-summary.json',out/'summary.json')
with tarfile.open(out/'artifacts.tar.xz','w:xz',preset=6) as t:t.add(study,arcname='study')
# Exclude transient pytest workdirs; retain exact logs, JUnit and environment records.
with tarfile.open(out/'validation.tar.xz','w:xz',preset=6) as t:
 for p in sorted(v.iterdir()):
  if p.is_file() and p.suffix in ('.json','.log','.xml','.py','.txt'):t.add(p,arcname='validation/'+p.name)
 t.add(v/'final-source',arcname='validation/final-source')
with tarfile.open(out/'artifacts.tar.xz') as t:
 inventory={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}
write(out/'artifact-inventory.json',inventory)
history=json.loads((v/'historical-hashes.json').read_text())
assert all(sha(p)==h for p,h in history.items())
checks={}
for mode in ('focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum'):
 checks[mode]=json.loads((v/(mode+'-command.json')).read_text())
 assert checks[mode]['exit_code']==0,(mode,checks[mode])
counts={}
for mode in ('focused','regressions','full'):
 tree=ET.parse(v/(mode+'.xml')); suites=tree.getroot().findall('testsuite')
 counts[mode]={key:sum(int(s.get(key,0)) for s in suites) for key in ('tests','failures','errors','skipped')}
manifest=signed({'schema':'island.j40-c13-manifest.v1','files':{name:sha(out/name) for name in ('summary.json','artifacts.tar.xz','validation.tar.xz','artifact-inventory.json')},'historical_files':history,'implementation_files':{p:sha(p) for p in source_files}})
write(out/'manifest.json',manifest)
receipt=signed({'schema':'island.j40-c13-receipt.v1','base_commit':'b63d8b126fcba11b7f96e0d071646f8bdb6c92ef','implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'manifest_sha256':sha(out/'manifest.json'),'summary_identity':summary['identity'],'numerical_rows':len(summary['rows']),'individual_existing_bound_passes':sum(r['existing_energy_force_bounds_passed'] for r in summary['rows']),'new_actual_polymer_pressure_derivatives':len(summary['pressure']),'native_evaluations':sum(1 for p in study.rglob('point.json')),'policy_status':summary['policy']['status'],'policy_identity':summary['policy']['identity'],'scientific_acceptance':False,'scientific_acceptance_exit_code':1,'ewald_status':'ewald_unvalidated','pressure_status':'pressure_unavailable','cutoff_recovery':'not_executed','long_npt':'not_executed','production_validated':False,'simulation_readiness':'not_established','tests':counts,'checks':{k:{'exit_code':v['exit_code'],'argv':v['argv']} for k,v in checks.items()},'historical_byte_hashes_preserved':len(history),'independent_audits':{'raw_sources':json.loads((v/'raw-source-audit.json').read_text())['all_passed'],'xml_special_pairs':json.loads((v/'independent-xml-audit.json').read_text())['all_passed'],'convergence_and_pressure_arithmetic':json.loads((v/'independent-convergence-pressure-audit.json').read_text())['all_passed']},'limitations':summary['convergence_limitations'],'evidence_references':['summary.json','manifest.json','artifact-inventory.json','artifacts.tar.xz','validation.tar.xz']})
write(out/'receipt.json',receipt)
print(json.dumps({'tests':counts,'rows':receipt['numerical_rows'],'native_evaluations':receipt['native_evaluations'],'history':len(history)},indent=2))
