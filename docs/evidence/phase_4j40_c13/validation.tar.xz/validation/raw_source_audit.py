"""Compare C12 input bytes directly against tracked historical J40 tar members."""
import hashlib,json,tarfile,sys
from pathlib import Path
study=Path(sys.argv[1]);output=Path(sys.argv[2]);historical=Path('docs/evidence/phase_4j40')
index=json.loads((historical/'archive-inventory.json').read_text())['files'];reports=[]
with tarfile.open(historical/'artifacts.tar.xz') as archive:
 for name in ('gaff2-pe','opls-peo','opls-resp-aromatic','opls-network'):
  for suffix,local in [('backend.json',study/'source-originals'/name/'backend.json'),('cross-engine/system.data',study/'source-originals'/name/'system.data')]:
   member='run/'+name+'/'+suffix;raw=archive.extractfile(member).read();current=local.read_bytes();digest=hashlib.sha256(raw).hexdigest()
   assert current==raw and digest==index[member],member
   reports.append({'historical_member':member,'sha256':digest,'byte_identical':True})
output.write_text(json.dumps({'schema':'island.j40-c12-independent-source-audit.v1','historical_archive_sha256':hashlib.sha256((historical/'artifacts.tar.xz').read_bytes()).hexdigest(),'historical_inventory_sha256':hashlib.sha256((historical/'archive-inventory.json').read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'all_passed':True,'files':reports},indent=2)+'\n');print(len(reports),'historical raw source members matched byte-for-byte')
