"""Reconstruct C12 executable input layout exclusively from the archive."""
import shutil,sys
from pathlib import Path
root=Path(sys.argv[1])/'study';dst=Path(sys.argv[2]);dst.mkdir(parents=True,exist_ok=False)
original=root/'c11-rerun/inputs'
for name in ('gaff2-pe','opls-peo','opls-resp-aromatic','opls-network'):
 source=dst/'source'/name;ref=dst/'reference'/name/'cross-engine';source.mkdir(parents=True);ref.mkdir(parents=True)
 shutil.copyfile(root/'additional-inputs'/(name+'-backend.json'),source/'backend.json')
 shutil.copyfile(root/'additional-inputs'/(name+'.data'),ref/'system.data')
 if name=='gaff2-pe':
  shutil.copyfile(original/'backend.json',source/'backend.json')
  for n in ('in.periodic','forces.dump','execution.log'):shutil.copyfile(original/n,ref/n)
  shutil.copyfile(original/'historical-comparison.json',ref.parent/'cross-engine.json')
  for i in (0,1):
   frames=source/f'replica-{i}/uninterrupted';frames.mkdir(parents=True)
   shutil.copyfile(original/f'replica-{i}-frames.json',frames/'frames.json')
