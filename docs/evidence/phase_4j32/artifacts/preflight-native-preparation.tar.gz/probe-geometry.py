import os,sys,random,json
from pathlib import Path
from dataclasses import replace
import numpy as np
import scripts.phase_4j32_real_fixture as f
from island.packing import _rotation_matrix
from scripts.phase_4j32_assignment import prepare,independent_check
original=f.build_linear_polymer
pack=f.pack_multichain_periodic
def build(psmiles,**kw):
 if kw['chain_id']=='J32-chain-2':
  psmiles='[*:1]CCCO[*:2]';kw['dp']=3
 return original(psmiles,**kw)
def packing(units,**kw):
 s=units[0][1]; ids=sorted(s.topology.sites);xyz=np.array([s.coordinates.get(i) for i in ids]); xyz-=xyz.mean(axis=0)
 mass=sum(a.mass for a in s.topology.sites.values()); L=(mass*1.6605390671738466/0.4)**(1/3)
 for seed in range(100000):
  rng=random.Random(seed);r=_rotation_matrix(rng,'random_uniform');t=np.array([rng.random()*L for _ in range(3)]);x=xyz@r.T+t
  if np.all(x>0) and np.all(x<L):break
 else:raise ValueError('No placement')
 print('packing seed',seed,'length',L,flush=True)
 kw['config']=replace(kw['config'],seed=seed)
 return pack(units,**kw)
f.SEED=int(sys.argv[2]); f.pack_multichain_periodic=packing
fixture=f.build_fixture('network');out=Path(sys.argv[1]);out.mkdir();(out/'fixture.json').write_text(json.dumps(fixture.evidence(),indent=2))
os.environ['PATH']=str(f.AMBER/'bin')+os.pathsep+os.environ['PATH']
print(fixture.packed.graph.identity,flush=True)
b=prepare(fixture,'gaff2',out)
(out/'independent.json').write_text(json.dumps(independent_check(b),indent=2));(out/'backend.json').write_text(json.dumps(b.payload,indent=2));print('SUCCESS',flush=True)
