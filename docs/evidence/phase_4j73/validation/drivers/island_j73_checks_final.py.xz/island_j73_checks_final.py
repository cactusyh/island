import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from scripts.phase_4j73_scope import install

install()
out = Path('/tmp/island-j73-checks-1')
out.mkdir(exist_ok=False)
commands = [
    ('ruff', [shutil.which('ruff'), 'check', 'src', 'scripts', 'tests']),
    ('compileall', [sys.executable, '-m', 'compileall', '-q', 'src', 'scripts', 'tests']),
    ('diff', ['git', 'diff', '--check', 'HEAD']),
    ('offline_replay', [sys.executable, '-m', 'scripts.validate_phase_4j73_receipt', 'docs/evidence/phase_4j73', '--replay']),
]
results = []
for name, command in commands:
    start = time.monotonic()
    with (out / (name + '.log')).open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=False)
    results.append({'name': name, 'command': command, 'cwd': os.getcwd(), 'returncode': result.returncode, 'runtime_seconds': time.monotonic() - start, 'log': name + '.log'})
    (out / 'results.json').write_text(json.dumps(results, sort_keys=True, indent=2) + '\n')
    print(name, result.returncode, flush=True)
raise SystemExit(int(any(r['returncode'] for r in results)))
