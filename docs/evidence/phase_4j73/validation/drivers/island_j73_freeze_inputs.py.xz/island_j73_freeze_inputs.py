from pathlib import Path
import hashlib
import os
import subprocess
from scripts.phase_4j73_source_intake import BASE, BRANCH, INPUTS, ROOT, pin, signed, write
from scripts.phase_4j73_scope import install
install()
ROOT.mkdir(exist_ok=False)
names = subprocess.check_output(['git','ls-tree','-r','-z','--name-only',BASE]).decode().split('\0')
history = {}
for name in filter(None,names):
 p = Path(name)
 history[name] = hashlib.sha256(os.readlink(p).encode()).hexdigest() if p.is_symlink() else pin(p)
write(ROOT/'historical-files.json',history)
frozen = signed({'schema':'island.j73-input-freeze.v1','base_commit':BASE,'base_branch':'codex/phase-4j72-c1-execution-scope-correction','branch':BRANCH,'required_ancestors':[BASE,'30737605b8252e2bf0f2265352f0937ee931fd6d'],'fetched_origin_main':subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip(),'base_selection':'exact requested J72-C1 commit','inputs':{n:pin(n) for n in INPUTS},'historical_files_sha256':pin(ROOT/'historical-files.json'),'new_source_artifacts':[],'re_adjudication_authorized':False,'scientific_execution_authorized':False})
write(ROOT/'frozen-inputs.json',frozen)
print('freeze_sha256',pin(ROOT/'frozen-inputs.json'),'historical_files',len(history))
