import shutil
import tarfile
from pathlib import Path
from scripts.phase_4j73_source_intake import ROOT, build
from scripts.phase_4j73_scope import install
install()
with tarfile.open('/tmp/island-j73-build-0-requests.tar.xz','w:xz') as archive:
 for name in ('source-intake.json','artifact-contract.json','source-artifact-requests.json','status-separation.json','no-execution-gate.json','evidence-request-report.md'):
  archive.add(ROOT/name,arcname=name)
new=Path('/tmp/island-j73-build-1-evidence')
new.mkdir(exist_ok=False)
for name in ('frozen-inputs.json','historical-files.json'):
 shutil.copyfile(ROOT/name,new/name)
print(build(Path.cwd(),new))
for name in ('source-intake.json','artifact-contract.json','source-artifact-requests.json','status-separation.json','no-execution-gate.json','evidence-request-report.md'):
 shutil.copyfile(new/name,ROOT/name)
