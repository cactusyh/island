"""Retain software attempts only; never execute a scientific backend."""
import hashlib
import json
import lzma
import os
from pathlib import Path

from scripts.phase_4j73_scope import install

install()
root = Path('docs/evidence/phase_4j73')
validation = root / 'validation'
validation.mkdir(exist_ok=False)
raw_inventory = {}


def retain(source, target, compressed=False):
    raw = source.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(lzma.compress(raw) if compressed else raw)
    raw_inventory[str(target.relative_to(root))] = {
        'original_path': str(source),
        'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'raw_bytes': len(raw),
        'lossless_xz': compressed,
    }


runs = []
for directory in sorted(Path('/tmp').glob('island-j73-*')):
    if not directory.is_dir() or not (directory / 'policy.json').is_file():
        continue
    if directory.resolve() == Path(os.environ['ISLAND_C1_POLICY']).resolve().parent:
        continue
    # This snapshot intentionally contains completed attempts only. The
    # packaging/sealing/strict-validator processes write their audit outside
    # the hash-bound package to avoid circular manifest dependencies.
    if not (directory / 'result.json').is_file():
        raise RuntimeError('unfinished attempt: ' + str(directory))
    target = validation / 'runs' / directory.name
    for name in ('policy.json', 'result.json', 'bootstrap/sitecustomize.py'):
        retain(directory / name, target / name)
    retain(directory / 'events.jsonl', target / 'events.jsonl.xz', True)
    log = directory.with_suffix('.log')
    if log.is_file():
        retain(log, target / 'stdout-stderr.log')
    runs.append(str(target.relative_to(root)))

for i in range(3):
    retain(Path(f'/tmp/island-j73-focused-{i}.xml'), validation / 'attempts' / f'focused-{i}.xml.xz', True)
    retain(Path(f'/tmp/island-j73-collection-{i}.json'), validation / 'attempts' / f'collection-{i}.json')
for i in range(2):
    for path in sorted(Path(f'/tmp/island-j73-checks-{i}').iterdir()):
        if path.is_file():
            retain(path, validation / f'checks-{i}' / path.name)
    retain(Path(f'/tmp/island-j73-checks-launch-{i}.log'), validation / f'checks-{i}' / 'launch.log')
retain(Path('/tmp/island-j73-focused-2.xml'), validation / 'focused.xml.xz', True)
retain(Path('/tmp/island-j73-collection-2.json'), validation / 'collection.json')
retain(Path('/tmp/island-j73-build-0-requests.tar.xz'), validation / 'attempts' / 'initial-request-package.tar.xz')
for name in ('freeze_inputs', 'revise_requests', 'checks', 'checks_final', 'package_attempt0', 'package'):
    path = Path('/tmp/island_j73_' + name + '.py')
    retain(path, validation / 'drivers' / (path.name + '.xz'), True)

records = []
for i, names in ((0, {'C1_receipt', 'pip'}), (1, {'ruff', 'compileall', 'diff', 'offline_replay'})):
    data = json.loads(Path(f'/tmp/island-j73-checks-{i}/results.json').read_text())
    for record in data:
        if record['name'] in names:
            record['log'] = f'validation/checks-{i}/' + record['log']
            records.append(record)
for name, directory in (('focused_tests', 'island-j73-focused-2'), ('relocated_replay', 'island-j73-relocated-1')):
    result = json.loads(Path('/tmp', directory, 'result.json').read_text())
    records.append({
        'name': name,
        'command': result['command'],
        'returncode': result['returncode'],
        'log': f'validation/runs/{directory}/stdout-stderr.log',
        'policy_sha256': result['policy_sha256'],
        'scope': 'software/evidence-only under unchanged J72-C1 fence',
    })

history = {
    'schema': 'island.j73-verification-history.v1',
    'terminal_unique_nodes': 144,
    'terminal_passed': 135,
    'terminal_scope_skipped': 9,
    'terminal_failed': 0,
    'terminal_errors': 0,
    'focused_attempts': [
        {'attempt': 0, 'passed': 134, 'skipped': 9, 'failed': 0, 'additional_terminal_unique_coverage': 0},
        {'attempt': 1, 'passed': 134, 'skipped': 9, 'failed': 1, 'reason': 'New historical-source mutation fixture omitted other required parent files. Intake stopped at a missing parent; copy all 13 inputs before mutation.', 'additional_terminal_unique_coverage': 0},
        {'attempt': 2, 'passed': 135, 'skipped': 9, 'failed': 0, 'role': 'terminal unique coverage'},
    ],
    'lint_failure': {'attempt': 'island-j73-lint-0', 'reason': 'F401 unused importlib.util in test file', 'correction': 'Removed unused import; retained original failed output.'},
    'request_refinement': 'Preserved initial successful package, then added direct retained native FRC lookup identity and incomplete distribution context. No historical input or scientific classification changed.',
    'packaging_failure': {'attempt': 'island-j73-package-0', 'reason': 'The snapshot enumerated its own still-running fence as an unfinished attempt and stopped.', 'correction': 'Exclude only the active policy directory; retain the failed attempt and original driver. Partial output preserved externally.'},
    'scope_controls': 'Nine live scientific controls explicitly skipped; marker-only fake process/module rejection controls passed. No passed live scientific check claimed.',
    'historical_suites': 'Not launched: live scientific engines, converters and scientific reconstruction are outside J73 evidence-only authorization. Unchanged C1 receipt and 9,380-file historical byte audit used instead.',
    'ledger_snapshot': 'All completed pre-seal J73 attempt outputs; packaging, sealing and final strict validation have external ledgers to avoid circular manifest dependencies.',
    'scientific_execution': {'J73_QM_attempts': 0, 'J73_MD_steps': 0, 'J73_converter_attempts': 0, 'J73_fitting': 0, 'J73_parameter_generation': 0, 'J73_reserved_validation': 0},
}
for name, data in (('checks.json', records), ('fenced-runs.json', runs), ('attempt-history.json', history), ('raw-file-identities.json', raw_inventory)):
    (validation / name).write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')
print(json.dumps({'completed_fenced_runs': len(runs), 'retained_raw_files': len(raw_inventory), 'terminal_unique_nodes': 144, 'selected_successful_checks': len(records)}))
