"""Preserve raw diagnostic whitespace losslessly and retain final audit runs."""
import hashlib
import json
import lzma
from pathlib import Path

from scripts.phase_4j73_scope import install

install()
root = Path('docs/evidence/phase_4j73')
validation = root / 'validation'
inventory = json.loads((validation / 'raw-file-identities.json').read_text())


def retain(source, target, compressed=False):
    raw = source.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise RuntimeError('do not overwrite retained attempt ' + str(target))
    target.write_bytes(lzma.compress(raw) if compressed else raw)
    inventory[str(target.relative_to(root))] = {
        'original_path': str(source),
        'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'raw_bytes': len(raw),
        'lossless_xz': compressed,
    }


log = validation / 'runs/island-j73-focused-1/stdout-stderr.log'
raw = log.read_bytes()
target = log.with_suffix('.log.xz')
target.write_bytes(lzma.compress(raw))
old = inventory.pop(str(log.relative_to(root)))
old['lossless_xz'] = True
inventory[str(target.relative_to(root))] = old
log.unlink()  # Same raw bytes retained losslessly, never sanitized.
for name in ('manifest.json', 'receipt.json'):
    retain(root / name, validation / 'attempts' / ('pre-log-compression-' + name + '.xz'), True)

runs = json.loads((validation / 'fenced-runs.json').read_text())
for name in ('island-j73-package-1', 'island-j73-seal-0', 'island-j73-strict-0', 'island-j73-staged-diff-0'):
    source = Path('/tmp') / name
    target = validation / 'runs' / name
    for file in ('policy.json', 'result.json', 'bootstrap/sitecustomize.py'):
        retain(source / file, target / file)
    retain(source / 'events.jsonl', target / 'events.jsonl.xz', True)
    retain(source.with_suffix('.log'), target / 'stdout-stderr.log.xz', True)
    runs.append(str(target.relative_to(root)))
retain(Path(__file__), validation / 'drivers/island_j73_finalize_evidence.py.xz', True)

history = json.loads((validation / 'attempt-history.json').read_text())
history['staged_diff_failure'] = {
    'attempt': 'island-j73-staged-diff-0',
    'reason': 'An original failed pytest traceback contained trailing whitespace, now exposed by staging its raw log.',
    'correction': 'Losslessly XZ-compress that diagnostic log; retain every byte and the failed staged-diff output, rather than edit the original traceback.',
}
for name, data in (('fenced-runs.json', runs), ('attempt-history.json', history), ('raw-file-identities.json', inventory)):
    (validation / name).write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')
print(json.dumps({'completed_fenced_runs': len(runs), 'preserved_raw_traceback_sha256': hashlib.sha256(raw).hexdigest()}))
