import json,lzma,subprocess
from pathlib import Path
from island.pcff_completion import pin,signed,write
repo=Path.cwd();root=repo/'docs/evidence/phase_4j70';dev=repo.parent/'island-validation'
paths=set((repo/'island_ffref').rglob('*'))
paths={p for p in paths if p.is_file()}
for folder in ('phase4h1-sources','phase4h2-upstream','phase4h3-sources','phase4j7-sources'):
 paths.update(p for p in (dev/folder).rglob('*.frc') if '.git' not in p.parts)
base=dev/'phase4h4-upstream/lammps'
paths.update((base/'tools/msi2lmp/frc_files').glob('*'))
paths.update(p for p in (base/'tools/msi2lmp/src').iterdir() if p.suffix in ('.c','.h'))
paths.add(dev/'pdms-author-md-20261028/README.md')
rows=[]
for p in sorted(p for p in paths if p.is_file()):
 name=str(p.resolve());isfrc=p.suffix=='.frc';isnative=isfrc and p.name=='pcff.frc'
 kind='native_pcff' if isnative else 'literature_external' if 'island_ffref' in p.parts else 'research_derived' if 'pdms-author-md-20261028' in p.parts else 'converter_asset' if 'msi2lmp' in p.parts and p.suffix in ('.c','.h') else 'external_comparison'
 rows.append({'path':name,'sha256':pin(p),'size':p.stat().st_size,'category':kind,'version':'pinned LAMMPS revision e891a3e10973c1a729e391a0aefaa02fd70f8c0f' if p.is_relative_to(base) or isnative else 'original mounted file; version authority requires source review','citation':'local mounted source; prior J44/J54/J69 citations and row references preserved separately','license_status':'LAMMPS distribution provenance; FRC third-party notices retained, no new redistribution grant' if isnative else 'not independently licensed for parameter redistribution; original file retained locally only','archive':None,'archive_sha256':None})
record=signed({'schema':'island.j70-source-inventory.v1','base':'efacd4b798a1f345ea05f928905be88ad49acf53','required_J69':'9f379f85f58807d9ae6502da1db712d8fc5680c9','sources':rows,'discovery_scope':['repository tracked source assets and retained J44/J54/J69 inventories','island_ffref (all mounted literature and archive files)','declared phase4h1/h2/h3/h4 and phase4j7 source directories','declared pdms-author-md directory README; simulation output is not an author primary artifact'],'author_primary':{'status':'author_artifact_not_supplied','original_author_artifact_status':'not_yet_supplied','confirmations':'28 user-attested'},'network_downloads':0,'large_raw_archives_committed':False})
write(root/'source-inventory.json',record)
plan=signed({'schema':'island.j70-plan.v1','base':record['base'],'required_J69':record['required_J69'],'source_inventory_sha256':pin(root/'source-inventory.json'),'parent_receipt_sha256':pin(repo/'docs/evidence/phase_4j69/receipt.json'),'policy':'exact source rows and ordinary equivalence only; no wildcard, family borrowing, zero fill, fitting or registration of incomplete rows','source_categories':['native_pcff','author_primary','literature_external','qm_fit_required','research_derived'],'native_converter_attempt_cap':2,'converter_timeout_seconds':60,'worker_count':1,'memory_GiB':4,'static_fixtures':26,'new_QM':0,'MD_steps':0,'production_fits':0,'validation_executions':0,'success_gates':['378 exact instances covered','complete equations units conventions and dependencies','strict original converter complete deterministic emission','independent static energy/force closure','bounded canonical preparation gates'],'failure':'retain every attempt; no completed bundle or execution profile if any source/convention/converter gate fails','solver_calls':0})
write(root/'plan.json',plan)
print('inventory',len(rows),pin(root/'source-inventory.json'),'plan',pin(root/'plan.json'))
