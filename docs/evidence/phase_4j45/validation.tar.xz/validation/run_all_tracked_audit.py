import json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/j45-validation');v=root/'validation';argv=['../island-validation/phase4e2-env/bin/python',str(root/'all_tracked_historical_audit.py')]
env={**os.environ,'PYTHONPATH':'.:src','PYTHONDONTWRITEBYTECODE':'1'}
start=time.time()
with (v/'all_tracked_historical_audit.log').open('w') as log:p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'argv':argv,'cwd':str(Path.cwd()),'environment':{'PYTHONPATH':'.:src','PYTHONDONTWRITEBYTECODE':'1'},'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exit_code':p.returncode,'elapsed_seconds':time.time()-start}
(v/'all_tracked_historical_audit-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));raise SystemExit(p.returncode)
