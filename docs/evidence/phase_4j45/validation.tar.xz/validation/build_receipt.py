"""Package completed J45 blocked qualification and independent verification."""
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
from pathlib import Path
from scripts.phase_4j41_c2 import read
from scripts.phase_4j45 import BASE,BRANCH,J44_SNAPSHOT,reconstruct
from scripts.validate_phase_4j41_receipt import sha,signed
root=Path('/tmp/j45-validation');v=root/'validation';repo=Path.cwd();dest=repo/'docs/evidence/phase_4j45'
commit=(v/'implementation-commit.txt').read_text().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
names=('focused','full','regressions','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum','receipt_j42','receipt_j42_c1','receipt_j43','receipt_j44','historical_byte_audit','relocation','independent_source_audit','all_tracked_historical_audit','execution')
verification={}
for name in names:
 result=json.loads((v/(name+'-command.json')).read_text())
 assert result['exit_code']==(1 if name=='execution' else 0) and result['tested_implementation_commit']==commit,name
 verification[name]=result
report=read(root/'final-study/report.json')
assert len(report['cases'])==6 and report['known_source_files']==52 and report['acceptance_gate']==1
assert report['execution_profiles']==[] and report['backend_executions']==[]
assert [c['status'] for c in report['cases']]==['typing_ambiguous','parameter_incomplete','typing_ambiguous','typing_ambiguous','typing_ambiguous','typing_ambiguous']
assert all(all(stage is False for stage in c['stages'].values()) for c in report['cases'])
historical={**json.loads((v/'all-tracked-historical-document-hashes.json').read_text()),**json.loads((v/'all-tracked-historical-other-hashes.json').read_text())}
assert all(sha(repo/p)==h for p,h in historical.items())
implementation={p:sha(repo/p) for p in ('src/island/forcefields/literature_closure.py','scripts/phase_4j45.py','scripts/audit_phase_4j45_sources.py','scripts/validate_phase_4j45_receipt.py','tests/test_phase_4j45.py','docs/evidence/phase_4j45/selection.json','docs/phase_4j45.md')}
for p,h in implementation.items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':'+p])).hexdigest()==h
for name in ('run_gates.py','run_extra.py','derive_regressions.py','historical_byte_audit.py','all_tracked_historical_audit.py','run_all_tracked_audit.py','run_source_audit.py','build_receipt.py','check_receipt_mutations.py','finish_package.py'):shutil.copyfile(root/name,v/name)
def files(folder):return {str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
for archive,source,arcname in [('execution.tar.xz',root/'final-study','study'),('validation.tar.xz',v,'validation')]:
 with tarfile.open(dest/archive,'w:xz',preset=6) as tar:tar.add(source,arcname=arcname)
source_hashes=read(root/'final-study/source-hashes.json')
manifest=signed({'schema':'island.j45-manifest.v1','base_commit':BASE,'historical_snapshot':J44_SNAPSHOT,'historical_files':historical,'implementation_files':implementation,'source_asset_hashes':source_hashes,'profile_identity':None,'profile_identities':[],'archives':{n:sha(dest/n) for n in ('execution.tar.xz','validation.tar.xz')},'study_files':files(root/'final-study'),'validation_files':files(v)})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
counts={name:{k:sum(int(s.attrib.get(k,0)) for s in E.parse(v/(name+'.xml')).getroot()) for k in ('tests','failures','errors','skipped')} for name in ('focused','full','regressions')}
assert all(c['failures']==c['errors']==0 for c in counts.values())
independent=json.loads((v/'independent_source_audit.log').read_text())
assert independent['raw_source_files_verified']==52 and independent['selected_coefficient_rows_reconstructed']==17
receipt=signed({'schema':'island.j45-receipt.v1','base_commit':BASE,'branch':BRANCH,'j44_unchanged_prerequisite_snapshot':J44_SNAPSHOT,'tested_implementation_commit':commit,'status':'parameter_incomplete','acceptance_gate':1,'native_pcff_acceptance_gate':1,'execution_profiles':[],'backend_executions':[],'production_validated':False,'simulation_readiness':'not_established','limitations':report['limitations'],'manifest_sha256':sha(dest/'manifest.json'),'study_report':report,'source_asset_hashes':source_hashes,'accepted_parameter_rows':0,'profile_identity':None,'independent_source_reconstruction':independent,'reconstruction':reconstruct(root/'final-study'),'relocation':json.loads((v/'relocation-file-hashes.json').read_text()),'verification':verification,'test_counts':counts,'regression_scope':'Exact J22-J44 subset of supported full execution; no second execution claimed','historical_bytes_match_snapshot':True,'historical_files_preserved':len(historical),'native_forcefields_c5_schema_and_historical_receipts_unchanged':True,'prior_harness_attempt':'Retained in validation/prior-harness-attempt.tar.xz: missing pytest temporary parent directory, interrupted full run, then corrected before completed runs. No implementation result inferred from interrupted attempt.','historical_receipt_validation':'Unchanged J42-C1/J43/J44 validators at current runtime; unchanged J42 validator source pins at original detached snapshot','source_files_redistributed':False})
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'test_counts':counts,'historical_files':len(historical),'source_files':len(source_hashes),'study_files':len(files(root/'final-study'))},indent=2))
