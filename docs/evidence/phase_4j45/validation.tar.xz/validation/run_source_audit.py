import json,subprocess,time,os,sys
from pathlib import Path
r=Path('/tmp/j45-validation');v=r/'validation';py=sys.executable
name='independent_source_audit';args=[py,'scripts/audit_phase_4j45_sources.py','--references','island_ffref','--catalog','docs/evidence/phase_4j44/source-audit.json','--selection','docs/evidence/phase_4j45/selection.json']
start=time.time();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
env={**os.environ,'PYTHONPATH':'.:src','PYTHONDONTWRITEBYTECODE':'1'}
with (v/(name+'.log')).open('w') as out,(v/(name+'-stderr.log')).open('w') as err:
 p=subprocess.run(args,env=env,stdout=out,stderr=err)
rec={'argv':args,'cwd':str(Path.cwd()),'environment':{'PYTHONPATH':'.:src','PYTHONDONTWRITEBYTECODE':'1'},'tested_implementation_commit':commit,'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'source_catalog_sha256':__import__('hashlib').sha256(Path('docs/evidence/phase_4j44/source-audit.json').read_bytes()).hexdigest()}
(v/(name+'-command.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec))
raise SystemExit(p.returncode)
