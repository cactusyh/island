import subprocess,json,os,time
from pathlib import Path
from island.analysis.npt import _signed,_write_json,FLAGS
r=Path('/tmp/j40-c2-validation/run');p=r/'opls-resp-aromatic/replica-2/uninterrupted'
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'}
code='from island.analysis.npt_continuation import load_continuation;load_continuation('+repr(str(p))+');print("Strict historical v1 reconstruction passed")'
rows={}
for name,python in [('execution','../island-validation/phase4g1-env/bin/python'),('supported','../island-validation/phase4e2-env/bin/python')]:
 argv=[python,'-c',code];start=time.time();q=subprocess.run(argv,env=env,capture_output=True,text=True,check=False)
 rows[name]={'argv':argv,'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'elapsed_seconds':time.time()-start}
assert rows['execution']['exit_code']==0
assert rows['supported']['exit_code']!=0
_write_json(r/'legacy-analysis-reconstruction.json',_signed(dict(schema='island.j40-c2-legacy-analysis-reconstruction.v1',results=rows,diagnostic='Historical NumPy convolve rolling means differ by last bits across these installations; original v1 record and strict loader retained unchanged. Additive C2 statistics are independently recomputed with fsum; no scientific threshold changed.',**FLAGS)))
