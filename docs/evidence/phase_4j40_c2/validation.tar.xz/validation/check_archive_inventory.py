import json,hashlib
from pathlib import Path
from scripts.phase_4j40_c2_archive import open_artifacts
out=Path('docs/evidence/phase_4j40_c2');expected=json.loads((out/'artifact-inventory.json').read_text());actual={}
with open_artifacts(out) as archive:
 for member in archive:
  if member.isfile():
   digest=hashlib.sha256()
   stream=archive.extractfile(member)
   while block:=stream.read(1024*1024):digest.update(block)
   actual[member.name]=digest.hexdigest()
assert actual==expected,({k for k in expected if expected.get(k)!=actual.get(k)},set(actual)-set(expected))
(out/'archive-integrity.json').write_text(json.dumps({'schema':'island.j40-c2-archive-integrity.v1','status':'passed','files':len(actual),'inventory_sha256':hashlib.sha256((out/'artifact-inventory.json').read_bytes()).hexdigest(),'parts_manifest_sha256':hashlib.sha256((out/'artifact-parts.json').read_bytes()).hexdigest()},indent=2)+'\n')
print(len(actual),'archived files independently hash-verified',flush=True)
