import json,tarfile,shutil
from math import fsum
from pathlib import Path
from island.analysis.npt import _signed,_write_json
from scripts.phase_4j40_c2_analysis import trajectory
root=Path('/tmp/j40-c2-validation/run');v=Path('/tmp/j40-c2-validation/validation');pre=v/'preliminary/component-sum';pre.mkdir(parents=True)
for name in ['focused.log','focused.xml','focused-command.json','j22-j40.log','j22-j40.xml','j22-j40-command.json','full_supported.log','full_supported.xml','full_supported-command.json','archive-command.json']:
 if (v/name).exists():shutil.move(v/name,pre/name)
with tarfile.open(pre/'original-component-metadata.tar.xz','w:xz') as a:
 for p in root.glob('*/replica-*/component-energies.json'):a.add(p,arcname=str(p.relative_to(root)))
for p in root.glob('*/replica-*/component-energies.json'):
 record=json.loads(p.read_text());_,_,frames,_=trajectory(p.parent)
 for row,frame in zip(record['rows'],frames,strict=True):
  row['sum_error_kj_mol']=abs(fsum(row['components_kj_mol'].values())-frame['potential_energy_kj_mol'])
  row['passed']=row['sum_error_kj_mol']<=1e-5
 record['passed']=all(r['passed'] for r in record['rows']);record['summation']='math.fsum';record.pop('identity');_write_json(p,_signed(record))
 print(str(p),max(r['sum_error_kj_mol'] for r in record['rows']),flush=True)
# Discard no original trajectory: only superseded incomplete compressed publication
# and its manifests are moved out of the final evidence namespace.
out=Path('docs/evidence/phase_4j40_c2');dest=Path('/tmp/j40-c2-validation/preliminary-publication');dest.mkdir()
for p in out.iterdir():shutil.move(p,dest/p.name)
