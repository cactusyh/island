import json
from pathlib import Path
from island.analysis.npt import analyze_npt_frames
p=Path('/tmp/j40-c2-validation/run/opls-resp-aromatic/replica-2/uninterrupted')
f=json.loads((p/'frames.json').read_text())['frames'];m=json.loads((p/'manifest.json').read_text());a=json.loads((p/'analysis.json').read_text())
b=analyze_npt_frames(f,total_mass_dalton=m['total_mass_dalton'],target_temperature_kelvin=m['config']['temperature_kelvin'],target_pressure_bar=m['config']['pressure_bar'])
def diff(a,b,path=''):
 if type(a)!=type(b):print(path,'types',type(a),type(b));return
 if isinstance(a,dict):
  for k in b:diff(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 elif a!=b:print(path,repr(a),repr(b),'delta',a-b if isinstance(a,float) else '')
diff(a,b)
