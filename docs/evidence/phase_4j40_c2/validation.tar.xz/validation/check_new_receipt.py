import time,json,subprocess,os,concurrent.futures,hashlib
from pathlib import Path
out=Path('docs/evidence/phase_4j40_c2');receipt=out/'receipt.json'
while True:
 try:
  value=json.loads(receipt.read_text())
  if value.get('identity'):break
 except (OSError,ValueError):pass
 time.sleep(5)
input_sha=hashlib.sha256(receipt.read_bytes()).hexdigest()
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
def run(name,extra,expected):
 argv=['../island-validation/phase4e2-env/bin/python','-m','scripts.validate_phase_4j40_c2_receipt',str(receipt),*extra]
 start=time.time()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 row={'argv':argv,'exit_code':r.returncode,'expected_exit_code':expected,'elapsed_seconds':time.time()-start,'receipt_sha256':input_sha,'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
 print(name,r.returncode,flush=True)
 return name,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=dict(pool.map(lambda args:run(*args),[('receipt-integrity',['--diagnostic-only'],0),('receipt-acceptance',[],1)]))
(out/'receipt-validation.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(row['exit_code']==row['expected_exit_code'] for row in results.values()),results
