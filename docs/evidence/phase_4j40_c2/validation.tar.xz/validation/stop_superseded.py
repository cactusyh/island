import os,signal,json
from pathlib import Path
procs={}
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=[a.decode() for a in (p/'cmdline').read_bytes().split(b'\0') if a];ppid=int((p/'stat').read_text().split()[3]);procs[int(p.name)]=(ppid,args)
 except (OSError,UnicodeDecodeError,ValueError):continue
roots={pid for pid,(ppid,args) in procs.items() if len(args)>=2 and args[1] in ['/tmp/j40-c2-validation/validation/'+n for n in ('gates.py','archive_run.py','split_archive.py','build_receipt.py')]}
roots|={pid for pid,(ppid,args) in procs.items() if any(a.startswith('--junitxml=/tmp/j40-c2-validation/validation/') for a in args)}
allp=set(roots)
while True:
 more={pid for pid,(ppid,args) in procs.items() if ppid in allp}
 if more<=allp:break
 allp|=more
rows=[]
for pid in sorted(allp):
 try:os.kill(pid,signal.SIGTERM);rows.append({'pid':pid,'argv':procs[pid][1],'signal':'SIGTERM','reason':'Stop superseded component-sum verification and archive; fix serialization-order bookkeeping without changing trajectories or tolerances.'})
 except ProcessLookupError:pass
Path('/tmp/j40-c2-validation/validation/component-interruptions.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'superseded processes stopped')
