import time,concurrent.futures
from pathlib import Path
from scripts.phase_4j40_c2_finalize import post
from scripts.phase_4j40_c2_analysis import read,replica_analysis
from scripts.validate_phase_4j40 import CASES
from scripts.validate_phase_4j40_c2 import BASE
from island.analysis.npt import _signed,_write_json,FLAGS
from island.analysis.equilibration_protocol import CorrectiveProtocol
root=Path('/tmp/j40-c2-validation/run')
def work(path):
 while not (path/'result.json').exists():time.sleep(5)
 result=post(path);print(str(path),result['continuation_status'],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
 list(pool.map(work,[root/key/f'replica-{i}' for key in CASES for i in range(3)]))
m=_signed(dict(schema='island.j40-c2-matrix.v1',base_commit=BASE,protocol=CorrectiveProtocol().payload,execution_policy='execute full maximum budget; integration errors terminate a replica, scientific preflight failures do not suppress attempts',cases={k:[read(root/k/f'replica-{i}/result.json') for i in range(3)] for k in CASES},replica_diagnostics={k:replica_analysis([root/k/f'replica-{i}' for i in range(3)]) for k in CASES},scientific_acceptance=False,blocked_gates=['pressure_unavailable','cross_engine_discrepancy','integration_failure_or_insufficient_sampling'],unsupported_origins={'native_aromatic_oplsaa':'source_incompatible','native_am1bcc':'blocked_precision','unsupported_pcff':'typing_rejection'},**FLAGS))
_write_json(root/'matrix.json',m)
