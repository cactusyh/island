import time,json,tarfile,shutil,subprocess,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
from island.analysis.npt import _signed,_write_json,FLAGS
from scripts.validate_phase_4j40_c2_receipt import SOURCES,history
from scripts.validate_phase_4j40_c2 import BASE
v=Path('/tmp/j40-c2-validation/validation');out=Path('docs/evidence/phase_4j40_c2')
required=['focused','j22-j40','full_supported','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
while not all((v/(n+'-command.json')).exists() for n in required) or not (v/'archive-command.json').exists():time.sleep(5)
gates={n:json.loads((v/(n+'-command.json')).read_text()) for n in required}
for n,r in gates.items():assert r['exit_code']==0,(n,r)
for n in ['focused','j22-j40','full_supported']:
 suites=ET.parse(v/(n+'.xml')).getroot().findall('testsuite')
 gates[n]['junit']={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
# Retain the preliminary failure and interruption records without counting them as passed gates.
for p in Path('/tmp/j40-c2-validation').glob('*.log'):shutil.copyfile(p,v/('progress-'+p.name))
shutil.copyfile('/tmp/j40-c2-validation/environments.json',out/'environments.json')
with tarfile.open(out/'validation.tar.xz','w:xz') as archive:
 for p in sorted(v.rglob('*')):
  if p.is_file() and not any(x.endswith('-tmp') or x=='__pycache__' for x in p.relative_to(v).parts):archive.add(p,arcname=str(Path('validation')/p.relative_to(v)))
m=json.loads(Path('/tmp/j40-c2-validation/run/matrix.json').read_text())
artifacts=json.loads((out/'artifact-inventory.json').read_text())
receipt=_signed(dict(schema='island.j40-c2-receipt.v1',base_commit=BASE,tested_implementation_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),final_evidence_commit_resolution='git log --diff-filter=A --format=%H -1 -- docs/evidence/phase_4j40_c2/receipt.json',implementation_sources={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in SOURCES},historical_files=history(),matrix_identity=m['identity'],scientific_acceptance=False,validation=gates,artifacts=artifacts,files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name not in {'receipt.json','receipt-integrity.log','receipt-acceptance.log','receipt-validation.json'}},blocked_gates=m['blocked_gates']+['native_v1_cross_environment_rolling_mean_bit_equality'],execution_notes=['Real integration began before the final additive analysis/validator code freeze. Numerical MD executor and model builder stayed byte-identical to C1; exact command records retain the actual invocation commits. Final focused/regression/full tests use the tested implementation commit.','Eleven full-budget requests terminate at the unchanged box/cutoff guard. One aromatic replica executes the full 1 ns NPT budget.','The redundant legacy continuation for the full-budget aromatic run is intentionally interrupted; an independently prepared, relocated parallel C2 continuation supplies the required complete comparison.','Original v1 summary bytes and strict loader are unchanged. Same-runtime v1 loading passes; supported-runtime convolution last-bit mismatch remains explicitly recorded. C2 statistics reconstruct independently without introducing tolerances.'],**FLAGS))
_write_json(out/'receipt.json',receipt)
print(json.dumps({n:r.get('junit',r['exit_code']) for n,r in gates.items()},indent=2),flush=True)
