import json,hashlib
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['svg.hashsalt']='island-j40-c2'
import matplotlib.pyplot as plt
root=Path('/tmp/j40-c2-validation/run');out=Path('docs/evidence/phase_4j40_c2');cases=['gaff2-pe','opls-resp-aromatic','opls-peo','opls-network']
fig,axes=plt.subplots(3,4,figsize=(13,8),layout='constrained',sharex='col')
hashes={}
for col,case in enumerate(cases):
 for i in range(3):
  p=root/case/f'replica-{i}/observations.json';d=json.loads(p.read_text());hashes[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
  cfg=json.loads((p.parent/'config.json').read_text());rows=[f for f in d['observations'] if f['stage']=='npt']
  x=[(f['step']-cfg['nvt_steps'])*cfg['timestep_fs']/1000 for f in rows]
  for row,key in enumerate(['density_g_cm3','measured_temperature_kelvin','volume_nm3']):
   ax=axes[row,col];ax.plot(x,[f[key] for f in rows],lw=.6,alpha=.8,label=f'Replica {i}'+(' (1 ns complete)' if d['complete'] else ' (cutoff failure)'))
   ax.set_xscale('log');ax.grid(alpha=.2)
  axes[0,col].set_title(case,fontsize=10)
 for row in range(3):axes[row,col].tick_params(labelsize=8)
 axes[1,col].axhline(300,color='black',ls='--',lw=.8,label='Requested 300 K')
 axes[2,col].set_xlabel('NPT time (ps, log scale)',fontsize=9)
 axes[0,col].legend(fontsize=6,loc='best')
for row,label in enumerate(['Density (g/cm³)','Kinetic temperature (K)','Volume (nm³)']):axes[row,0].set_ylabel(label)
fig.suptitle('Actual retained NPT traces: one full-budget run, eleven integration failures\nPressure unavailable; scientific acceptance blocked',fontsize=12)
fig.savefig(out/'npt-traces.svg',metadata={'Date':None});fig.savefig(out/'npt-traces.pdf',metadata={'CreationDate':None,'ModDate':None});fig.savefig('/tmp/j40-c2-validation/traces-preview.png',dpi=110);plt.close(fig)
(out/'plot-provenance.json').write_text(json.dumps({'schema':'island.j40-c2-plot.v1','source':'actual retained NPT observations; no experimental data, no target density or target pressure used as observation','matplotlib':matplotlib.__version__,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashes,'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'npt-traces.svg',out/'npt-traces.pdf']}},indent=2)+'\n')
