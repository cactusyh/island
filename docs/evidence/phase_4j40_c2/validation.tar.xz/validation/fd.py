import json
from pathlib import Path
from scripts.phase_4j40_c2_finite_difference import audit
from island.analysis.npt import _write_json
p=json.load(open('/tmp/j40-validation/final/run/opls-network/backend.json'))
f=json.load(open('/tmp/j40-validation/final/run/opls-network/replica-0/uninterrupted/frames.json'))['frames'][0]
for partition in ('ordinary','crosslink'):
 r=audit(p,f['positions_nm'],sorted(s['id'] for s in p['final_graph']['sites']),partition=partition)
 _write_json(Path('/tmp/j40-c2-validation/run')/(partition+'-finite-difference.json'),r)
 print(partition,r['passed'],flush=True)
