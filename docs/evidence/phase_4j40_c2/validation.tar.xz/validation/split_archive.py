from pathlib import Path
from hashlib import sha256
import json,time
out=Path('docs/evidence/phase_4j40_c2')
while not Path('/tmp/j40-c2-validation/validation/archive-command.json').exists():time.sleep(5)
p=out/'artifacts.tar.xz'
if p.stat().st_size>80*1024*1024:
 digest=sha256();parts=[];total=0
 with p.open('rb') as stream:
  i=0
  while raw:=stream.read(80*1024*1024):
   name=f'artifacts.tar.xz.part-{i:03d}';(out/name).write_bytes(raw);digest.update(raw);total+=len(raw)
   parts.append({'name':name,'size_bytes':len(raw),'sha256':sha256(raw).hexdigest()});i+=1
 record={'schema':'island.lossless-archive-parts.v1','size_bytes':total,'sha256':digest.hexdigest(),'parts':parts}
 (out/'artifact-parts.json').write_text(json.dumps(record,indent=2)+'\n')
 p.unlink()
 print('lossless archive parts',len(parts),'total',total,flush=True)
else:print('single archive',p.stat().st_size,flush=True)
