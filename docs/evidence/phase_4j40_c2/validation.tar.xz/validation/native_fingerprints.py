import subprocess,json,hashlib
from pathlib import Path
pythons={'supported':'../island-validation/phase4e2-env/bin/python','foyer_openmm':'../island-validation/phase4g1-env/bin/python','analysis':'../island-validation/phase4j32-analysis-env/bin/python','ambertools':'../miniforge3/envs/md_rg/bin/python','quantum':'../island-validation/phase4j36-native-env/bin/python'}
code='''import sys,sysconfig,json,hashlib,importlib.util
from pathlib import Path
origins={}
roots=[]
for name in ('openmm','numpy','matplotlib','psi4'):
 spec=importlib.util.find_spec(name)
 if spec is not None and spec.origin:
  origin=Path(spec.origin).resolve();origins[name]=str(origin);roots.append(origin.parent)
  if name=='openmm':roots.append(origin.parent.parent/'OpenMM.libs')
  if name=='numpy':roots.append(origin.parent.parent/'numpy.libs')
files={p.resolve() for root in roots if root.is_dir() for p in root.rglob('*') if p.is_file() and ('.so' in p.name or p.suffix=='.dylib')}
files|={p.resolve() for p in (Path(sys.prefix)/'lib').glob('*OpenMM*.so*') if p.is_file()}
print(json.dumps({'executable':sys.executable,'resolved_module_origins':origins,'native_libraries':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}))
'''
rows={}
for name,py in pythons.items():
 p=subprocess.run([py,'-c',code],capture_output=True,text=True,check=False);assert p.returncode==0,p.stderr
 rows[name]={**json.loads(p.stdout),'argv':[py,'-c',code],'exit_code':p.returncode}
out=Path('docs/evidence/phase_4j40_c2/native-library-fingerprints.json');out.write_text(json.dumps(rows,indent=2)+'\n')
print({name:len(row['native_libraries']) for name,row in rows.items()})
