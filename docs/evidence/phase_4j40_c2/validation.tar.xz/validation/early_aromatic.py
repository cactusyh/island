from pathlib import Path
from scripts.phase_4j40_c2_analysis import read
from scripts.phase_4j38_fixture import build
from scripts.validate_phase_4j40 import backend_for
from island.analysis.equilibration_run import run_heated_workflow
from island.analysis.equilibration_protocol import CorrectiveProtocol
from island.analysis.npt import NPTConfiguration,_write_json
from island.analysis.npt_continuation import relocate_continuation,require
from scripts.validate_phase_4j38_c3 import command
import sys
root=Path('/tmp/j40-c2-validation/run/opls-resp-aromatic/replica-2')
out=root/'independent-early-continuation';out.mkdir()
f,e=build('aromatic');b=backend_for('opls-resp-aromatic',f,out,Path('/tmp/j40-validation/final/run/raw'))
require(b.payload==read(root/'backend.json'),'Early continuation backend differs')
c=NPTConfiguration.from_payload(read(root/'config.json'))
run_heated_workflow(b,c,out/'split',stop_npt_step=100,heating=CorrectiveProtocol().heating)
r=relocate_continuation(out/'split',out/'relocated')
args=[sys.executable,'-m','scripts.phase_4j40_c2_resume','--resume',str(out/'relocated'),'--destination',str(out/'attempt'),'--restart',r['identity'],'--parent',r['parent_workflow_identity'],'--config',c.identity]
code=command(args,out/'resume')
print('Independent parallel continuation finished:',code,flush=True)
