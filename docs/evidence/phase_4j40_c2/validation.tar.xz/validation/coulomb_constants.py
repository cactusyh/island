import json,math,subprocess,re
from pathlib import Path
from hashlib import sha256
import openmm as mm
from openmm import unit
from island.analysis.npt import _signed,_write_json,FLAGS
root=Path('/tmp/j40-c2-validation/run/electrostatic-unit-control');root.mkdir()
model=mm.System();model.addParticle(1);model.addParticle(1)
f=mm.NonbondedForce();f.setNonbondedMethod(f.NoCutoff);f.addParticle(1,1,0);f.addParticle(-1,1,0);model.addForce(f)
i=mm.VerletIntegrator(.001);c=mm.Context(model,i,mm.Platform.getPlatformByName('Reference'));c.setPositions([[0,0,0],[1,0,0]])
s=c.getState(getEnergy=True,getForces=True);energy=s.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
forces=s.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer).tolist();del c,i
(root/'control.data').write_text('Mathematical two-charge unit calibration, not a molecular benchmark\n\n2 atoms\n1 atom types\n\n0 50 xlo xhi\n0 50 ylo yhi\n0 50 zlo zhi\n\nMasses\n\n1 1\n\nAtoms # charge\n\n1 1 1 20 20 20\n2 1 -1 30 20 20\n')
(root/'control.in').write_text('units real\natom_style charge\nboundary f f f\nread_data control.data\npair_style coul/cut 15\npair_coeff * *\nneighbor 2 bin\nthermo_style custom step ecoul\nthermo 1\ndump control all custom 1 forces.dump id fx fy fz\ndump_modify control sort id\nrun 0\nprint "COULOMB_CONTROL $(ecoul:%.17g)"\n')
exe=Path('../island-validation/phase4j22/lmp-kspace').resolve();r=subprocess.run([str(exe),'-in','control.in'],cwd=root,text=True,capture_output=True,check=False)
(root/'execution.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
lmp=float(re.search(r'COULOMB_CONTROL (-?[0-9.eE+]+)',r.stdout).group(1))*4.184
header=Path('../island-validation/phase4e2-env/lib/python3.11/site-packages/OpenMM.libs/include/openmm/reference/SimTKOpenMMRealType.h')
raw=subprocess.check_output(['git','-C','../island-validation/phase4h4-upstream/lammps','show','36f7c81ced8dd456430b13647e48f0c7d7bd8faa:src/update.cpp'])
(root/'lammps-update.cpp').write_bytes(raw);(root/'openmm-constants.h').write_bytes(header.read_bytes())
record=_signed(dict(schema='island.j40-c2-coulomb-unit-control.v1',scope='two point charges at 1 nm, mathematical nonperiodic unit control; not a polymer workflow, not KSPACE acceptance',openmm_version=mm.version.full_version,openmm_energy_kj_mol=energy,openmm_forces_kj_mol_nm=forces,lammps_energy_kj_mol=lmp,coulomb_prefactor_openmm=-energy,coulomb_prefactor_lammps=-lmp,relative_prefactor_difference=abs(energy/lmp-1),source_header_sha256=sha256(header.read_bytes()).hexdigest(),lammps_source_sha256=sha256(raw).hexdigest(),executable_sha256=sha256(exe.read_bytes()).hexdigest(),files={p.name:sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()},interpretation='Small native Coulomb-prefactor difference confirmed without rescaling; periodic Ewald errors remain unresolved and acceptance remains failed.',**FLAGS))
_write_json(root/'result.json',record);print(json.dumps(record,indent=2))
