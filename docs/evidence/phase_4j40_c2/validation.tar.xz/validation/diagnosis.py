from pathlib import Path
from scripts.phase_4j40_c2_analysis import read
from scripts.validate_phase_4j40 import CASES
from island.analysis.npt import _signed,_write_json,_digest,FLAGS
root=Path('/tmp/j40-c2-validation/run')
rows={}
for key in CASES:
 r=read(root/'reference'/key/'cross-engine.json');p=read(root/'reference'/key/'input-parity.json')
 rows[key]={'static_reference_identity':_digest(r),'input_parity_identity':p['identity'],'geometry':'exact original packed graph; same coordinates in both engines',
 'units':{'input_conversion':'passed','native_coulomb_prefactors':'small_difference_measured_in_separate_unit_control; no rescaling'},
 'atom_order_masses_charges_parameters_exclusions_mixing_scaling_cutoff':p,
 'periodic_images':{'status':'input_box_and_coordinates_exact','remaining':'full term-by-term periodic-image attribution not proved'},
 'neighbor_list':{'status':'native fixed-cutoff settings retained','remaining':'no tolerance widening or cutoff change; cutoff sensitivity remains a separate boundary'},
 'force_sign':{'finite_difference_check':r['checks']['finite_difference'],'scope':'original historical first/last atom audit; full minimized network audit stored separately'},
 'long_range':{'method':'actually executed KSPACE Ewald','requested_relative_accuracy':1e-5,'absolute_reference_agreement':r['passed'],'component_errors_kj_mol':r['component_errors_kj_mol'],'max_force_error_kj_mol_angstrom':r['force_max_error_kj_mol_angstrom'],'diagnosis':'electrostatic discrepancy unresolved; different truncation/splitting and prefactors remain distinct from export parity; PPPM not executed'},
 'scientific_acceptance':False}
_write_json(root/'cross-engine-diagnosis.json',_signed(dict(schema='island.j40-c2-cross-engine-diagnosis.v1',cases=rows,unit_control_identity=read(root/'electrostatic-unit-control/result.json')['identity'],**FLAGS)))
