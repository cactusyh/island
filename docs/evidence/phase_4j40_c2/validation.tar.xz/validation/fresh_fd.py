import json
from pathlib import Path
from scripts.phase_4j40_c2_analysis import trajectory
from scripts.phase_4j40_c1_finite_difference import audit as complete_audit
from scripts.phase_4j40_c2_finite_difference import audit
from island.analysis.npt import _write_json,_signed,_digest,FLAGS
root=Path('/tmp/j40-c2-validation/run'); dest=root/'fresh-network-finite-difference';dest.mkdir()
p,c,frames,complete=trajectory(root/'opls-network/replica-0')
ids=sorted(s['id'] for s in p['final_graph']['sites']);xyz=frames[0]['positions_nm']
for name,record in [('full',complete_audit(p,xyz,ids)),('ordinary',audit(p,xyz,ids,partition='ordinary')),('crosslink',audit(p,xyz,ids,partition='crosslink'))]:
 _write_json(dest/(name+'.json'),record); print(name,record['passed'],flush=True)
_write_json(dest/'mapping.json',_signed(dict(schema='island.j40-c2-fd-geometry.v1',backend_identity=p['identity'],frame_identity=_digest(frames[0]),geometry_stage='minimize',origin='fresh_C2_minimization',**FLAGS)))
