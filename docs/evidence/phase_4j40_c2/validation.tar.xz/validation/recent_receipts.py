import os,subprocess,json,time
from pathlib import Path
v=Path('/tmp/j40-c2-validation/validation');py='../island-validation/phase4g1-env/bin/python'
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
for phase,flag in [('4j38_c1','--diagnostic-only'),('4j38_c2','--diagnostic-only'),('4j38_c3','--diagnostic-only'),('4j39','--software-only'),('4j40','--diagnostic-only'),('4j40_c1','--diagnostic-only')]:
 cmd=[py,'-m','scripts.validate_phase_'+phase+'_receipt','docs/evidence/phase_'+phase+'/receipt.json',flag]
 start=time.time()
 with (v/(phase+'-receipt.log')).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 (v/(phase+'-receipt-command.json')).write_text(json.dumps({'argv':cmd,'exit_code':r.returncode,'elapsed_seconds':time.time()-start,'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n')
 print(phase,r.returncode,flush=True)
 assert r.returncode==0
