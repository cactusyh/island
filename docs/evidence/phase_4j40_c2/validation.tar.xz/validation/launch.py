import os,subprocess,json,time,concurrent.futures
from pathlib import Path
from island.forcefields.ambertools.runtime import declared_environment
root=Path('/tmp/j40-c2-validation/run')
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
amber=json.loads(Path('docs/evidence/phase_4j34/runtime.json').read_text())
def run(case,replica):
 dest=root/case/('replica-'+str(replica)); dest.parent.mkdir(exist_ok=True)
 cmd=['../island-validation/phase4g1-env/bin/python','-m','scripts.validate_phase_4j40_c2','--case',case,'--replica',str(replica),'--output',str(dest),'--raw','/tmp/j40-validation/final/run/raw']
 e={**env,**declared_environment(amber)} if case=='gaff2-pe' else env
 start=time.time()
 with (dest.parent/(dest.name+'.log')).open('w') as log: r=subprocess.run(cmd,env=e,stdout=log,stderr=subprocess.STDOUT)
 (dest.parent/(dest.name+'-command.json')).write_text(json.dumps({'argv':cmd,'environment':{k:e[k] for k in ('PYTHONPATH','PATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'elapsed_seconds':time.time()-start,'exit_code':r.returncode},indent=2)+'\n')
 print(case,replica,r.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
 list(pool.map(lambda pair:run(*pair),[(case,i) for case in ('gaff2-pe','opls-resp-aromatic','opls-peo','opls-network') for i in range(3)]))
