import json
from pathlib import Path
from scripts.validate_phase_4j40_c2_receipt import history
rows=history()
Path('/tmp/j40-c2-validation/historical-files.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
print(len(rows),'historical evidence entries unchanged, including Git symlink text')
