import json,time,subprocess,hashlib
from pathlib import Path
from island.analysis.npt import _signed,_write_json,FLAGS
from scripts.validate_phase_4j40 import CASES
root=Path('/tmp/j40-c2-validation/run');out=Path('docs/evidence/phase_4j40_c2')
while not (root/'matrix.json').exists():time.sleep(5)
m=json.loads((root/'matrix.json').read_text());rows={}
for case in CASES:
 rows[case]=[]
 for i in range(3):
  r=root/case/f'replica-{i}';o=json.loads((r/'observations.json').read_text());b=json.loads((r/'backend.json').read_text());cmp=json.loads((r/'partial-comparison.json').read_text())
  rows[case].append({'replica':i,'charge_origin':CASES[case][1],'graph_identity':b['final_graph_identity'],'packing_identity':b['system']['metadata']['packing']['plan_identity'],'source_identity':b['config']['source']['sha256'],'typed_graph_identity':b['typed_graph_identity'],'charge_identity':b['charge_identity'],'assignment_identity':b['assignment_identity'],'backend_identity':b['identity'],'frame_content_identity':o['trajectory_identity'],'config_identity':o['config_identity'],'complete_dynamics':o['complete'],'last_retained_step':o['last_retained_step'],'npt_duration_ps':o['npt_duration_ps'],'npt_frames':o['npt_frames'],'retained_frames':o['total_retained_frames'],'pressure_status':o['pressure_status'],'metrics':{name:{k:v for k,v in metric.items() if k not in {'autocorrelation','rolling_mean'}} for name,metric in o['metrics'].items()},'continuation':cmp,'parameter_completeness':'passed','scientific_validation':'not_established'})
manifest=_signed(dict(schema='island.j40-c2-reproducibility-manifest.v1',matrix_identity=m['identity'],protocol=m['protocol'],cases=rows,scientific_acceptance=False,limitations=m['blocked_gates']+['legacy_v1_NumPy_rolling_mean_not_bit_portable_across_environments'],core_executor_source_hashes={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ('src/island/analysis/equilibration_run.py','src/island/analysis/equilibration.py','src/island/analysis/equilibration_protocol.py','src/island/analysis/npt.py','src/island/analysis/npt_continuation.py','src/island/_periodic_openmm.py')},**FLAGS))
_write_json(out/'manifest.json',manifest)
inventory={str(p.relative_to(root.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
_write_json(out/'artifact-inventory.json',inventory)
# Dictionary spans the unchanged suffix shared only after independent execution.
# This is lossless archive compression, never trajectory synthesis.
cmd="tar --sort=name -cf - -C /tmp/j40-c2-validation run | xz -T1 -6 --lzma2=dict=512MiB > docs/evidence/phase_4j40_c2/artifacts.tar.xz"
proc=subprocess.run(['bash','-o','pipefail','-c',cmd],check=False)
_write_json(Path('/tmp/j40-c2-validation/validation/archive-command.json'),{'argv':['bash','-o','pipefail','-c',cmd],'exit_code':proc.returncode})
assert proc.returncode==0
print('archive bytes',(out/'artifacts.tar.xz').stat().st_size,flush=True)
