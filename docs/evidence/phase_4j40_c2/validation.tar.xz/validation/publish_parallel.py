import time,shutil,subprocess,os,json
from pathlib import Path
from hashlib import sha256
from island.analysis.npt import _signed,_write_json,FLAGS
from island.analysis.equilibration import require
root=Path('/tmp/j40-c2-validation/run');r=root/'opls-resp-aromatic/replica-2';early=r/'independent-early-continuation'
while not (early/'resume.command.json').exists():time.sleep(5)
command=json.loads((early/'resume.command.json').read_text())
require(command['exit_code']==0,'Independent long continuation failed')
a=json.loads((early/'attempt/attempt.json').read_text());restart=json.loads((r/'relocated/restart.json').read_text())
require(a['parent_restart']==restart,'Independently generated split/restart differs')
hashes={p.name:sha256(p.read_bytes()).hexdigest() for p in (early/'attempt').iterdir() if p.is_file()}
shutil.move(str(early/'attempt'),str(r/'resumed-attempt'))
require(all(sha256((r/'resumed-attempt'/n).read_bytes()).hexdigest()==v for n,v in hashes.items()),'Continuation artifact relocation changed bytes')
shutil.copyfile(early/'resume.command.json',r/'resume-attempt.command.json');shutil.copyfile(early/'resume.log',r/'resume-attempt.log')
_write_json(r/'parallel-continuation-relocation.json',_signed(dict(schema='island.j40-c2-executed-continuation-relocation.v1',source='independent-early-continuation/attempt',destination='resumed-attempt',files=hashes,parent_restart_identity=restart['identity'],source_command=command,**FLAGS)))
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'}
cmd=['../island-validation/phase4g1-env/bin/python','-m','scripts.phase_4j40_c2_finalize','--output',str(root)]
with Path('/tmp/j40-c2-validation/finalize.log').open('w') as log:proc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
Path('/tmp/j40-c2-validation/validation/finalize-command.json').write_text(json.dumps({'argv':cmd,'exit_code':proc.returncode,'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'environment':{k:env[k] for k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS')}},indent=2)+'\n')
print('finalizer',proc.returncode,flush=True)
