"""Retain first J74 capture and select citation-complete source facts."""
import json
import shutil
from pathlib import Path
from scripts.phase_4j74_source_intake import scope

scope()
root = Path('docs/evidence/phase_4j74')
saved = Path('/tmp/island-j74-capture-0-snapshot')
if saved.exists():
    raise RuntimeError('do not overwrite earlier capture')
shutil.move(root, saved)
shutil.copytree('/tmp/island-j74-capture-1-evidence', root)
inventory = json.loads((root / 'source-file-inventory.json').read_text())
records = json.loads((root / 'extracted-parameter-records.json').read_text())
facts = json.loads((root / 'source-parsing-facts.json').read_text())
print(json.dumps({'files': len(inventory['files']), 'extracted_records': len(records['records']), 'archive_members': len(facts['files']['PDMS_benchmark-main.zip']['members']), 'PDF_pages_parsed': sum(len(v.get('pages', [])) for v in facts['files'].values()), 'source_assets_copied': False}))
