"""Package fenced verification metadata, never external source assets."""
import hashlib
import json
import lzma
import os
from pathlib import Path
from xml.etree import ElementTree as ET

from scripts.phase_4j74_source_intake import scope

scope()
root = Path('docs/evidence/phase_4j74')
validation = root / 'validation'
validation.mkdir(exist_ok=False)
identities = {}


def retain(source, target, compressed=False):
    raw = source.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(lzma.compress(raw) if compressed else raw)
    identities[str(target.relative_to(root))] = {
        'original_path': str(source), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'raw_bytes': len(raw), 'lossless_xz': compressed,
    }


runs = []
for directory in sorted(Path('/tmp').glob('island-j74-*')):
    if not directory.is_dir() or not (directory / 'policy.json').is_file():
        continue
    if directory.resolve() == Path(os.environ['ISLAND_C1_POLICY']).resolve().parent:
        continue
    if not (directory / 'result.json').is_file():
        raise RuntimeError('unfinished previous run ' + str(directory))
    target = validation / 'runs' / directory.name
    for name in ('policy.json', 'result.json', 'bootstrap/sitecustomize.py'):
        retain(directory / name, target / name)
    retain(directory / 'events.jsonl', target / 'events.jsonl.xz', True)
    log = directory.with_suffix('.log')
    if log.is_file():
        if directory.name == 'island-j74-parser-inspect-0':
            raw = log.read_bytes()
            (target / 'stdout-withheld-for-licensing.json').write_text(json.dumps({
                'external_original_path': str(log), 'raw_sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw),
                'reason': 'Read-only inspection printed external README/parameter source excerpts. Original stdout remains external; it is not redistributed. Numeric facts and provenance are in the separately reviewed JSON extraction.',
            }, sort_keys=True, indent=2) + '\n')
        else:
            retain(log, target / 'stdout-stderr.log.xz', True)
    runs.append(str(target.relative_to(root)))

for i in range(2):
    retain(Path(f'/tmp/island-j74-focused-{i}.xml'), validation / 'attempts' / f'focused-{i}.xml.xz', True)
    retain(Path(f'/tmp/island-j74-collection-{i}.json'), validation / 'attempts' / f'collection-{i}.json')
for path in sorted(Path('/tmp/island-j74-capture-0-snapshot').iterdir()):
    if path.is_file():
        retain(path, validation / 'attempts/capture-0' / (path.name + '.xz'), True)
for path in sorted(Path('/tmp/island-j74-checks-0').iterdir()):
    if path.is_file():
        retain(path, validation / 'checks-0' / (path.name + ('.xz' if path.suffix == '.log' else '')), path.suffix == '.log')
retain(Path('/tmp/island-j74-checks-launch-0.log'), validation / 'checks-0/launch.log.xz', True)
retain(Path('/tmp/island-j74-focused-1.xml'), validation / 'focused.xml.xz', True)
retain(Path('/tmp/island-j74-collection-1.json'), validation / 'collection.json')
for name in ('select_capture', 'checks', 'package'):
    path = Path('/tmp/island_j74_' + name + '.py')
    retain(path, validation / 'drivers' / (path.name + '.xz'), True)

checks = []
for record in json.loads(Path('/tmp/island-j74-checks-0/results.json').read_text()):
    record['log'] = 'validation/checks-0/' + record['log'] + '.xz'
    checks.append(record)
selected = {
    'focused_tests': 'island-j74-focused-1', 'pip_parser': 'island-j74-pip-parser-0',
    'pip_supported': 'island-j74-historical-checks-0', 'C1_receipt': 'island-j74-historical-checks-0',
    'J73_receipt': 'island-j74-historical-checks-0', 'source_originals': 'island-j74-originals-0',
    'relocated_replay': 'island-j74-relocated-1', 'diff': 'island-j74-diff-0',
}
for name, run in selected.items():
    result = json.loads(Path('/tmp', run, 'result.json').read_text())
    checks.append({'name': name, 'command': result['command'], 'returncode': result['returncode'],
        'log': f'validation/runs/{run}/stdout-stderr.log.xz', 'policy_sha256': result['policy_sha256'],
        'status': 'existing_parser_environment_dependency_conflicts_retained' if name == 'pip_parser' else 'passed_software_or_evidence_check'})


def counts(path):
    cases = list(ET.parse(path).iter('testcase'))
    return {'unique_nodes': len(cases), 'passed': sum(not any(c.find(k) is not None for k in ('failure', 'error', 'skipped')) for c in cases), 'skipped': sum(c.find('skipped') is not None for c in cases), 'failure': sum(c.find('failure') is not None for c in cases), 'error': sum(c.find('error') is not None for c in cases)}


history = {
    'terminal': counts('/tmp/island-j74-focused-1.xml'),
    'focused_attempts': [{'attempt': i, **counts(f'/tmp/island-j74-focused-{i}.xml'), 'additional_terminal_unique_coverage': 0 if i == 0 else 'terminal_node_set'} for i in range(2)],
    'historical_counts_replayed_are_not_new_coverage': True,
    'parser_environment_pip_failure': 'Return code 1; torch metadata requires missing fsspec and sympy1.13.1 versus installed1.14.0. No dependency installation or change; exact failure retained and required by validator.',
    'first_lint_failure': 'Import ordering, re.I alias, broad parser exception boundary and unused variable; corrected before focused tests, original log retained.',
    'capture_refinement': 'Initial successful capture retained; final capture adds literal FRC citation/license-notice metadata. Same27 source files and1012 facts; no source bytes or parameter decisions changed.',
    'relocation_failure': 'First independent launcher selected J73-only pytest fixture. Missing J74 frozen inputs correctly rejected; rerun on J74 fixture passed.',
    'preflight_sequence_deviation': 'Initial read-only listing/header/ZIP inspection preceded explicit J74 preflight. No scientific backend ran. All subsequent capture and terminal verification fenced. J74 does not claim initial sequence compliance.',
    'scientific_execution_counts': {'J74_QM': 0, 'J74_MD_steps': 0, 'converter': 0, 'fitting': 0, 'parameter_generation': 0, 'reserved_validation': 0, 'energy_force_pressure_evaluation': 0},
    'source_asset_licensing': 'External originals and source-containing inspection stdout remain outside git; only fingerprints, metadata and extracted facts retained.',
    'self_reference_policy': 'Completed pre-seal ledgers retained. Packaging, sealing and final strict-validation ledgers stay external to avoid circular artifact identities.',
}
for name, data in (('checks.json', checks), ('fenced-runs.json', runs), ('attempt-history.json', history), ('raw-file-identities.json', identities)):
    (validation / name).write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')
print(json.dumps({'fenced_runs': len(runs), 'raw_files_retained': len(identities), 'selected_checks': len(checks), 'terminal': history['terminal']}))
