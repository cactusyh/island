import hashlib,json,os,subprocess
from pathlib import Path
from scripts.phase_4j42_c1 import BASE
from scripts.validate_phase_4j41_receipt import sha
root=Path.cwd();v=Path('/tmp/j42-c1-validation/validation')
rows=subprocess.check_output(['git','ls-tree','-r',BASE,'docs','src','scripts','tests'],text=True).splitlines()
changed={'src/island/forcefields/external_pdms_adapter.py','src/island/forcefields/preparation.py','tests/test_phase_4j42.py'}
p=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
historical={};protected={}
for row in rows:
 meta,name=row.split('\t',1);mode,kind,oid=meta.split()
 if name in changed:continue
 assert kind=='blob' and mode in ('100644','100755','120000')
 p.stdin.write((oid+'\n').encode());p.stdin.flush()
 header=p.stdout.readline().split();assert header[0].decode()==oid and header[1]==b'blob'
 raw=p.stdout.read(int(header[2]));assert p.stdout.read(1)==b'\n'
 expected=hashlib.sha256(raw).hexdigest()
 if mode=='120000':assert os.readlink(root/name).encode()==raw,name
 else:assert sha(root/name)==expected,name
 (historical if name.startswith('docs/') else protected)[name]=sha(root/name)
p.stdin.close();assert p.wait()==0
(v/'historical-byte-hashes.json').write_text(json.dumps(historical,indent=2)+'\n')
(v/'protected-source-hashes.json').write_text(json.dumps(protected,indent=2)+'\n')
print(json.dumps({'historical_files':len(historical),'protected_source_files':len(protected),'intentional_changes':sorted(changed),'base_commit':BASE,'all_preserved_bytes_equal_to_git_base':True}))
