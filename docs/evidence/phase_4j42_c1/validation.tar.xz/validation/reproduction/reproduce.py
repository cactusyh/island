import json,subprocess
from pathlib import Path
from island.chemistry import from_smiles
from island.forcefields import ExternalPDMSOptions,ForceFieldRequest,prepare_forcefield,create_evaluator
from island.minimization import minimize_geometry
r={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'cases':[]}
for name,text in [('missing_sio','[SiH3][SiH3].O'),('invalid_valence','[SiH2]O'),('charged','[SiH3][O-]'),('phosphorus','P')]:
 s=from_smiles(text,random_seed=2026)
 p=prepare_forcefield(s,ForceFieldRequest('external_pdms_class2',ExternalPDMSOptions()))
 row={'name':name,'smiles':text,'status':p.payload['status'],'requirements':p.payload['requirements'],'diagnostics':p.payload['diagnostics'],'boundaries':[]}
 for boundary in ('create_evaluator','minimization/evaluator'):
  try:
   evaluator=create_evaluator(s,p)
   if boundary=='minimization/evaluator':minimize_geometry(s,evaluator)
  except Exception as e:
   row['boundaries'].append({'boundary':boundary,'exception_type':type(e).__name__,'message':str(e),'classified':type(e).__name__=='ExternalPDMSBlockedError'})
 r['cases'].append(row)
print(json.dumps(r,indent=2))
Path('/tmp/j42-c1-validation/reproduction/before.json').write_text(json.dumps(r,indent=2)+'\n')
