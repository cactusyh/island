import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
from pathlib import Path
from scripts.phase_4j41_c2 import read
from scripts.phase_4j42_c1 import BASE,BRANCH
from scripts.validate_phase_4j41_receipt import sha,signed
root=Path('/tmp/j42-c1-validation');v=root/'validation';repo=Path.cwd();dest=repo/'docs/evidence/phase_4j42_c1';dest.mkdir(parents=True,exist_ok=True)
commit=(v/'implementation-commit.txt').read_text().strip();assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
for name in ['run_gates.py','run_extra.py','derive_regressions.py','historical_byte_audit.py','build_receipt.py']:shutil.copyfile(root/name,v/name)
verification={}
for name in ('focused','full','regressions','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum','receipt_j42','historical_byte_audit','relocation','original_defect','execution'):
 result=json.loads((v/(name+'-command.json')).read_text());assert result['exit_code']==0 and result['tested_implementation_commit']==commit,name
 verification[name]=result
report=read(root/'final-study/report.json');assert len(report['cases'])==9 and report['software_acceptance_gate']==0 and report['scientific_acceptance_gate']==1 and report['execution_profiles']==[] and report['backend_executions']==[]
historical=json.loads((v/'historical-byte-hashes.json').read_text());protected=json.loads((v/'protected-source-hashes.json').read_text())
assert all(sha(repo/p)==h for p,h in {**historical,**protected}.items())
implementation={p:sha(repo/p) for p in ('src/island/forcefields/external_pdms_adapter.py','src/island/forcefields/preparation.py','tests/test_phase_4j42.py','scripts/phase_4j42_c1.py','scripts/validate_phase_4j42_c1_receipt.py','tests/test_phase_4j42_c1.py')}
for p,h in implementation.items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':'+p])).hexdigest()==h
before=json.loads((v/'reproduction/before.json').read_text());assert before['base_commit']==BASE
assert all(not b['classified'] and b['exception_type']=='ValueError' for c in before['cases'] for b in c['boundaries'])
def files(folder):return {str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
for archive,source,arcname in [('execution.tar.xz',root/'final-study','study'),('validation.tar.xz',v,'validation')]:
 with tarfile.open(dest/archive,'w:xz',preset=6) as tar:tar.add(source,arcname=arcname)
manifest=signed({'schema':'island.j42-c1-manifest.v1','base_commit':BASE,'historical_files':historical,'protected_source_files':protected,'implementation_files':implementation,'archives':{n:sha(dest/n) for n in ('execution.tar.xz','validation.tar.xz')},'study_files':files(root/'final-study'),'validation_files':files(v)})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
counts={name:{k:sum(int(s.attrib.get(k,0)) for s in E.parse(v/(name+'.xml')).getroot()) for k in ('tests','failures','errors','skipped')} for name in ('focused','full')}
receipt=signed({'schema':'island.j42-c1-receipt.v1','base_commit':BASE,'branch':BRANCH,'tested_implementation_commit':commit,'status':'blocked_outcomes_validated','software_acceptance_gate':0,'scientific_acceptance_gate':1,'execution_profiles':[],'production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(dest/'manifest.json'),'study_report':report,'original_reproduction':before,'reconstruction':json.loads((v/'relocation.log').read_text()),'verification':verification,'test_counts':counts,'regressions':json.loads((v/'regressions.json').read_text()),'relocation':json.loads((v/'relocation-file-hashes.json').read_text()),'historical_bytes_match_base':True,'historical_receipt_validation':'Unchanged J42 validator; source pins checked against original detached J42 checkout, study reconstructed with current repaired runtime','native_pcff_and_c5_schema_unchanged':True})
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'test_counts':counts,'historical_files':len(historical),'protected_source_files':len(protected),'study_files':len(files(root/'final-study'))},indent=2))
