import concurrent.futures,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/j41-c1-validation');v=root/'validation';repo=Path.cwd();py='../island-validation/phase4e2-env/bin/python'
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1',**json.loads(Path('/tmp/j40-c2-validation/validation/full_supported-command.json').read_text())['environment'],'ISLAND_J40_C11_RUN':'/tmp/j40-c11-validation/final-study','ISLAND_J40_C12_RUN':'/tmp/j40-c13-validation/study','ISLAND_J40_C13_RUN':'/tmp/j40-c13-validation/study'}
env['ISLAND_J41_DISTRIBUTION']=str(Path('../lammps/lammps/tools/msi2lmp/frc_files').resolve())
mode=sys.argv[1]
def run(name,argv):
 start=time.time();sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 with (v/(name+'.log')).open('w') as log:p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
 r={'argv':argv,'cwd':str(repo),'environment':{k:env[k] for k in env if k.startswith('ISLAND_') or k in ['PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE']},'tested_implementation_commit':sha,'exit_code':p.returncode,'elapsed_seconds':time.time()-start}
 (v/(name+'-command.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,p.returncode,flush=True)
 return p.returncode
if mode in ('focused','regressions','full'):
 if mode=='focused': files=['tests/test_phase_4j41_c1.py']
 elif mode=='regressions':
  import re
  files=[str(p) for p in sorted(Path('tests').glob('test_phase_4j*.py')) if (m:=re.search(r'4j(\d+)',p.name)) and 22<=int(m[1])<=41 and p.name != "test_phase_4j41_c1.py"]
 else:files=[]
 argv=[py,'-m','pytest','-p','no:cacheprovider','-q','--tb=short','--junitxml='+str(v/(mode+'.xml')),'--basetemp='+str(v/(mode+'-tmp')),*files]
 raise SystemExit(run(mode,argv))
if mode=='checks':
 jobs=[('ruff',[py,'-m','ruff','check','.']),('compileall',[py,'-m','compileall','-q','src','scripts','tests']),('diff_check',['git','diff','--check'])]
 envs={'supported':'../island-validation/phase4e2-env/bin/python','foyer':'../island-validation/phase4g1-env/bin/python','analysis':'../island-validation/phase4j32-analysis-env/bin/python','amber':'../miniforge3/envs/md_rg/bin/python','quantum':'../island-validation/phase4j36-native-env/bin/python'}
 jobs += [(f'pip_{k}',[p,'-m','pip','check']) for k,p in envs.items()]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: results=list(pool.map(lambda j:run(*j),jobs))
 for name,p in envs.items():
  cmd=[p,'-c','import sys,platform,importlib.metadata as m,json; print(json.dumps({"python":sys.version,"executable":sys.executable,"platform":platform.platform(),"packages":sorted((x.metadata["Name"],x.version) for x in m.distributions())},indent=2))']
  run('environment_'+name,cmd)
 raise SystemExit(max(results))
