import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
r=Path('/tmp/j41-c1-validation');v=r/'validation';repo=Path.cwd()
moved=r/'relocated'/'study';moved.parent.mkdir(exist_ok=True);shutil.copytree(r/'final-study',moved)
cwd=r/'relocation-cwd';cwd.mkdir(exist_ok=True)
env={**os.environ,'PYTHONPATH':str(repo)+':'+str(repo/'src'),'OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
argv=[str((repo/'../island-validation/phase4e2-env/bin/python').absolute()),str(repo/'scripts/phase_4j41_c1.py'),'--reconstruct',str(moved)]
start=time.time()
with (v/'portable-reconstruction.log').open('w') as log:p=subprocess.run(argv,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original={str(p.relative_to(r/'final-study')):sha(p) for p in (r/'final-study').rglob('*') if p.is_file()}
relocated={str(p.relative_to(moved)):sha(p) for p in moved.rglob('*') if p.is_file()}
record={'argv':argv,'cwd':str(cwd),'environment':{k:env[k] for k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'all_study_files_identical_after_relocation':original==relocated,'study_file_count':len(original)}
(v/'portable-reconstruction-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(record,flush=True)
raise SystemExit(int(p.returncode!=0 or original!=relocated))
