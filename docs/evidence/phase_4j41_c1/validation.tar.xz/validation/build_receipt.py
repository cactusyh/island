import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path
from island.workflows import storage
from scripts.validate_phase_4j41_c1_receipt import validate_study,signed
from island.charge_references.records import unpack
r=Path('/tmp/j41-c1-validation');v=r/'validation';repo=Path.cwd()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
verification={n:json.loads((v/(n+'-command.json')).read_text()) for n in names}
commit=(v/'implementation-commit.txt').read_text().strip()
if any(q['exit_code'] or q['tested_implementation_commit']!=commit for q in verification.values()):raise RuntimeError('Failed or mixed-commit verification')
for name in ('focused','regressions','full'):
 suite=ET.parse(v/(name+'.xml')).getroot().find('testsuite')
 c={k:int(suite.attrib.get(k,0)) for k in ('tests','failures','errors','skipped')};c['passed']=c['tests']-c['failures']-c['errors']-c['skipped']
 if c['failures'] or c['errors'] or not c['passed']:raise RuntimeError('Invalid JUnit result')
 verification[name]['junit']=c
historical=json.loads((v/'historical-hashes.json').read_text());frozen=json.loads((v/'frozen-source.json').read_text())
for group in (historical,frozen):
 for p,h in group.items():
  if sha(repo/p)!=h:raise RuntimeError('Changed frozen file '+p)
relocation=json.loads((v/'portable-reconstruction-command.json').read_text())
mutation=json.loads((v/'mutation-audit.json').read_text())
execution=json.loads((v/'execution-command.json').read_text())
if relocation['exit_code'] or not relocation['all_study_files_identical_after_relocation']:raise RuntimeError('Relocation failed')
if execution['exit_code']!=execution['expected_exit_code'] or execution['exit_code']!=1:raise RuntimeError('Unexpected execution status')
if not mutation['all_rejected'] or len(mutation['results'])!=8:raise RuntimeError('Mutation audit failed')
independent=validate_study(r/'final-study')
report=storage.decode(storage.read_json(r/'final-study/report.json'))
baseline=storage.decode(storage.read_json(r/'final-study/baseline/report.json'))
silane=baseline['cases'][0]
old=json.loads((repo/'docs/evidence/phase_4j41/receipt.json').read_text())
for key in ('singlepoint','finite_differences','minimization','coefficient_audit'):
 if silane[key]!=old['numerical_silane'][key]:raise RuntimeError('Changed retained finite silane '+key)
profiles=[]
for row in report['cases']:
 p=unpack((r/'final-study'/row['name']/'assessment.json').read_text());i=p['inspection'];n=i['native_charge_record']['native_charge_record'] if i else None
 profiles.append({**row,'profile':p['profile'],'atom_order':p['atom_order'],'policy':p['policy'],'typing_identity':i['typing_identity'] if i else None,'charge_identity':i['charge_identity'] if i else None,'charge_unit':'elementary_charge' if n else None,'charge_vector':[[k,n['partial_charges'][k]] for k in p['atom_order']] if n else None,'component_totals':n['components'] if n else None,'parameter_identity':i['assignment_identity'] if i and p['complete'] else None,'diagnostic_assignment_identity':i['assignment_identity'] if i else None,'charge_status':'complete' if i and i['charges_complete'] else 'not_assigned_typing_blocked','parameter_status':'complete' if p['complete'] else 'source_incomplete_or_interpretation_blocked','periodic_status':'not_authorized','scientific_validation_status':'not_established'})
pub=r/'portable';pub.mkdir(exist_ok=False)
shutil.copytree(r/'final-study',pub/'study')
for folder in ('converter','matcher'):shutil.copytree(r/folder,pub/folder)
shutil.copyfile(r/'environment.json',pub/'environment.json')
for name in ('execution-command.json','converter-build.json','mutation-audit.json','mutation-audit.log','portable-reconstruction-command.json','portable-reconstruction.log','study-validation.log'):
 shutil.copyfile(v/name,pub/name)
bundle=signed({'schema':'island.j41-c1-portable-bundle.v1','files':{str(p.relative_to(pub)):sha(p) for p in sorted(pub.rglob('*')) if p.is_file()}})
(pub/'bundle-manifest.json').write_text(json.dumps(bundle,indent=2)+'\n')
evidence=repo/'docs/evidence/phase_4j41_c1';evidence.mkdir(exist_ok=False)
with tarfile.open(evidence/'execution.tar.xz','w:xz') as tar:
 for path in sorted(pub.iterdir()):tar.add(path,arcname=path.name)
with tarfile.open(evidence/'validation.tar.xz','w:xz') as tar:
 for path in sorted(v.iterdir()):
  if path.is_file() or path.name=='source':tar.add(path,arcname='validation/'+path.name)
manifest=signed({'schema':'island.j41-c1-manifest.v1','base_commit':(v/'base-commit.txt').read_text().strip(),'tested_implementation_commit':commit,'files':{n:sha(evidence/n) for n in ('execution.tar.xz','validation.tar.xz')},'historical_files':historical,'implementation_files':frozen,'bundle_identity':bundle['identity']})
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
environment=json.loads((r/'environment.json').read_text())
receipt=signed({'schema':'island.j41-c1-receipt.v1','created_utc':datetime.now(timezone.utc).isoformat(),'phase':'4J41-C1','base_commit':manifest['base_commit'],'tested_implementation_commit':commit,'branch':'codex/phase-4j41-c1-mixed-silicon-phosphorus','acceptance_gate':1,'outcome':'finite_silane_preserved; 16 additional retained fixtures source-incomplete or typing-blocked','production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(evidence/'manifest.json'),'independent_validation':independent,'profiles':profiles,'source_distribution':environment['source_distribution'],'converter':environment['converter'],'lammps':{k:x for k,x in environment['lammps'].items() if k!='help'},'openmm':environment['openmm'],'source_audit':{'raw_catalog_records_compared':4359,'compiled_C_leaf_queries':347,'assigned_direct_queries':337,'missing_direct_queries':10,'scope':'direct leaf matching; missing final couplings decided separately after ordinary-equivalence graph audit','wildcard_equivalence_control':'matcher/receipt.json in execution archive','typing_authority':'bounded source-backed chemical graph rules; msi2lmp consumes rather than chemically validates supplied atom labels','phosphorus':'source descriptions and companion oxo template conflict; graph valence/oxidation descriptions do not authorize a P type','missing_coupling_policy':'reject; no zero substitution; no wildcard-only new Si/P terms','charge_origin':'PCFF/source_native_bond_increments; no normalization'},'finite_silane':{'historical_numerical_results_identical':True,'model_identity':silane['model_identity'],'singlepoint':silane['singlepoint'],'finite_differences':silane['finite_differences'],'minimization':silane['minimization'],'dynamics':silane['dynamics'],'time_step_fs':0.1,'steps_per_integrator':200,'trajectory_length_ps':0.02,'interpretation':'finite software control only; no active nonbonded pairs, equilibrium, pressure or periodic qualification'},'periodic_scientific_status':{'ewald':'ewald_unvalidated','pressure':'pressure_unavailable','long_npt':'blocked','cutoff_recovery':'not_executed'},'audits':{'execution':execution,'relocation_fresh_process':relocation,'negative_controls':mutation,'historical_preservation':{'files':len(historical),'changed':0}},'verification':verification,'limitations':['No new mixed-Si or P executable domain is qualified by the pinned source.','Si-N/S/halogen increments and automatic rows do not prove chemical type or Class-II source completeness.','No supplied P/oxygen types, P charges, incomplete models or incomplete-source dynamics are invented.','Unchanged finite silane is the sole retained executable; whole/split final physical state and complete RNG are exact.','Checkpoint byte equality uses identical segmented lineage across in-process and relocated fresh-process continuation; whole-run lineage/counters differ.','No universal PCFF/COMPASS/msi2lmp parity, ionic/charged/metallic coverage, AM1-BCC support, experimental agreement, equilibration or production readiness.','PCFF Ewald/PPPM, backend pressure and long NPT remain unqualified.']})
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps({'receipt':str(evidence/'receipt.json'),'verification':{k:q['junit'] for k,q in verification.items() if 'junit'in q},'historical_files':len(historical),'acceptance_gate':1}),flush=True)
