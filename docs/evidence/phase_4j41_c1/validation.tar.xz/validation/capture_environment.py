import hashlib,json,os,platform,shutil,subprocess,sys
from pathlib import Path
import openmm
root=Path('/tmp/j41-c1-validation');converter=root/'converter'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cmd(args):
 p=subprocess.run(args,capture_output=True,text=True,check=False)
 return {'argv':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
source=Path('../lammps/lammps/tools/msi2lmp/src').resolve()
lmp=Path('../island-validation/phase4j22/lmp-kspace').resolve()
record={
 'schema':'island.j41-c1-executable-environment.v1',
 'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),
 'hardware':cmd(['lscpu']),
 'openmm':{'version':openmm.version.full_version,'platform':'Reference','precision':'double; Reference implementation','platform_properties':list(openmm.Platform.getPlatformByName('Reference').getPropertyNames())},
 'compiler':cmd(['gcc','--version']),
 'converter':{'sha256':sha(converter/'msi2lmp'),'version':'3.9.11 / 6 Sep 2024; observed in all retained converter logs','source_commit':cmd(['git','-C','../lammps/lammps','rev-parse','HEAD']),'source_hashes':{p.name:sha(p) for p in sorted(source.glob('*')) if p.suffix in ('.c','.h')},'build_argv':json.loads((root/'validation/converter-build.json').read_text())['argv'],'recorded_build':json.loads((root/'validation/converter-build.json').read_text()),'build_exit_code':0,'scope':'PCFF/COMPASS supplied-type Class-II assembly; no atom perception or charge assignment'},
 'lammps':{'path':str(lmp),'sha256':sha(lmp),'help':cmd([str(lmp),'-h']),'precision':'double FFT / KISS mpiFFT; finite direct-Coulomb only executed for J41','executed_pair_style':'lj/class2/coul/cut','executed_boundary':'finite f f f; all pair distances below declared cutoff'},
 'source_distribution':{n:sha(root/'final-study'/n) for n in ('pcff.frc','pcff.rlb','pcff_templates.dat')},
 'environment':{k:os.environ.get(k) for k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS')},
 'readiness':{'production_validated':False,'simulation_readiness':'not_established'}
}
(root/'environment.json').write_text(json.dumps(record,indent=2)+'\n')
