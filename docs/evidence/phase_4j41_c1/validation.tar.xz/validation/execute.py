import json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/j41-c1-validation');v=root/'validation'
env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
argv=['../island-validation/phase4e2-env/bin/python','-u','scripts/phase_4j41_c1.py','--distribution','../lammps/lammps/tools/msi2lmp/frc_files','--converter',str(root/'converter/msi2lmp'),'--matcher',str(root/'matcher/leaf.so'),'--lammps','../island-validation/phase4j22/lmp-kspace','--output',str(root/'final-study')]
start=time.time()
with (v/'execution.log').open('w') as log:p=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
record={'argv':argv,'cwd':str(Path.cwd()),'environment':{k:env[k] for k in ('PYTHONPATH','OPENMM_CPU_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'exit_code':p.returncode,'expected_exit_code':1,'elapsed_seconds':time.time()-start}
(v/'execution-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(record,flush=True)
raise SystemExit(int(p.returncode!=1))
