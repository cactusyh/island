import copy,json,sys,time
from pathlib import Path
from island.charge_references.records import pack,unpack
from island.exceptions import PCFFError
from island.workflows import storage
from scripts.validate_phase_4j41_c1_receipt import validate_study
root=Path('/tmp/j41-c1-validation');study=root/'relocated/study'
if not (root/'validation/portable-reconstruction-command.json').is_file():raise RuntimeError('Fresh reconstruction must finish first')
mutations=[('raw_source',study/'pcff.frc'),('source_inventory',study/'mixed-source-inventory.json'),('periodic_gate',study/'report.json'),('policy',study/'silane_control/assessment.json'),('atom_order',study/'methylsilane/assessment.json'),('component_total',study/'methylsilane/assessment.json'),('p_typing',study/'phosphate_ester/assessment.json'),('compiled_values',study/'compiled-source-audit.json')]
results=[]
for kind,path in mutations:
 old=path.read_bytes();start=time.time()
 try:
  if kind=='raw_source':new=old+b'\n'
  elif kind in ('policy','atom_order','component_total','p_typing'):
   p=unpack(old.decode())
   if kind=='policy':p['policy']['missing_cross_term']='zero'
   elif kind=='atom_order':p['atom_order'].reverse()
   elif kind=='component_total':p['inspection']['native_charge_record']['native_charge_record']['components'][0]['charge']=1
   else:p['phosphorus_environments'][0]['selected_type']='p='
   new=pack(p).encode()
  else:
   p=storage.decode(storage.read_json(path))
   if kind=='source_inventory':p['environments']['Si-C']['families']['bond-bond_1_3']=['invented']
   elif kind=='periodic_gate':p['pressure_status']='validated'
   elif kind=='compiled_values':
    row=next(r for r in p['queries'] if r['compiled_source_values'])
    row['compiled_source_values'][0]='999999'
   new=storage.json_bytes(storage.encode(p))
  path.write_bytes(new)
  try:validate_study(study)
  except (ValueError,AssertionError,PCFFError) as e:results.append({'mutation':kind,'rejected':True,'error':type(e).__name__,'diagnostic':str(e)[:1000],'elapsed_seconds':time.time()-start})
  else:raise RuntimeError('Mutation accepted '+kind)
 finally:path.write_bytes(old)
 print(kind,'rejected',flush=True)
(root/'validation/mutation-audit.json').write_text(json.dumps({'schema':'island.j41-c1-independent-mutation-audit.v1','results':results,'all_rejected':all(r['rejected'] for r in results)},indent=2)+'\n')
