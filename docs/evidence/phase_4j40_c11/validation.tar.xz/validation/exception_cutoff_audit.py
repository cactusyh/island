"""Independent source-parameter audit of special pairs outside the real cutoff."""
import json,math,hashlib
from pathlib import Path
root=Path('/tmp/j40-c11-validation/final-study');backend=json.loads((root/'inputs/backend.json').read_text());sites={s['id']:s for s in backend['numerical_data']['sites']};rows=[]
for name in ('baseline','box-1.25','box-1.5'):
 frame=json.loads((root/name/'frame.json').read_text());xyz=dict(zip(frame['atom_ids'],frame['positions_nm']));box=frame['box_lengths_nm'];ljterms=[];cterms=[];pairs=[]
 for pair in backend['numerical_data']['pairs']:
  a,b=pair['sites'];delta=[xyz[a][k]-xyz[b][k] for k in range(3)];delta=[v-round(v/box[k])*box[k] for k,v in enumerate(delta)];r=math.sqrt(sum(v*v for v in delta))
  if r<=.5:continue
  x,y=sites[a],sites[b];sigma=(x['sigma']+y['sigma'])/20;epsilon=math.sqrt(x['epsilon']*y['epsilon']);lj=4*epsilon*pair['lj']*((sigma/r)**12-(sigma/r)**6);correction=138.935456264*x['charge']*y['charge']*(pair['coulomb']-1)/r
  ljterms.append(lj);cterms.append(correction);pairs.append({'sites':[a,b],'distance_nm':r,'coulomb_scaling':pair['coulomb'],'lj_scaling':pair['lj'],'lj_kj_mol':lj,'missing_exclusion_correction_kj_mol':correction})
 actual=json.loads((root/name/'comparison.json').read_text())['comparison']['signed_component_errors_kj_mol']
 if pairs:
  assert abs(math.fsum(ljterms)-actual['lj'])<=1e-5
  assert abs(math.fsum(cterms)-actual['coulomb'])<=1e-5
 rows.append({'case':name,'pairs_outside_cutoff':pairs,'analytical_lj_difference_kj_mol':math.fsum(ljterms),'analytical_coulomb_correction_kj_mol':math.fsum(cterms),'actual_lj_difference_kj_mol':actual['lj'],'actual_coulomb_difference_kj_mol':actual['coulomb']})
Path('docs/evidence/phase_4j40_c11/exception-cutoff-audit.json').write_text(json.dumps({'schema':'island.j40-c11-exception-cutoff-audit.v1','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'interpretation':'diagnostic export/convention mismatch for special pairs outside cutoff; no parameters or semantics changed','cases':rows},indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k!='pairs_outside_cutoff'}|{'n_pairs':len(x['pairs_outside_cutoff'])} for x in rows],indent=2))
