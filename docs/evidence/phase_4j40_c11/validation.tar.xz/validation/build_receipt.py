import json,time,tarfile,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
from scripts.phase_4j40_c11_numeric import signed,sha,write
from scripts.validate_phase_4j40_c11_receipt import BASE,SOURCES,historical_hashes
root=Path('/tmp/j40-c11-validation');v=root/'validation';out=Path('docs/evidence/phase_4j40_c11')
required=['focused','regressions','full','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum']
while not all((v/(n+'-command.json')).exists() for n in required):time.sleep(5)
gates={n:json.loads((v/(n+'-command.json')).read_text()) for n in required}
for n,r in gates.items(): assert r['exit_code']==0,(n,r)
for n in ('focused','regressions','full'):
 suites=ET.parse(v/(n+'.xml')).getroot().findall('testsuite')
 gates[n]['junit']={k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
# Preserve all preliminary failures and native-output checks without mislabeling them.
for p in root.glob('*.log'):
 (v/('progress-'+p.name)).write_bytes(p.read_bytes())
with tarfile.open(out/'validation.tar.xz','w:xz') as archive:
 for p in sorted(v.rglob('*')):
  if p.is_file() and not any(x.endswith('-tmp') or x=='__pycache__' for x in p.relative_to(v).parts):archive.add(p,arcname=str(Path('validation')/p.relative_to(v)))
 archive.add(root/'independent_audit.py',arcname='independent_audit.py')
 archive.add(root/'NonbondedForceImpl.cpp',arcname='NonbondedForceImpl.cpp')
 archive.add(root/'focused-preliminary.log',arcname='preliminary/focused-preliminary.log')
 archive.add(root/'focused-preliminary.xml',arcname='preliminary/focused-preliminary.xml')
 archive.add(root/'study.log',arcname='preliminary/wrapped-coordinate-check.log')
with tarfile.open(out/'artifacts.tar.xz') as archive:
 inventory={member.name:__import__('hashlib').sha256(archive.extractfile(member).read()).hexdigest() for member in archive.getmembers() if member.isfile()}
write(out/'artifact-inventory.json',inventory)
c=json.loads((out/'characterization.json').read_text())
manifest=signed({'schema':'island.j40-c11-manifest.v2','base_commit':BASE,'tested_implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'characterization_identity':c['identity'],'artifacts_archive_sha256':sha(out/'artifacts.tar.xz'),'study_schema':'island.j40-c11-study.v2','environment_sha256':sha(out/'environment.json'),'native_fingerprints_sha256':sha(out/'runtime-native-fingerprints.json'),'scientific_acceptance':False,'readiness':{'production_validated':False,'simulation_readiness':'not_established'}})
write(out/'manifest.json',manifest)
history=historical_hashes()
receipt=signed({'schema':'island.j40-c11-receipt.v2','base_commit':BASE,'tested_implementation_commit':manifest['tested_implementation_commit'],'final_evidence_commit_resolution':'git log --format=%H -1 -- docs/evidence/phase_4j40_c11/receipt.json','implementation_sources':{n:sha(n) for n in SOURCES},'validation':gates,'manifest_identity':manifest['identity'],'characterization_identity':c['identity'],'artifact_inventory':inventory,'files':{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name not in ('receipt.json','receipt-validation.json','receipt-integrity.log','receipt-acceptance.log','final-diff-check.json')},'historical_files':history,'historical_entries':len(history),'scientific_acceptance':False,'ewald_status':'ewald_unvalidated','pressure_status':'pressure_unavailable','production_validated':False,'simulation_readiness':'not_established','cutoff_recovery':'not_executed','long_npt':'not_executed','classification':c['classification'],'bounded_numerical_difference_established':False,'limitations':['No atom-count growth study; box strain is not system-size scaling','OpenMM PME interpolation order fixed; only LAMMPS order independently varied','No alternate FFT precision build or GPU single/mixed platform declared','Residual at tight settings and nonuniform strained-box interaction differences remain unresolved','No independently validated OpenMM full force/reciprocal virial tensor for scientific NPT','Original C11 unit/method-reporting errors corrected; original files archived verbatim']})
write(out/'receipt.json',receipt)
print(json.dumps({n:r.get('junit',r['exit_code']) for n,r in gates.items()},indent=2),flush=True)
