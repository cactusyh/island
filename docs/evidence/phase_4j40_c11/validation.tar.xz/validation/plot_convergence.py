import json,hashlib
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/tmp/j40-c11-validation/final-study');out=Path('docs/evidence/phase_4j40_c11');s=json.loads((root/'study.json').read_text());fig,axes=plt.subplots(1,2,figsize=(9,3.6),layout='constrained')
for label,select in [('Ewald/Ewald',lambda r:r['name']=='baseline' or r['name'].startswith('tolerance-')),('PME/PPPM',lambda r:r['name'].startswith('pme-pppm-'))]:
 rows=sorted([r for r in s['rows'] if select(r)],key=lambda r:r['setting']['tolerance'])
 x=[r['setting']['tolerance'] for r in rows]
 axes[0].loglog(x,[r['comparison']['absolute_energy_error_kj_mol'] for r in rows],'o-',label=label)
 axes[1].loglog(x,[r['comparison']['forces']['maximum_component_error'] for r in rows],'o-',label=label)
for ax in axes:ax.set_xlabel('Requested reciprocal tolerance');ax.grid(alpha=.3);ax.legend(fontsize=8)
axes[0].set_ylabel('Absolute total energy difference (kJ/mol)');axes[1].set_ylabel('Maximum force-component difference (kJ/mol/nm)')
axes[0].axhline(1e-5,ls='--',color='black',label='unchanged energy bound');axes[1].axhline(1e-4,ls='--',color='black',label='unchanged absolute force bound')
fig.suptitle('Executed 52-atom GAFF2-PE single points; scientific closure unvalidated',fontsize=10)
fig.savefig(out/'convergence.pdf',metadata={'CreationDate':None,'ModDate':None});plt.close(fig)
(out/'plot-provenance.json').write_text(json.dumps({'input_sha256':hashlib.sha256((root/'study.json').read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'matplotlib':matplotlib.__version__,'outputs':{'convergence.pdf':hashlib.sha256((out/'convergence.pdf').read_bytes()).hexdigest()}},indent=2)+'\n')
