import json,subprocess,tarfile,sys,os,time,hashlib
from pathlib import Path
root=Path('/tmp/j40-c11-validation');dst=root/'relocation-check';dst.mkdir(exist_ok=False)
with tarfile.open('docs/evidence/phase_4j40_c11/artifacts.tar.xz') as archive:archive.extractall(dst/'extracted',filter='data')
subprocess.run([sys.executable,str(root/'validation/reconstruct_inputs.py'),str(dst/'extracted'),str(dst/'inputs')],check=True)
args=[sys.executable,'-m','scripts.phase_4j40_c11_study','--backend',str(dst/'inputs/backend.json'),'--reference',str(dst/'inputs/reference'),'--frames-root',str(dst/'inputs/frames'),'--lammps','../island-validation/phase4j22/lmp-kspace','--output',str(dst/'run')]
start=time.time()
with (root/'validation/relocated-execution.log').open('w') as log:p=subprocess.run(args,env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT,check=False)
assert p.returncode==1
old=json.loads((root/'final-study/study.json').read_text());new=json.loads((dst/'run/study.json').read_text());checks={}
for a,b in zip(old['rows'],new['rows']):
 for engine in ('openmm','lammps'):
  for field in ('energy_kj_mol','forces_kj_mol_nm','components_kj_mol'):
   checks[a['name']+'/'+engine+'/'+field]=a[engine][field]==b[engine][field]
 checks[a['name']+'/comparison']=a['comparison']==b['comparison']
checks['pressure_strain']=old['pressure_strain']==new['pressure_strain']
assert all(checks.values()),[k for k,v in checks.items() if not v]
with tarfile.open(root/'validation/relocated-execution.tar.xz','w:xz') as archive:archive.add(dst/'run',arcname='relocated-run')
result={'schema':'island.j40-c11-relocated-execution.v1','argv':args,'actual_exit':p.returncode,'expected_acceptance_exit':1,'elapsed_seconds':time.time()-start,'checks':checks,'all_equal':all(checks.values()),'scope':'all single-point native energy/force/components and strain values; not MD or checkpoint/RNG execution','inputs_archive_sha256':hashlib.sha256(Path('docs/evidence/phase_4j40_c11/artifacts.tar.xz').read_bytes()).hexdigest()}
Path('docs/evidence/phase_4j40_c11/relocated-execution.json').write_text(json.dumps(result,indent=2)+'\n')
print('relocated numerical execution',all(checks.values()),len(checks),flush=True)
