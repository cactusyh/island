import json,time,hashlib,concurrent.futures,subprocess,os
from pathlib import Path
out=Path('docs/evidence/phase_4j40_c11');p=out/'receipt.json'
while True:
 try:
  r=json.loads(p.read_text())
  if r.get('schema')=='island.j40-c11-receipt.v2':break
 except (OSError,ValueError):pass
 time.sleep(5)
sha=hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,extra,expected):
 argv=['../island-validation/phase4e2-env/bin/python','-m','scripts.validate_phase_4j40_c11_receipt',str(p),*extra];start=time.time()
 with (out/(name+'.log')).open('w') as log:c=subprocess.run(argv,env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT,check=False)
 row={'argv':argv,'exit_code':c.returncode,'expected_exit_code':expected,'receipt_sha256':sha,'elapsed_seconds':time.time()-start}
 print(name,c.returncode,flush=True);return name,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:checks=dict(pool.map(lambda j:check(*j),[('receipt-integrity',['--diagnostic-only'],0),('receipt-acceptance',[],1)]))
(out/'receipt-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
assert all(c['exit_code']==c['expected_exit_code'] for c in checks.values())
