import json,tarfile,shutil,subprocess,time
from pathlib import Path
from scripts.phase_4j40_c11_numeric import sha,write
root=Path('/tmp/j40-c11-validation');s=root/'final-study';out=Path('docs/evidence/phase_4j40_c11')
while not (s/'study.json').exists():time.sleep(1)
result=subprocess.run(['../island-validation/phase4e2-env/bin/python','-m','scripts.validate_phase_4j40_c11','--study',str(s),'--output',str(out/'characterization.json')],check=False);assert result.returncode==1
subprocess.run(['../island-validation/phase4e2-env/bin/python',str(root/'independent_audit.py'),str(s),str(out/'independent-audit.json')],check=True)
with tarfile.open(out/'artifacts.tar.xz','w:xz') as tar:
 tar.add(s,arcname='study')
 tar.add(root/'previous-c11',arcname='previous-c11')
 tar.add(root/'independent_audit.py',arcname='independent_audit.py')
 tar.add(root/'NonbondedForceImpl.cpp',arcname='source-control/NonbondedForceImpl.cpp')
write(out/'artifact-inventory.json',{str(p.relative_to(s.parent)):sha(p) for p in s.rglob('*') if p.is_file()})
shutil.copyfile(s/'environment.json',out/'environment.json')
print('archive complete',sha(out/'artifacts.tar.xz'),flush=True)
