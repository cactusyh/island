import importlib,json,hashlib,sys
from pathlib import Path
mods={}
for name in ('openmm','openmm._openmm','numpy','numpy._core._multiarray_umath'):
 try:
  m=importlib.import_module(name);p=Path(m.__file__).resolve();mods[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 except (ImportError,AttributeError) as e:mods[name]={'unavailable':str(e)}
print(json.dumps({'python':sys.version,'executable':sys.executable,'modules':mods},indent=2))
