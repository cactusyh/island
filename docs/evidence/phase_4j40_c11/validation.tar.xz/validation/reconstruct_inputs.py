"""Restore the historical input layout from the portable study bundle."""
import shutil,sys
from pathlib import Path
src=Path(sys.argv[1])/'study/inputs';dst=Path(sys.argv[2]);dst.mkdir(parents=True,exist_ok=False)
ref=dst/'reference/cross-engine';ref.mkdir(parents=True)
for n in ('system.data','in.periodic','forces.dump','execution.log'):shutil.copyfile(src/n,ref/n)
shutil.copyfile(src/'historical-comparison.json',ref.parent/'cross-engine.json')
for i in (0,1):
 d=dst/f'frames/replica-{i}/uninterrupted';d.mkdir(parents=True)
 shutil.copyfile(src/f'replica-{i}-frames.json',d/'frames.json')
shutil.copyfile(src/'backend.json',dst/'backend.json')
