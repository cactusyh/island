"""Independent metric, unit and native XML reconstruction (no study importer)."""
import hashlib,json,math,sys
from pathlib import Path
import openmm as mm
from openmm import unit
root=Path(sys.argv[1]);out=Path(sys.argv[2])
a=json.loads((root/'baseline/openmm/point.json').read_text())
p=root/'baseline/lammps/forces.dump';lines=p.read_text().splitlines();start=next(i for i,s in enumerate(lines) if s.startswith('ITEM: ATOMS '))+1
native=[list(map(float,s.split())) for s in lines[start:]]
b=[[v*41.84 for v in r[-3:]] for r in native]
errors=[[x-y for x,y in zip(ra,rb)] for ra,rb in zip(a['forces_kj_mol_nm'],b)]
rms=math.sqrt(math.fsum(x*x for r in errors for x in r)/(3*len(errors)))
norms=sorted(math.sqrt(math.fsum(x*x for x in r)) for r in errors)
def percentile(q):
 t=q/100*(len(norms)-1);i=math.floor(t);return norms[i]+(norms[min(i+1,len(norms)-1)]-norms[i])*(t-i)
model=mm.XmlSerializer.deserialize((root/'baseline/openmm/system.xml').read_text());integ=mm.VerletIntegrator(.0005)
c=mm.Context(model,integ,mm.Platform.getPlatformByName('Reference'));frame=json.loads((root/'baseline/frame.json').read_text());c.setPositions(frame['positions_nm']);st=c.getState(getEnergy=True,getForces=True)
energy=st.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole);forces=st.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer).tolist()
xml_equal=energy==a['energy_kj_mol'] and forces==a['forces_kj_mol_nm']
reported=json.loads((root/'baseline/comparison.json').read_text())['comparison']['forces']
assert xml_equal
assert abs(rms-reported['rms_component_error'])<1e-12
# The independently grouped unit multiplication differs in the last bit only.
assert abs(max(abs(x) for r in errors for x in r)-reported['maximum_component_error'])<1e-10
pressure={}
for method in ('ewald','pme'):
 for engine in ('openmm','lammps'):
  pairs=[]
  for h in (1e-4,1e-5,1e-6):
   values=[json.loads((root/f'{method}-strain-{engine}'/f'h-{h}-{s}'/'point.json').read_text())['energy_kj_mol'] for s in (-1,1)]
   box=frame['box_lengths_nm'];v=box[0]*box[1]*box[2];bar=-(values[1]-values[0])/(2*h*v)*16.605390671738468
   pairs.append(bar)
  pressure[method+'-'+engine]=pairs
result={'schema':'island.j40-c11-independent-audit.v1','xml_fresh_context_byte_value_equality':xml_equal,'rms_component_error_kj_mol_nm':rms,'atom_error_percentiles':{str(q):percentile(q) for q in (50,90,95,99,100)},'pressure_reconstructed_from_raw_energies_bar':pressure,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scientific_acceptance':False}
out.write_text(json.dumps(result,indent=2)+'\n')
