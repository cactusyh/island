import json,sys
from pathlib import Path
from island.forcefields.external_pdms import load_external_pdms_bundle
from island.workflows.bundle import system_from
from scripts.phase_4j41_c2 import read
roots=list(map(Path,sys.argv[1:]))
out=[]
for case in read(roots[0]/'report.json')['cases']:
 name=case['name'];reports=[]
 for root in roots:
  system=system_from(read(root/name/'system.json'))
  path=root/name/'incomplete-template.json'
  import hashlib
  pin=hashlib.sha256(path.read_bytes()).hexdigest()
  bundle,result=load_external_pdms_bundle(path,system,expected_sha256=pin)
  assert result.payload['status']=='parameter_incomplete'
  assert not result.payload['execution_authorized']
  reports.append(result.json_text)
 assert len(set(reports))==1
 out.append({'case':name,'relocated_bundle_identical':True,'status':'parameter_incomplete','validation':json.loads(reports[0])})
print(json.dumps(out,indent=2))
