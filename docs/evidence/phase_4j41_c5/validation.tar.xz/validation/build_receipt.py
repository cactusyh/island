import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
from pathlib import Path
from scripts.phase_4j41_c2 import read
from scripts.phase_4j41_c5 import BASE,BRANCH,reconstruct_study
from scripts.validate_phase_4j41_receipt import sha,signed
root=Path('/tmp/j41-c5-validation');v=root/'validation';repo=Path.cwd();dest=repo/'docs/evidence/phase_4j41_c5';dest.mkdir(parents=True,exist_ok=True)
commit=(v/'implementation-commit.txt').read_text().strip();assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
for name in ['run_gates.py','run_extra.py','derive_regressions.py','reconstruct_bundles.py','historical_byte_audit.py','build_receipt.py']:
 shutil.copyfile(root/name,v/name)
verification={}
for name in ('focused','full','regressions','ruff','compileall','diff_check','pip_supported','pip_foyer','pip_analysis','pip_amber','pip_quantum','receipt_j41','receipt_c1','receipt_c2','receipt_c3','receipt_c4','historical_byte_audit','relocation','bundle_reconstruction'):
 result=json.loads((v/(name+'-command.json')).read_text());assert result['exit_code']==0 and result['tested_implementation_commit']==commit,name
 verification[name]=result
execution=json.loads((v/'execution-command.json').read_text());assert execution['exit_code']==1 and execution['tested_implementation_commit']==commit
assert 'Traceback' not in (v/'execution.log').read_text()
report=read(root/'final-study/report.json');assert report['status']=='asset_unavailable' and report['execution_profiles']==[]
historical=json.loads((v/'historical-byte-hashes.json').read_text());assert all(sha(repo/p)==h for p,h in historical.items())
implementation={p:sha(repo/p) for p in ('src/island/forcefields/external_pdms.py','scripts/phase_4j41_c5.py','scripts/validate_phase_4j41_c5_receipt.py','tests/test_phase_4j41_c5.py')}
def files(folder):return {str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
# No superseded explorations or unrelated temporary data enter these archives.
for archive,source,arcname in [('execution.tar.xz',root/'final-study','study'),('validation.tar.xz',v,'validation')]:
 with tarfile.open(dest/archive,'w:xz',preset=6) as tar:tar.add(source,arcname=arcname)
manifest=signed({'schema':'island.j41-c5-manifest.v1','base_commit':BASE,'historical_files':historical,'implementation_files':implementation,'archives':{n:sha(dest/n) for n in ('execution.tar.xz','validation.tar.xz')},'study_files':files(root/'final-study'),'validation_files':files(v)})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
counts={}
for name in ('focused','full'):
 counts[name]={k:sum(int(s.attrib.get(k,0)) for s in E.parse(v/(name+'.xml')).getroot()) for k in ('tests','failures','errors','skipped')}
receipt=signed({'schema':'island.j41-c5-receipt.v1','base_commit':BASE,'branch':BRANCH,'tested_implementation_commit':commit,'status':'asset_unavailable','acceptance_gate':1,'execution_profiles':[],'production_validated':False,'simulation_readiness':'not_established','manifest_sha256':sha(dest/'manifest.json'),'study_report':json.loads((root/'final-study/report.json').read_text()),'summary':report,'reconstruction':json.loads((v/'relocation.log').read_text()),'full_source_execution':execution,'verification':verification,'test_counts':counts,'regressions':json.loads((v/'regressions.json').read_text()),'relocation':json.loads((v/'relocation-file-hashes.json').read_text()),'source_and_parameter_rows':'external asset unavailable; independent literal raw-source schema controls and native converter reconstruction executed; no PDMS model published','historical_bytes_match_base':True})
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'test_counts':counts,'historical_files':len(historical),'study_files':len(files(root/'final-study')),'acceptance_gate':1},indent=2))
