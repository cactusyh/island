import os,subprocess,json,tempfile,shutil
from pathlib import Path
from island.analysis.npt import _digest
from island.analysis.npt_continuation import load_continuation,compare_continuations
from island.forcefields.ambertools.resp_policy import FiniteRESPCharges
from scripts.phase_4j34_real_fixture import build_fixture
root=Path('/tmp/j36-c2-validation/final-validation');source=Path('/tmp/j36-c2-validation/post-independent-acceptance');results={}
with tempfile.TemporaryDirectory(prefix='j36-c2-relocation-') as tmp:
 target=Path(tmp)/'different-path';shutil.copytree(source,target)
 for kind in ('linear','network'):
  identity=json.loads((source/('memory-'+kind+'-charges.json')).read_text())['identity']
  a=FiniteRESPCharges.load(target/('memory-'+kind+'-charges.json'),build_fixture(kind,'GAFF2').fixture.packed.graph,expected_identity=identity)
  comp=compare_continuations(target/kind/'uninterrupted',target/kind/'resumed',target/kind/'relocated');assert comp['passed']
  expected=_digest(load_continuation(source/kind/'resumed'));assert expected==_digest(load_continuation(target/kind/'resumed'))
  code='''import sys,json
from pathlib import Path
from island.analysis.npt import _digest
from island.analysis.npt_continuation import load_continuation
from island.forcefields.ambertools.resp_policy import FiniteRESPCharges
from scripts.phase_4j34_real_fixture import build_fixture
p=Path(sys.argv[1]);k=sys.argv[2];q=FiniteRESPCharges.load(p/('memory-'+k+'-charges.json'),build_fixture(k,'GAFF2').fixture.packed.graph,expected_identity=sys.argv[3]);print(json.dumps({'charge_identity':q.identity,'workflow_identity':_digest(load_continuation(p/k/'resumed'))}))'''
  cmd=['../island-validation/phase4g1-env/bin/python','-c',code,str(target),kind,identity]
  child=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':'.:src','OPENMM_CPU_THREADS':'1','OMP_NUM_THREADS':'1'},capture_output=True,text=True)
  assert child.returncode==0,child.stderr
  assert json.loads(child.stdout)=={'charge_identity':identity,'workflow_identity':expected}
  results[kind]={'same_process_relocation':True,'fresh_process_reconstruction':True,'comparison_identity':comp['identity'],'argv':cmd,'exit_code':child.returncode,'child_result':json.loads(child.stdout)}
(root/'relocation.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
