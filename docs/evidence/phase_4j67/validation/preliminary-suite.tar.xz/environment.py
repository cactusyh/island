import importlib.metadata as m,json,platform,sys
from pathlib import Path
result={'python':sys.version,'platform':platform.platform(),'packages':{k:m.version(k) for k in ['numpy','scipy','clarabel','scs','cffi','pycparser']},'lazy_research_solver_bridge':True,'native_environment_unchanged':True}
Path('docs/evidence/phase_4j67/solver-environment.json').write_text(json.dumps(result,indent=2)+'\n')
