import json,os,subprocess
from pathlib import Path
root=Path.cwd()/'docs/evidence/phase_4j67/validation'
env={k:v for k,v in os.environ.items() if k!='PYTHONPATH'}
rows=[r for r in json.loads((root/'historical-checks.json').read_text()) if r['name'].startswith('pip')]
results=[]
for row in rows:
 log=root/(row['name']+'-environment-only.log')
 with log.open('w') as f:r=subprocess.run(row['command'],env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({**row,'returncode':r.returncode,'log':log.name,'correction':'No external PYTHONPATH overlay on unrelated interpreter.'})
(root/'pip-environment-retries.json').write_text(json.dumps(results,indent=2)+'\n')
