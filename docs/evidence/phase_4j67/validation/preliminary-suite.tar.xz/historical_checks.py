import json,os,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'docs/evidence/phase_4j67/validation'
rows=[r for r in json.loads((repo/'docs/evidence/phase_4j66/validation/checks.json').read_text()) if r['name'].startswith(('pip','J'))]
rows.append({'name':'J66_receipt','command':[str(repo.parent/'island-validation/phase4g1-env/bin/python'),'scripts/validate_phase_4j66_receipt.py','docs/evidence/phase_4j66','--repo','.'],'cwd':str(repo)})
env={**os.environ,'PYTHONPATH':str(repo.parent/'island-validation/phase4j66-solvers-only')+':.:src','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','OPENMM_CPU_THREADS':'1'}
results=[]
for row in rows:
 name=row['name'];log=out/(name+'.log')
 with log.open('w') as f:r=subprocess.run(row['command'],cwd=row.get('cwd',str(repo)),env=env,stdout=f,stderr=subprocess.STDOUT,check=False)
 results.append({'name':name,'command':row['command'],'cwd':row.get('cwd',str(repo)),'returncode':r.returncode,'log':log.name})
 (out/'historical-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,r.returncode,flush=True)
raise SystemExit(any(r['returncode'] for r in results))
